#include <stdio.h>

#define NUM 4

__shared__ int v[NUM];

__global__ void bankConflict() {
  int temp;
  v[ (threadIdx.x == 0 || threadIdx.x == 1) ? 0 : threadIdx.x ] = 2;
}

int main() {
  bankConflict<<<1, NUM>>>();
  return 0;
}
