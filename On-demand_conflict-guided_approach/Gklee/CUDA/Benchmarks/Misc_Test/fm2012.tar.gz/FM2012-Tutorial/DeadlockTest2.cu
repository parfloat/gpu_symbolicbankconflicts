#include <stdio.h>

#define NUM 100

__shared__ int v[NUM];

__global__ void deadlock() {
  if (threadIdx.x > 0) { 
    v[threadIdx.x]++;
  }
  else {
    v[threadIdx.x]--;
  }
  __syncthreads();
}

int main() {
  deadlock<<<1,NUM>>>();

  return 0;
}
