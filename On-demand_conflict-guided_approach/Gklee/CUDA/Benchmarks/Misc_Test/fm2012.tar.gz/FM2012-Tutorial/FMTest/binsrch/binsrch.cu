#include "stdio.h"
#include "string.h"

#define STRLEN 5
int main(){
 char item;
 char str[STRLEN];
 int lo=0;
 int hi;
 
 int mid, found=0;
 //  printf("Please give char to be searched: \n");
 //  scanf("%c", &item);
 klee_make_symbolic(&item, sizeof(item), "item");
 //  printf("Please give string within which to search: \n");
 //  scanf("%s", str);
 klee_make_symbolic(str, sizeof(str), "str");
 klee_assume(str[0] <= str[1]);
 klee_assume(str[1] <= str[2]);
 klee_assume(str[2] <= str[3]);
 klee_assume(str[3] <= str[4]);
 str[4] = '\0';
 hi=  4; //strlen(str)-1; // strlen ignores null at the end of string
                   // hi points to last char in a 0 based array
 while(!found && lo <= hi) {
   mid = (lo+hi)/2;
   
   if (item == str[mid])
     { printf("*\n");
        found = 1; }
   else
     if (item < str[mid])
       { hi = mid-1;
	  printf("L\n"); }
     else
       { lo = mid+1;
	  printf("H\n"); }
 }
 if (found) printf("found\n");//printf("\nitem %c found at posn %d\n", item, mid);
 else printf("not found\n");//printf("\nitem %c not in str %s\n", item, str);
 return found;
}
/*
  Guodong said to use the -check-div-zero=false flag before the object
file on the command line. Also, to only generate sorted arrays you
need the following calls after klee_make_symbolic() (for array size
3):

  klee_assume(str[0] <= str[1]);
  klee_assume(str[1] <= str[2]);

*/
