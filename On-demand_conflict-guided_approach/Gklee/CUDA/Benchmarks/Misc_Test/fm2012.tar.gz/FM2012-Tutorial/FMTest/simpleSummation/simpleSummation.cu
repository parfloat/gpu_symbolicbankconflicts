#include "stdio.h"

#define NUM 4

__shared__ int shared[NUM];

__global__ void simpleSummation(int * values)
{
  unsigned int tid = threadIdx.x;

  // Copy input to shared mem.  
  shared[tid] = values[tid];
  //__syncthreads();

  // Compute
  shared[tid] += tid;

  // __syncthreads();  
  // Write result.
  values[tid] = shared[tid];
}


// *************************************************************
//  Driver 
// *************************************************************

int main() {
  int values[NUM];
  klee_make_symbolic(values, sizeof(values), "input");

  klee_assume(values[0] == values[1]);
  klee_assume(values[1] == values[2]);
  klee_assume(values[2] == values[3]);
  
  int *dvalues;
  cudaMalloc((void**)&dvalues, sizeof(int)*NUM);
  cudaMemcpy(dvalues, values, sizeof(int)*NUM, cudaMemcpyHostToDevice);

  simpleSummation<<<1,NUM>>>(dvalues);
  cudaMemcpy(values, dvalues, sizeof(int)*NUM, cudaMemcpyHostToDevice);

  // post-conditions
  for (int i = 1; i < NUM; i++) {
    if (values[i] != (values[i-1]+1)) {
      printf("The summation routine is behaving incorrectly at location %d\n", i);
    }
  }
  return 0;
}


