; ModuleID = 'ConcolicIllustration1'
target datalayout = "e-p:64:64:64-i1:8:8-i8:8:8-i16:16:16-i32:32:32-i64:64:64-f32:32:32-f64:64:64-v64:64:64-v128:128:128-a0:0:64-s0:64:64-f80:128:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%struct.dim3 = type { i32, i32, i32 }

@gridDim = global %struct.dim3 zeroinitializer, align 4
@blockIdx = global %struct.dim3 zeroinitializer, align 4
@blockDim = global %struct.dim3 zeroinitializer, align 4
@threadIdx = global %struct.dim3 zeroinitializer, align 4
@.str = private unnamed_addr constant [6 x i8] c"item1\00", align 1
@.str4 = private unnamed_addr constant [6 x i8] c"item2\00", align 1
@.str5 = private unnamed_addr constant [6 x i8] c"item3\00", align 1
@.str6 = private unnamed_addr constant [15 x i8] c"Item1 > Item2\0A\00", align 1
@.str7 = private unnamed_addr constant [15 x i8] c"Item2 > Item3\0A\00", align 1
@.str8 = private unnamed_addr constant [15 x i8] c"Item3 > Item1\0A\00", align 1
@.str9 = private unnamed_addr constant [16 x i8] c"Item3 <= Item1\0A\00", align 1
@.str10 = private unnamed_addr constant [16 x i8] c"Item2 <= Item3\0A\00", align 1
@.str11 = private unnamed_addr constant [16 x i8] c"Item1 <= Item2\0A\00", align 1
@llvm.global_ctors = appending global [1 x { i32, void ()* }] [{ i32, void ()* } { i32 65535, void ()* @_GLOBAL__I_a }]

define internal void @__cxx_global_var_init() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @gridDim, i32 1, i32 1, i32 1)
  ret void
}

define linkonce_odr void @_ZN4dim3C1Ejjj(%struct.dim3* %this, i32 %vx, i32 %vy, i32 %vz) unnamed_addr uwtable section "__device__" align 2 {
entry:
  %this.addr = alloca %struct.dim3*, align 8
  %vx.addr = alloca i32, align 4
  %vy.addr = alloca i32, align 4
  %vz.addr = alloca i32, align 4
  store %struct.dim3* %this, %struct.dim3** %this.addr, align 8
  store i32 %vx, i32* %vx.addr, align 4
  store i32 %vy, i32* %vy.addr, align 4
  store i32 %vz, i32* %vz.addr, align 4
  %this1 = load %struct.dim3** %this.addr
  %0 = load i32* %vx.addr, align 4
  %1 = load i32* %vy.addr, align 4
  %2 = load i32* %vz.addr, align 4
  call void @_ZN4dim3C2Ejjj(%struct.dim3* %this1, i32 %0, i32 %1, i32 %2)
  ret void
}

define internal void @__cxx_global_var_init1() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @blockIdx, i32 1, i32 1, i32 1)
  ret void
}

define internal void @__cxx_global_var_init2() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @blockDim, i32 1, i32 1, i32 1)
  ret void
}

define internal void @__cxx_global_var_init3() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @threadIdx, i32 1, i32 1, i32 1)
  ret void
}

define i32 @main() uwtable {
entry:
  call void @klee.ctor_stub()
  %retval = alloca i32, align 4
  %item1 = alloca i32, align 4
  %item2 = alloca i32, align 4
  %item3 = alloca i32, align 4
  store i32 0, i32* %retval
  %0 = bitcast i32* %item1 to i8*
  call void @klee_make_symbolic(i8* %0, i64 4, i8* getelementptr inbounds ([6 x i8]* @.str, i32 0, i32 0))
  %1 = bitcast i32* %item2 to i8*
  call void @klee_make_symbolic(i8* %1, i64 4, i8* getelementptr inbounds ([6 x i8]* @.str4, i32 0, i32 0))
  %2 = bitcast i32* %item3 to i8*
  call void @klee_make_symbolic(i8* %2, i64 4, i8* getelementptr inbounds ([6 x i8]* @.str5, i32 0, i32 0))
  %3 = load i32* %item1, align 4
  %4 = load i32* %item2, align 4
  %cmp = icmp sgt i32 %3, %4
  br i1 %cmp, label %if.then, label %if.end10

if.then:                                          ; preds = %entry
  %call = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([15 x i8]* @.str6, i32 0, i32 0))
  %5 = load i32* %item2, align 4
  %6 = load i32* %item3, align 4
  %cmp1 = icmp sgt i32 %5, %6
  br i1 %cmp1, label %if.then2, label %if.end8

if.then2:                                         ; preds = %if.then
  %call3 = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([15 x i8]* @.str7, i32 0, i32 0))
  %7 = load i32* %item3, align 4
  %8 = load i32* %item1, align 4
  %cmp4 = icmp sgt i32 %7, %8
  br i1 %cmp4, label %if.then5, label %if.else

if.then5:                                         ; preds = %if.then2
  %call6 = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([15 x i8]* @.str8, i32 0, i32 0))
  br label %if.end8

if.else:                                          ; preds = %if.then2
  %call7 = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([16 x i8]* @.str9, i32 0, i32 0))
  br label %if.end8

if.end8:                                          ; preds = %if.then5, %if.else, %if.then
  %call9 = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([16 x i8]* @.str10, i32 0, i32 0))
  br label %if.end10

if.end10:                                         ; preds = %if.end8, %entry
  %call11 = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([16 x i8]* @.str11, i32 0, i32 0))
  %9 = load i32* %retval
  ret i32 %9
}

declare void @klee_make_symbolic(i8*, i64, i8*)

declare i32 @printf(i8*, ...)

define linkonce_odr void @_ZN4dim3C2Ejjj(%struct.dim3* %this, i32 %vx, i32 %vy, i32 %vz) unnamed_addr nounwind uwtable section "__device__" align 2 {
entry:
  %this.addr = alloca %struct.dim3*, align 8
  %vx.addr = alloca i32, align 4
  %vy.addr = alloca i32, align 4
  %vz.addr = alloca i32, align 4
  store %struct.dim3* %this, %struct.dim3** %this.addr, align 8
  store i32 %vx, i32* %vx.addr, align 4
  store i32 %vy, i32* %vy.addr, align 4
  store i32 %vz, i32* %vz.addr, align 4
  %this1 = load %struct.dim3** %this.addr
  %x = getelementptr inbounds %struct.dim3* %this1, i32 0, i32 0
  %0 = load i32* %vx.addr, align 4
  store i32 %0, i32* %x, align 4
  %y = getelementptr inbounds %struct.dim3* %this1, i32 0, i32 1
  %1 = load i32* %vy.addr, align 4
  store i32 %1, i32* %y, align 4
  %z = getelementptr inbounds %struct.dim3* %this1, i32 0, i32 2
  %2 = load i32* %vz.addr, align 4
  store i32 %2, i32* %z, align 4
  ret void
}

define internal void @_GLOBAL__I_a() section ".text.startup" {
entry:
  call void @__cxx_global_var_init()
  call void @__cxx_global_var_init1()
  call void @__cxx_global_var_init2()
  call void @__cxx_global_var_init3()
  ret void
}

declare void @llvm.dbg.value(metadata, i64, metadata) nounwind readnone

define internal void @klee.ctor_stub() {
entry:
  call void @_GLOBAL__I_a()
  ret void
}

!llvm.dbg.cu = !{!0, !26, !42}

!0 = metadata !{i32 786449, i32 0, i32 1, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memcpy.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", metadata !"clang version 3.2 (trunk 162409)", i1 true, i1 t
!1 = metadata !{metadata !2}
!2 = metadata !{i32 0}
!3 = metadata !{metadata !4}
!4 = metadata !{metadata !5}
!5 = metadata !{i32 786478, i32 0, metadata !6, metadata !"memcpy", metadata !"memcpy", metadata !"", metadata !6, i32 12, metadata !7, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, null, null, null, metadata !14, i32 12} ; [ DW_TAG_subprogram
!6 = metadata !{i32 786473, metadata !"memcpy.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!7 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !8, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!8 = metadata !{metadata !9, metadata !9, metadata !10, metadata !12}
!9 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, null} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!10 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !11} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!11 = metadata !{i32 786470, null, metadata !"", null, i32 0, i64 0, i64 0, i64 0, i32 0, null} ; [ DW_TAG_const_type ] [line 0, size 0, align 0, offset 0] [from ]
!12 = metadata !{i32 786454, null, metadata !"size_t", metadata !6, i32 35, i64 0, i64 0, i64 0, i32 0, metadata !13} ; [ DW_TAG_typedef ] [size_t] [line 35, size 0, align 0, offset 0] [from long unsigned int]
!13 = metadata !{i32 786468, null, metadata !"long unsigned int", null, i32 0, i64 64, i64 64, i64 0, i32 0, i32 7} ; [ DW_TAG_base_type ] [long unsigned int] [line 0, size 64, align 64, offset 0, enc DW_ATE_unsigned]
!14 = metadata !{metadata !15}
!15 = metadata !{metadata !16, metadata !17, metadata !18, metadata !19, metadata !23}
!16 = metadata !{i32 786689, metadata !5, metadata !"destaddr", metadata !6, i32 16777228, metadata !9, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [destaddr] [line 12]
!17 = metadata !{i32 786689, metadata !5, metadata !"srcaddr", metadata !6, i32 33554444, metadata !10, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [srcaddr] [line 12]
!18 = metadata !{i32 786689, metadata !5, metadata !"len", metadata !6, i32 50331660, metadata !12, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [len] [line 12]
!19 = metadata !{i32 786688, metadata !20, metadata !"dest", metadata !6, i32 13, metadata !21, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [dest] [line 13]
!20 = metadata !{i32 786443, metadata !5, i32 12, i32 63, metadata !6, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memcpy.c]
!21 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !22} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from char]
!22 = metadata !{i32 786468, null, metadata !"char", null, i32 0, i64 8, i64 8, i64 0, i32 0, i32 6} ; [ DW_TAG_base_type ] [char] [line 0, size 8, align 8, offset 0, enc DW_ATE_signed_char]
!23 = metadata !{i32 786688, metadata !20, metadata !"src", metadata !6, i32 14, metadata !24, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [src] [line 14]
!24 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !25} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!25 = metadata !{i32 786470, null, metadata !"", null, i32 0, i64 0, i64 0, i64 0, i32 0, metadata !22} ; [ DW_TAG_const_type ] [line 0, size 0, align 0, offset 0] [from char]
!26 = metadata !{i32 786449, i32 0, i32 1, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memmove.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", metadata !"clang version 3.2 (trunk 162409)", i1 true, i1
!27 = metadata !{metadata !28}
!28 = metadata !{metadata !29}
!29 = metadata !{i32 786478, i32 0, metadata !30, metadata !"memmove", metadata !"memmove", metadata !"", metadata !30, i32 12, metadata !31, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, null, null, null, metadata !34, i32 12} ; [ DW_TAG_subp
!30 = metadata !{i32 786473, metadata !"memmove.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!31 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !32, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!32 = metadata !{metadata !9, metadata !9, metadata !10, metadata !33}
!33 = metadata !{i32 786454, null, metadata !"size_t", metadata !30, i32 35, i64 0, i64 0, i64 0, i32 0, metadata !13} ; [ DW_TAG_typedef ] [size_t] [line 35, size 0, align 0, offset 0] [from long unsigned int]
!34 = metadata !{metadata !35}
!35 = metadata !{metadata !36, metadata !37, metadata !38, metadata !39, metadata !41}
!36 = metadata !{i32 786689, metadata !29, metadata !"dst", metadata !30, i32 16777228, metadata !9, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [dst] [line 12]
!37 = metadata !{i32 786689, metadata !29, metadata !"src", metadata !30, i32 33554444, metadata !10, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [src] [line 12]
!38 = metadata !{i32 786689, metadata !29, metadata !"count", metadata !30, i32 50331660, metadata !33, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [count] [line 12]
!39 = metadata !{i32 786688, metadata !40, metadata !"a", metadata !30, i32 14, metadata !21, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [a] [line 14]
!40 = metadata !{i32 786443, metadata !29, i32 12, i32 57, metadata !30, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memmove.c]
!41 = metadata !{i32 786688, metadata !40, metadata !"b", metadata !30, i32 15, metadata !24, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [b] [line 15]
!42 = metadata !{i32 786449, i32 0, i32 1, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memset.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", metadata !"clang version 3.2 (trunk 162409)", i1 true, i1 
!43 = metadata !{metadata !44}
!44 = metadata !{metadata !45}
!45 = metadata !{i32 786478, i32 0, metadata !46, metadata !"memset", metadata !"memset", metadata !"", metadata !46, i32 12, metadata !47, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, null, null, null, metadata !51, i32 12} ; [ DW_TAG_subpro
!46 = metadata !{i32 786473, metadata !"memset.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!47 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !48, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!48 = metadata !{metadata !9, metadata !9, metadata !49, metadata !50}
!49 = metadata !{i32 786468, null, metadata !"int", null, i32 0, i64 32, i64 32, i64 0, i32 0, i32 5} ; [ DW_TAG_base_type ] [int] [line 0, size 32, align 32, offset 0, enc DW_ATE_signed]
!50 = metadata !{i32 786454, null, metadata !"size_t", metadata !46, i32 35, i64 0, i64 0, i64 0, i32 0, metadata !13} ; [ DW_TAG_typedef ] [size_t] [line 35, size 0, align 0, offset 0] [from long unsigned int]
!51 = metadata !{metadata !52}
!52 = metadata !{metadata !53, metadata !54, metadata !55, metadata !56}
!53 = metadata !{i32 786689, metadata !45, metadata !"dst", metadata !46, i32 16777228, metadata !9, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [dst] [line 12]
!54 = metadata !{i32 786689, metadata !45, metadata !"s", metadata !46, i32 33554444, metadata !49, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [s] [line 12]
!55 = metadata !{i32 786689, metadata !45, metadata !"count", metadata !46, i32 50331660, metadata !50, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [count] [line 12]
!56 = metadata !{i32 786688, metadata !57, metadata !"a", metadata !46, i32 13, metadata !58, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [a] [line 13]
!57 = metadata !{i32 786443, metadata !45, i32 12, i32 47, metadata !46, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memset.c]
!58 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !59} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!59 = metadata !{i32 786485, null, metadata !"", null, i32 0, i64 0, i64 0, i64 0, i32 0, metadata !22} ; [ DW_TAG_volatile_type ] [line 0, size 0, align 0, offset 0] [from char]
