#include "stdio.h"
#include <cstdlib>

#ifndef NUM
#define  NUM  4
#endif

__shared__ int shared[NUM];

__device__ inline void swap(int & a, int & b) {
  // Alternative swap doesn't use a temporary register:
  // a ^= b;
  // b ^= a;
  // a ^= b;
  
  int tmp = a;
  a = b;
  b = tmp;
}

__global__ void BitonicKernel(int * values)
{
  unsigned int tid = threadIdx.x;

  // Copy input to shared mem.  
  shared[tid] = values[tid];
  __syncthreads();

  // Parallel bitonic sort.
  for (unsigned int k = 2; k <= blockDim.x; k *= 2) {
    for (unsigned int j = k / 2; j>0; j /= 2) {
      unsigned int ixj = tid ^ j;
      
      if (ixj > tid) {
	if ((tid & k) == 0) {
	  if (shared[tid] > shared[ixj])
	    swap(shared[tid], shared[ixj]);
	}
	else {
	  if (shared[tid] < shared[ixj])
	    swap(shared[tid], shared[ixj]);
	}
      }
      __syncthreads();
    }
  } //end sort
  
  // Write result.
  values[tid] = shared[tid];
}

int main() {
  int values[NUM];
  klee_make_symbolic(values, sizeof(values), "input");
  
  int *dvalues;
  cudaMalloc((void **)&dvalues, sizeof(int) * NUM);
  cudaMemcpy(dvalues, values, sizeof(int) * NUM, cudaMemcpyHostToDevice);

  // the following is equivalent to calling the kernel using <<<...>>>(BitonicKernel)
  BitonicKernel<<<1,NUM>>>(dvalues);
   
  cudaMemcpy(values, dvalues, sizeof(int) * NUM, cudaMemcpyHostToDevice);
  
  // post-conditions
  for (int i = 1; i < NUM; i++) {
    if (values[i] < values[i-1]) {
      printf("The sorting algorithm is incorrect since values[%d] < values[%d]!\n", i, i-1);
    }
  }
  cudaFree(dvalues);

  return 0;
}
