; ModuleID = 'DeadlockTest1'
target datalayout = "e-p:64:64:64-i1:8:8-i8:8:8-i16:16:16-i32:32:32-i64:64:64-f32:32:32-f64:64:64-v64:64:64-v128:128:128-a0:0:64-s0:64:64-f80:128:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%struct.dim3 = type { i32, i32, i32 }
%struct.CUstream_st = type opaque

@v = global [100 x i32] zeroinitializer, section "__shared__", align 16
@gridDim = global %struct.dim3 zeroinitializer, align 4
@blockIdx = global %struct.dim3 zeroinitializer, align 4
@blockDim = global %struct.dim3 zeroinitializer, align 4
@threadIdx = global %struct.dim3 zeroinitializer, align 4
@llvm.global_ctors = appending global [1 x { i32, void ()* }] [{ i32, void ()* } { i32 65535, void ()* @_GLOBAL__I_a }]

define void @_Z8deadlockv() uwtable {
entry:
  %0 = load i32* getelementptr inbounds (%struct.dim3* @threadIdx, i32 0, i32 0), align 4, !dbg !118
  %cmp = icmp ugt i32 %0, 0, !dbg !118
  %1 = load i32* getelementptr inbounds (%struct.dim3* @threadIdx, i32 0, i32 0), align 4, !dbg !120
  %idxprom = zext i32 %1 to i64, !dbg !120
  %arrayidx = getelementptr inbounds [100 x i32]* @v, i32 0, i64 %idxprom, !dbg !120
  %2 = load i32* %arrayidx, align 4, !dbg !120
  br i1 %cmp, label %if.then, label %if.else, !dbg !118

if.then:                                          ; preds = %entry
  %inc = add nsw i32 %2, 1, !dbg !120
  store i32 %inc, i32* %arrayidx, align 4, !dbg !120
  call void @__syncthreads(), !dbg !122
  br label %if.end, !dbg !123

if.else:                                          ; preds = %entry
  %dec = add nsw i32 %2, -1, !dbg !124
  store i32 %dec, i32* %arrayidx, align 4, !dbg !124
  call void @__syncthreads(), !dbg !126
  br label %if.end

if.end:                                           ; preds = %if.else, %if.then
  ret void, !dbg !127
}

declare void @__syncthreads() section "__device__"

define internal void @__cxx_global_var_init() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @gridDim, i32 1, i32 1, i32 1), !dbg !128
  ret void, !dbg !128
}

define linkonce_odr void @_ZN4dim3C1Ejjj(%struct.dim3* %this, i32 %vx, i32 %vy, i32 %vz) unnamed_addr uwtable section "__device__" align 2 {
entry:
  %this.addr = alloca %struct.dim3*, align 8
  %vx.addr = alloca i32, align 4
  %vy.addr = alloca i32, align 4
  %vz.addr = alloca i32, align 4
  store %struct.dim3* %this, %struct.dim3** %this.addr, align 8
  store i32 %vx, i32* %vx.addr, align 4
  store i32 %vy, i32* %vy.addr, align 4
  store i32 %vz, i32* %vz.addr, align 4
  %this1 = load %struct.dim3** %this.addr
  %0 = load i32* %vx.addr, align 4, !dbg !129
  %1 = load i32* %vy.addr, align 4, !dbg !129
  %2 = load i32* %vz.addr, align 4, !dbg !129
  call void @_ZN4dim3C2Ejjj(%struct.dim3* %this1, i32 %0, i32 %1, i32 %2), !dbg !129
  ret void, !dbg !129
}

define internal void @__cxx_global_var_init1() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @blockIdx, i32 1, i32 1, i32 1), !dbg !130
  ret void, !dbg !130
}

define internal void @__cxx_global_var_init2() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @blockDim, i32 1, i32 1, i32 1), !dbg !131
  ret void, !dbg !131
}

define internal void @__cxx_global_var_init3() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @threadIdx, i32 1, i32 1, i32 1), !dbg !132
  ret void, !dbg !132
}

declare i32 @cudaSetupArgument(i8*, i64, i64)

declare i32 @cudaLaunch(i8*)

define i32 @main() uwtable {
entry:
  call void @klee.ctor_stub()
  %retval = alloca i32, align 4
  %agg.tmp = alloca %struct.dim3, align 4
  %agg.tmp1 = alloca %struct.dim3, align 4
  store i32 0, i32* %retval
  call void @_ZN4dim3C1Ejjj(%struct.dim3* %agg.tmp, i32 1, i32 1, i32 1), !dbg !133
  call void @_ZN4dim3C1Ejjj(%struct.dim3* %agg.tmp1, i32 100, i32 1, i32 1), !dbg !133
  %0 = bitcast %struct.dim3* %agg.tmp to { i64, i32 }*, !dbg !133
  %1 = getelementptr { i64, i32 }* %0, i32 0, i32 0, !dbg !133
  %2 = load i64* %1, align 1, !dbg !133
  %3 = getelementptr { i64, i32 }* %0, i32 0, i32 1, !dbg !133
  %4 = load i32* %3, align 1, !dbg !133
  %5 = bitcast %struct.dim3* %agg.tmp1 to { i64, i32 }*, !dbg !133
  %6 = getelementptr { i64, i32 }* %5, i32 0, i32 0, !dbg !133
  %7 = load i64* %6, align 1, !dbg !133
  %8 = getelementptr { i64, i32 }* %5, i32 0, i32 1, !dbg !133
  %9 = load i32* %8, align 1, !dbg !133
  %call = call i32 @cudaConfigureCall(i64 %2, i32 %4, i64 %7, i32 %9, i64 0, %struct.CUstream_st* null), !dbg !133
  %tobool = icmp ne i32 %call, 0, !dbg !133
  br i1 %tobool, label %kcall.end, label %kcall.configok, !dbg !133

kcall.configok:                                   ; preds = %entry
  call void @_Z8deadlockv(), !dbg !133
  br label %kcall.end, !dbg !133

kcall.end:                                        ; preds = %kcall.configok, %entry
  ret i32 0, !dbg !135
}

declare i32 @cudaConfigureCall(i64, i32, i64, i32, i64, %struct.CUstream_st*)

declare void @llvm.dbg.declare(metadata, metadata) nounwind readnone

define linkonce_odr void @_ZN4dim3C2Ejjj(%struct.dim3* %this, i32 %vx, i32 %vy, i32 %vz) unnamed_addr nounwind uwtable section "__device__" align 2 {
entry:
  %this.addr = alloca %struct.dim3*, align 8
  %vx.addr = alloca i32, align 4
  %vy.addr = alloca i32, align 4
  %vz.addr = alloca i32, align 4
  store %struct.dim3* %this, %struct.dim3** %this.addr, align 8
  store i32 %vx, i32* %vx.addr, align 4
  store i32 %vy, i32* %vy.addr, align 4
  store i32 %vz, i32* %vz.addr, align 4
  %this1 = load %struct.dim3** %this.addr
  %x = getelementptr inbounds %struct.dim3* %this1, i32 0, i32 0, !dbg !136
  %0 = load i32* %vx.addr, align 4, !dbg !136
  store i32 %0, i32* %x, align 4, !dbg !136
  %y = getelementptr inbounds %struct.dim3* %this1, i32 0, i32 1, !dbg !136
  %1 = load i32* %vy.addr, align 4, !dbg !136
  store i32 %1, i32* %y, align 4, !dbg !136
  %z = getelementptr inbounds %struct.dim3* %this1, i32 0, i32 2, !dbg !136
  %2 = load i32* %vz.addr, align 4, !dbg !136
  store i32 %2, i32* %z, align 4, !dbg !136
  ret void, !dbg !137
}

define internal void @_GLOBAL__I_a() section ".text.startup" {
entry:
  call void @__cxx_global_var_init()
  call void @__cxx_global_var_init1()
  call void @__cxx_global_var_init2()
  call void @__cxx_global_var_init3()
  ret void
}

declare void @llvm.dbg.value(metadata, i64, metadata) nounwind readnone

define internal void @klee.ctor_stub() {
entry:
  call void @_GLOBAL__I_a()
  ret void
}

!llvm.dbg.cu = !{!0, !16, !61, !85, !101}

!0 = metadata !{i32 786449, i32 0, i32 4, metadata !"DeadlockTest1.cu", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Deadlock", metadata !"clang version 3.2 (trunk 162409)", i1 true, i1 false, metadata !"", i32
!1 = metadata !{metadata !2}
!2 = metadata !{i32 0}
!3 = metadata !{metadata !4}
!4 = metadata !{metadata !5}
!5 = metadata !{i32 786478, i32 0, metadata !6, metadata !"deadlock", metadata !"deadlock", metadata !"_Z8deadlockv", metadata !6, i32 7, metadata !7, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void ()* @_Z8deadlockv, null, null, metadata 
!6 = metadata !{i32 786473, metadata !"DeadlockTest1.cu", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Deadlock", null} ; [ DW_TAG_file_type ]
!7 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !8, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!8 = metadata !{null}
!9 = metadata !{metadata !10}
!10 = metadata !{metadata !11}
!11 = metadata !{i32 786484, i32 0, null, metadata !"v", metadata !"v", metadata !"", metadata !6, i32 5, metadata !12, i32 0, i32 1, [100 x i32]* @v} ; [ DW_TAG_variable ] [v] [line 5] [def]
!12 = metadata !{i32 786433, null, metadata !"", null, i32 0, i64 3200, i64 32, i32 0, i32 0, metadata !13, metadata !14, i32 0, i32 0} ; [ DW_TAG_array_type ] [line 0, size 3200, align 32, offset 0] [from int]
!13 = metadata !{i32 786468, null, metadata !"int", null, i32 0, i64 32, i64 32, i64 0, i32 0, i32 5} ; [ DW_TAG_base_type ] [int] [line 0, size 32, align 32, offset 0, enc DW_ATE_signed]
!14 = metadata !{metadata !15}
!15 = metadata !{i32 786465, i64 0, i64 99}       ; [ DW_TAG_subrange_type ] [0, 99]
!16 = metadata !{i32 786449, i32 0, i32 4, metadata !"DeadlockTest1.cu", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Deadlock", metadata !"clang version 3.2 (trunk 162409)", i1 true, i1 false, metadata !"", i3
!17 = metadata !{metadata !18}
!18 = metadata !{metadata !19, metadata !21, metadata !22, metadata !23, metadata !5, metadata !24, metadata !27, metadata !53}
!19 = metadata !{i32 786478, i32 0, metadata !20, metadata !"__cxx_global_var_init", metadata !"__cxx_global_var_init", metadata !"", metadata !20, i32 26, metadata !7, i1 true, i1 true, i32 0, i32 0, null, i32 256, i1 false, void ()* @__cxx_global_var_i
!20 = metadata !{i32 786473, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/include/klee/gklee.h", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Deadlock", null} ; [ DW_TAG_file_type ]
!21 = metadata !{i32 786478, i32 0, metadata !20, metadata !"__cxx_global_var_init1", metadata !"__cxx_global_var_init1", metadata !"", metadata !20, i32 27, metadata !7, i1 true, i1 true, i32 0, i32 0, null, i32 256, i1 false, void ()* @__cxx_global_var
!22 = metadata !{i32 786478, i32 0, metadata !20, metadata !"__cxx_global_var_init2", metadata !"__cxx_global_var_init2", metadata !"", metadata !20, i32 28, metadata !7, i1 true, i1 true, i32 0, i32 0, null, i32 256, i1 false, void ()* @__cxx_global_var
!23 = metadata !{i32 786478, i32 0, metadata !20, metadata !"__cxx_global_var_init3", metadata !"__cxx_global_var_init3", metadata !"", metadata !20, i32 29, metadata !7, i1 true, i1 true, i32 0, i32 0, null, i32 256, i1 false, void ()* @__cxx_global_var
!24 = metadata !{i32 786478, i32 0, metadata !6, metadata !"main", metadata !"main", metadata !"", metadata !6, i32 18, metadata !25, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, i32 ()* @main, null, null, metadata !1, i32 18} ; [ DW_TAG_sub
!25 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !26, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!26 = metadata !{metadata !13}
!27 = metadata !{i32 786478, i32 0, null, metadata !"dim3", metadata !"dim3", metadata !"_ZN4dim3C1Ejjj", metadata !28, i32 397, metadata !29, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (%struct.dim3*, i32, i32, i32)* @_ZN4dim3C1Ejjj,
!28 = metadata !{i32 786473, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/include/cuda/vector_types.h", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Deadlock", null} ; [ DW_TAG_file_type ]
!29 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !30, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!30 = metadata !{null, metadata !31, metadata !35, metadata !35, metadata !35}
!31 = metadata !{i32 786447, i32 0, metadata !"", i32 0, i32 0, i64 64, i64 64, i64 0, i32 64, metadata !32} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from dim3]
!32 = metadata !{i32 786434, null, metadata !"dim3", metadata !28, i32 393, i64 96, i64 32, i32 0, i32 0, null, metadata !33, i32 0, null, null} ; [ DW_TAG_class_type ] [dim3] [line 393, size 96, align 32, offset 0] [from ]
!33 = metadata !{metadata !34, metadata !36, metadata !37, metadata !38, metadata !41, metadata !50}
!34 = metadata !{i32 786445, metadata !32, metadata !"x", metadata !28, i32 395, i64 32, i64 32, i64 0, i32 0, metadata !35} ; [ DW_TAG_member ] [x] [line 395, size 32, align 32, offset 0] [from unsigned int]
!35 = metadata !{i32 786468, null, metadata !"unsigned int", null, i32 0, i64 32, i64 32, i64 0, i32 0, i32 7} ; [ DW_TAG_base_type ] [unsigned int] [line 0, size 32, align 32, offset 0, enc DW_ATE_unsigned]
!36 = metadata !{i32 786445, metadata !32, metadata !"y", metadata !28, i32 395, i64 32, i64 32, i64 32, i32 0, metadata !35} ; [ DW_TAG_member ] [y] [line 395, size 32, align 32, offset 32] [from unsigned int]
!37 = metadata !{i32 786445, metadata !32, metadata !"z", metadata !28, i32 395, i64 32, i64 32, i64 64, i32 0, metadata !35} ; [ DW_TAG_member ] [z] [line 395, size 32, align 32, offset 64] [from unsigned int]
!38 = metadata !{i32 786478, i32 0, metadata !32, metadata !"dim3", metadata !"dim3", metadata !"", metadata !28, i32 397, metadata !29, i1 false, i1 false, i32 0, i32 0, null, i32 256, i1 false, null, null, i32 0, metadata !39, i32 397} ; [ DW_TAG_subpr
!39 = metadata !{metadata !40}
!40 = metadata !{i32 786468}                      ; [ DW_TAG_base_type ] [line 0, size 0, align 0, offset 0]
!41 = metadata !{i32 786478, i32 0, metadata !32, metadata !"dim3", metadata !"dim3", metadata !"", metadata !28, i32 398, metadata !42, i1 false, i1 false, i32 0, i32 0, null, i32 256, i1 false, null, null, i32 0, metadata !39, i32 398} ; [ DW_TAG_subpr
!42 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !43, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!43 = metadata !{null, metadata !31, metadata !44}
!44 = metadata !{i32 786454, null, metadata !"uint3", metadata !28, i32 359, i64 0, i64 0, i64 0, i32 0, metadata !45} ; [ DW_TAG_typedef ] [uint3] [line 359, size 0, align 0, offset 0] [from uint3]
!45 = metadata !{i32 786434, null, metadata !"uint3", metadata !28, i32 186, i64 96, i64 32, i32 0, i32 0, null, metadata !46, i32 0, null, null} ; [ DW_TAG_class_type ] [uint3] [line 186, size 96, align 32, offset 0] [from ]
!46 = metadata !{metadata !47, metadata !48, metadata !49}
!47 = metadata !{i32 786445, metadata !45, metadata !"x", metadata !28, i32 188, i64 32, i64 32, i64 0, i32 0, metadata !35} ; [ DW_TAG_member ] [x] [line 188, size 32, align 32, offset 0] [from unsigned int]
!48 = metadata !{i32 786445, metadata !45, metadata !"y", metadata !28, i32 188, i64 32, i64 32, i64 32, i32 0, metadata !35} ; [ DW_TAG_member ] [y] [line 188, size 32, align 32, offset 32] [from unsigned int]
!49 = metadata !{i32 786445, metadata !45, metadata !"z", metadata !28, i32 188, i64 32, i64 32, i64 64, i32 0, metadata !35} ; [ DW_TAG_member ] [z] [line 188, size 32, align 32, offset 64] [from unsigned int]
!50 = metadata !{i32 786478, i32 0, metadata !32, metadata !"operator uint3", metadata !"operator uint3", metadata !"_ZN4dim3cv5uint3Ev", metadata !28, i32 399, metadata !51, i1 false, i1 false, i32 0, i32 0, null, i32 256, i1 false, null, null, i32 0, m
!51 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !52, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!52 = metadata !{metadata !44, metadata !31}
!53 = metadata !{i32 786478, i32 0, null, metadata !"dim3", metadata !"dim3", metadata !"_ZN4dim3C2Ejjj", metadata !28, i32 397, metadata !29, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (%struct.dim3*, i32, i32, i32)* @_ZN4dim3C2Ejjj,
!54 = metadata !{metadata !55}
!55 = metadata !{metadata !56, metadata !58, metadata !59, metadata !60}
!56 = metadata !{i32 786484, i32 0, null, metadata !"gridDim", metadata !"gridDim", metadata !"", metadata !20, i32 26, metadata !57, i32 0, i32 1, %struct.dim3* @gridDim} ; [ DW_TAG_variable ] [gridDim] [line 26] [def]
!57 = metadata !{i32 786454, null, metadata !"dim3", metadata !20, i32 403, i64 0, i64 0, i64 0, i32 0, metadata !32} ; [ DW_TAG_typedef ] [dim3] [line 403, size 0, align 0, offset 0] [from dim3]
!58 = metadata !{i32 786484, i32 0, null, metadata !"blockIdx", metadata !"blockIdx", metadata !"", metadata !20, i32 27, metadata !57, i32 0, i32 1, %struct.dim3* @blockIdx} ; [ DW_TAG_variable ] [blockIdx] [line 27] [def]
!59 = metadata !{i32 786484, i32 0, null, metadata !"blockDim", metadata !"blockDim", metadata !"", metadata !20, i32 28, metadata !57, i32 0, i32 1, %struct.dim3* @blockDim} ; [ DW_TAG_variable ] [blockDim] [line 28] [def]
!60 = metadata !{i32 786484, i32 0, null, metadata !"threadIdx", metadata !"threadIdx", metadata !"", metadata !20, i32 29, metadata !57, i32 0, i32 1, %struct.dim3* @threadIdx} ; [ DW_TAG_variable ] [threadIdx] [line 29] [def]
!61 = metadata !{i32 786449, i32 0, i32 1, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memcpy.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", metadata !"clang version 3.2 (trunk 162409)", i1 true, i1 
!62 = metadata !{metadata !63}
!63 = metadata !{metadata !64}
!64 = metadata !{i32 786478, i32 0, metadata !65, metadata !"memcpy", metadata !"memcpy", metadata !"", metadata !65, i32 12, metadata !66, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, null, null, null, metadata !73, i32 12} ; [ DW_TAG_subpro
!65 = metadata !{i32 786473, metadata !"memcpy.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!66 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !67, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!67 = metadata !{metadata !68, metadata !68, metadata !69, metadata !71}
!68 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, null} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!69 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !70} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!70 = metadata !{i32 786470, null, metadata !"", null, i32 0, i64 0, i64 0, i64 0, i32 0, null} ; [ DW_TAG_const_type ] [line 0, size 0, align 0, offset 0] [from ]
!71 = metadata !{i32 786454, null, metadata !"size_t", metadata !65, i32 35, i64 0, i64 0, i64 0, i32 0, metadata !72} ; [ DW_TAG_typedef ] [size_t] [line 35, size 0, align 0, offset 0] [from long unsigned int]
!72 = metadata !{i32 786468, null, metadata !"long unsigned int", null, i32 0, i64 64, i64 64, i64 0, i32 0, i32 7} ; [ DW_TAG_base_type ] [long unsigned int] [line 0, size 64, align 64, offset 0, enc DW_ATE_unsigned]
!73 = metadata !{metadata !74}
!74 = metadata !{metadata !75, metadata !76, metadata !77, metadata !78, metadata !82}
!75 = metadata !{i32 786689, metadata !64, metadata !"destaddr", metadata !65, i32 16777228, metadata !68, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [destaddr] [line 12]
!76 = metadata !{i32 786689, metadata !64, metadata !"srcaddr", metadata !65, i32 33554444, metadata !69, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [srcaddr] [line 12]
!77 = metadata !{i32 786689, metadata !64, metadata !"len", metadata !65, i32 50331660, metadata !71, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [len] [line 12]
!78 = metadata !{i32 786688, metadata !79, metadata !"dest", metadata !65, i32 13, metadata !80, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [dest] [line 13]
!79 = metadata !{i32 786443, metadata !64, i32 12, i32 63, metadata !65, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memcpy.c]
!80 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !81} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from char]
!81 = metadata !{i32 786468, null, metadata !"char", null, i32 0, i64 8, i64 8, i64 0, i32 0, i32 6} ; [ DW_TAG_base_type ] [char] [line 0, size 8, align 8, offset 0, enc DW_ATE_signed_char]
!82 = metadata !{i32 786688, metadata !79, metadata !"src", metadata !65, i32 14, metadata !83, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [src] [line 14]
!83 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !84} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!84 = metadata !{i32 786470, null, metadata !"", null, i32 0, i64 0, i64 0, i64 0, i32 0, metadata !81} ; [ DW_TAG_const_type ] [line 0, size 0, align 0, offset 0] [from char]
!85 = metadata !{i32 786449, i32 0, i32 1, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memmove.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", metadata !"clang version 3.2 (trunk 162409)", i1 true, i1
!86 = metadata !{metadata !87}
!87 = metadata !{metadata !88}
!88 = metadata !{i32 786478, i32 0, metadata !89, metadata !"memmove", metadata !"memmove", metadata !"", metadata !89, i32 12, metadata !90, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, null, null, null, metadata !93, i32 12} ; [ DW_TAG_subp
!89 = metadata !{i32 786473, metadata !"memmove.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!90 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !91, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!91 = metadata !{metadata !68, metadata !68, metadata !69, metadata !92}
!92 = metadata !{i32 786454, null, metadata !"size_t", metadata !89, i32 35, i64 0, i64 0, i64 0, i32 0, metadata !72} ; [ DW_TAG_typedef ] [size_t] [line 35, size 0, align 0, offset 0] [from long unsigned int]
!93 = metadata !{metadata !94}
!94 = metadata !{metadata !95, metadata !96, metadata !97, metadata !98, metadata !100}
!95 = metadata !{i32 786689, metadata !88, metadata !"dst", metadata !89, i32 16777228, metadata !68, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [dst] [line 12]
!96 = metadata !{i32 786689, metadata !88, metadata !"src", metadata !89, i32 33554444, metadata !69, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [src] [line 12]
!97 = metadata !{i32 786689, metadata !88, metadata !"count", metadata !89, i32 50331660, metadata !92, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [count] [line 12]
!98 = metadata !{i32 786688, metadata !99, metadata !"a", metadata !89, i32 14, metadata !80, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [a] [line 14]
!99 = metadata !{i32 786443, metadata !88, i32 12, i32 57, metadata !89, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memmove.c]
!100 = metadata !{i32 786688, metadata !99, metadata !"b", metadata !89, i32 15, metadata !83, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [b] [line 15]
!101 = metadata !{i32 786449, i32 0, i32 1, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memset.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", metadata !"clang version 3.2 (trunk 162409)", i1 true, i1
!102 = metadata !{metadata !103}
!103 = metadata !{metadata !104}
!104 = metadata !{i32 786478, i32 0, metadata !105, metadata !"memset", metadata !"memset", metadata !"", metadata !105, i32 12, metadata !106, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, null, null, null, metadata !109, i32 12} ; [ DW_TAG_s
!105 = metadata !{i32 786473, metadata !"memset.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!106 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !107, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!107 = metadata !{metadata !68, metadata !68, metadata !13, metadata !108}
!108 = metadata !{i32 786454, null, metadata !"size_t", metadata !105, i32 35, i64 0, i64 0, i64 0, i32 0, metadata !72} ; [ DW_TAG_typedef ] [size_t] [line 35, size 0, align 0, offset 0] [from long unsigned int]
!109 = metadata !{metadata !110}
!110 = metadata !{metadata !111, metadata !112, metadata !113, metadata !114}
!111 = metadata !{i32 786689, metadata !104, metadata !"dst", metadata !105, i32 16777228, metadata !68, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [dst] [line 12]
!112 = metadata !{i32 786689, metadata !104, metadata !"s", metadata !105, i32 33554444, metadata !13, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [s] [line 12]
!113 = metadata !{i32 786689, metadata !104, metadata !"count", metadata !105, i32 50331660, metadata !108, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [count] [line 12]
!114 = metadata !{i32 786688, metadata !115, metadata !"a", metadata !105, i32 13, metadata !116, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [a] [line 13]
!115 = metadata !{i32 786443, metadata !104, i32 12, i32 47, metadata !105, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memset.c]
!116 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !117} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!117 = metadata !{i32 786485, null, metadata !"", null, i32 0, i64 0, i64 0, i64 0, i32 0, metadata !81} ; [ DW_TAG_volatile_type ] [line 0, size 0, align 0, offset 0] [from char]
!118 = metadata !{i32 8, i32 3, metadata !119, null}
!119 = metadata !{i32 786443, metadata !5, i32 7, i32 28, metadata !6, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Deadlock/DeadlockTest1.cu]
!120 = metadata !{i32 9, i32 5, metadata !121, null}
!121 = metadata !{i32 786443, metadata !119, i32 8, i32 24, metadata !6, i32 1} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Deadlock/DeadlockTest1.cu]
!122 = metadata !{i32 10, i32 5, metadata !121, null}
!123 = metadata !{i32 11, i32 3, metadata !121, null}
!124 = metadata !{i32 13, i32 5, metadata !125, null}
!125 = metadata !{i32 786443, metadata !119, i32 12, i32 8, metadata !6, i32 2} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Deadlock/DeadlockTest1.cu]
!126 = metadata !{i32 14, i32 5, metadata !125, null}
!127 = metadata !{i32 16, i32 1, metadata !119, null}
!128 = metadata !{i32 26, i32 6, metadata !19, null}
!129 = metadata !{i32 397, i32 116, metadata !27, null}
!130 = metadata !{i32 27, i32 6, metadata !21, null}
!131 = metadata !{i32 28, i32 6, metadata !22, null}
!132 = metadata !{i32 29, i32 6, metadata !23, null}
!133 = metadata !{i32 19, i32 11, metadata !134, null}
!134 = metadata !{i32 786443, metadata !24, i32 18, i32 12, metadata !6, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Deadlock/DeadlockTest1.cu]
!135 = metadata !{i32 21, i32 3, metadata !134, null}
!136 = metadata !{i32 397, i32 115, metadata !53, null}
!137 = metadata !{i32 397, i32 116, metadata !138, null}
!138 = metadata !{i32 786443, metadata !53, i32 397, i32 115, metadata !28, i32 1} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Deadlock//home/peng/gklee-clang/gklee/trunk/Gklee/include/cuda/ve
