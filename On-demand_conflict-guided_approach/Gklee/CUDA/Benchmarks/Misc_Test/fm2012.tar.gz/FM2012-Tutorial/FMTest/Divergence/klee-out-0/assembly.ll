; ModuleID = 'DivergenceTest'
target datalayout = "e-p:64:64:64-i1:8:8-i8:8:8-i16:16:16-i32:32:32-i64:64:64-f32:32:32-f64:64:64-v64:64:64-v128:128:128-a0:0:64-s0:64:64-f80:128:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%struct.dim3 = type { i32, i32, i32 }
%struct.CUstream_st = type opaque

@v = global [100 x i32] zeroinitializer, section "__shared__", align 16
@gridDim = global %struct.dim3 zeroinitializer, align 4
@blockIdx = global %struct.dim3 zeroinitializer, align 4
@blockDim = global %struct.dim3 zeroinitializer, align 4
@threadIdx = global %struct.dim3 zeroinitializer, align 4
@llvm.global_ctors = appending global [1 x { i32, void ()* }] [{ i32, void ()* } { i32 65535, void ()* @_GLOBAL__I_a }]
@.str = private unnamed_addr constant [22 x i8] c"klee_div_zero_check.c\00", align 1
@.str1 = private unnamed_addr constant [15 x i8] c"divide by zero\00", align 1
@.str2 = private unnamed_addr constant [8 x i8] c"div.err\00", align 1

define void @_Z10divergencev() nounwind uwtable {
entry:
  %0 = load i32* getelementptr inbounds (%struct.dim3* @threadIdx, i32 0, i32 0), align 4, !dbg !129
  %int_cast_to_i64 = zext i32 2 to i64
  call void @klee_div_zero_check(i64 %int_cast_to_i64)
  %rem = urem i32 %0, 2, !dbg !129
  %tobool = icmp ne i32 %rem, 0, !dbg !129
  %1 = load i32* getelementptr inbounds (%struct.dim3* @threadIdx, i32 0, i32 0), align 4, !dbg !131
  %idxprom = zext i32 %1 to i64, !dbg !131
  %arrayidx = getelementptr inbounds [100 x i32]* @v, i32 0, i64 %idxprom, !dbg !131
  %2 = load i32* %arrayidx, align 4, !dbg !131
  br i1 %tobool, label %if.then, label %if.else, !dbg !129

if.then:                                          ; preds = %entry
  %inc = add nsw i32 %2, 1, !dbg !131
  store i32 %inc, i32* %arrayidx, align 4, !dbg !131
  br label %if.end, !dbg !133

if.else:                                          ; preds = %entry
  %dec = add nsw i32 %2, -1, !dbg !134
  store i32 %dec, i32* %arrayidx, align 4, !dbg !134
  br label %if.end

if.end:                                           ; preds = %if.else, %if.then
  ret void, !dbg !136
}

define internal void @__cxx_global_var_init() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @gridDim, i32 1, i32 1, i32 1), !dbg !137
  ret void, !dbg !137
}

define linkonce_odr void @_ZN4dim3C1Ejjj(%struct.dim3* %this, i32 %vx, i32 %vy, i32 %vz) unnamed_addr uwtable section "__device__" align 2 {
entry:
  %this.addr = alloca %struct.dim3*, align 8
  %vx.addr = alloca i32, align 4
  %vy.addr = alloca i32, align 4
  %vz.addr = alloca i32, align 4
  store %struct.dim3* %this, %struct.dim3** %this.addr, align 8
  store i32 %vx, i32* %vx.addr, align 4
  store i32 %vy, i32* %vy.addr, align 4
  store i32 %vz, i32* %vz.addr, align 4
  %this1 = load %struct.dim3** %this.addr
  %0 = load i32* %vx.addr, align 4, !dbg !138
  %1 = load i32* %vy.addr, align 4, !dbg !138
  %2 = load i32* %vz.addr, align 4, !dbg !138
  call void @_ZN4dim3C2Ejjj(%struct.dim3* %this1, i32 %0, i32 %1, i32 %2), !dbg !138
  ret void, !dbg !138
}

define internal void @__cxx_global_var_init1() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @blockIdx, i32 1, i32 1, i32 1), !dbg !139
  ret void, !dbg !139
}

define internal void @__cxx_global_var_init2() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @blockDim, i32 1, i32 1, i32 1), !dbg !140
  ret void, !dbg !140
}

define internal void @__cxx_global_var_init3() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @threadIdx, i32 1, i32 1, i32 1), !dbg !141
  ret void, !dbg !141
}

declare i32 @cudaSetupArgument(i8*, i64, i64)

declare i32 @cudaLaunch(i8*)

define i32 @main() uwtable {
entry:
  call void @klee.ctor_stub()
  %retval = alloca i32, align 4
  %agg.tmp = alloca %struct.dim3, align 4
  %agg.tmp1 = alloca %struct.dim3, align 4
  store i32 0, i32* %retval
  call void @_ZN4dim3C1Ejjj(%struct.dim3* %agg.tmp, i32 1, i32 1, i32 1), !dbg !142
  call void @_ZN4dim3C1Ejjj(%struct.dim3* %agg.tmp1, i32 100, i32 1, i32 1), !dbg !142
  %0 = bitcast %struct.dim3* %agg.tmp to { i64, i32 }*, !dbg !142
  %1 = getelementptr { i64, i32 }* %0, i32 0, i32 0, !dbg !142
  %2 = load i64* %1, align 1, !dbg !142
  %3 = getelementptr { i64, i32 }* %0, i32 0, i32 1, !dbg !142
  %4 = load i32* %3, align 1, !dbg !142
  %5 = bitcast %struct.dim3* %agg.tmp1 to { i64, i32 }*, !dbg !142
  %6 = getelementptr { i64, i32 }* %5, i32 0, i32 0, !dbg !142
  %7 = load i64* %6, align 1, !dbg !142
  %8 = getelementptr { i64, i32 }* %5, i32 0, i32 1, !dbg !142
  %9 = load i32* %8, align 1, !dbg !142
  %call = call i32 @cudaConfigureCall(i64 %2, i32 %4, i64 %7, i32 %9, i64 0, %struct.CUstream_st* null), !dbg !142
  %tobool = icmp ne i32 %call, 0, !dbg !142
  br i1 %tobool, label %kcall.end, label %kcall.configok, !dbg !142

kcall.configok:                                   ; preds = %entry
  call void @_Z10divergencev(), !dbg !142
  br label %kcall.end, !dbg !142

kcall.end:                                        ; preds = %kcall.configok, %entry
  ret i32 0, !dbg !144
}

declare i32 @cudaConfigureCall(i64, i32, i64, i32, i64, %struct.CUstream_st*)

declare void @llvm.dbg.declare(metadata, metadata) nounwind readnone

define linkonce_odr void @_ZN4dim3C2Ejjj(%struct.dim3* %this, i32 %vx, i32 %vy, i32 %vz) unnamed_addr nounwind uwtable section "__device__" align 2 {
entry:
  %this.addr = alloca %struct.dim3*, align 8
  %vx.addr = alloca i32, align 4
  %vy.addr = alloca i32, align 4
  %vz.addr = alloca i32, align 4
  store %struct.dim3* %this, %struct.dim3** %this.addr, align 8
  store i32 %vx, i32* %vx.addr, align 4
  store i32 %vy, i32* %vy.addr, align 4
  store i32 %vz, i32* %vz.addr, align 4
  %this1 = load %struct.dim3** %this.addr
  %x = getelementptr inbounds %struct.dim3* %this1, i32 0, i32 0, !dbg !145
  %0 = load i32* %vx.addr, align 4, !dbg !145
  store i32 %0, i32* %x, align 4, !dbg !145
  %y = getelementptr inbounds %struct.dim3* %this1, i32 0, i32 1, !dbg !145
  %1 = load i32* %vy.addr, align 4, !dbg !145
  store i32 %1, i32* %y, align 4, !dbg !145
  %z = getelementptr inbounds %struct.dim3* %this1, i32 0, i32 2, !dbg !145
  %2 = load i32* %vz.addr, align 4, !dbg !145
  store i32 %2, i32* %z, align 4, !dbg !145
  ret void, !dbg !146
}

define internal void @_GLOBAL__I_a() section ".text.startup" {
entry:
  call void @__cxx_global_var_init()
  call void @__cxx_global_var_init1()
  call void @__cxx_global_var_init2()
  call void @__cxx_global_var_init3()
  ret void
}

define void @klee_div_zero_check(i64 %z) nounwind uwtable {
entry:
  %cmp = icmp eq i64 %z, 0, !dbg !148
  br i1 %cmp, label %if.then, label %if.end, !dbg !148

if.then:                                          ; preds = %entry
  tail call void @klee_report_error(i8* getelementptr inbounds ([22 x i8]* @.str, i64 0, i64 0), i32 14, i8* getelementptr inbounds ([15 x i8]* @.str1, i64 0, i64 0), i8* getelementptr inbounds ([8 x i8]* @.str2, i64 0, i64 0)) noreturn nounwind, !dbg !1
  unreachable, !dbg !150

if.end:                                           ; preds = %entry
  ret void, !dbg !151
}

declare void @klee_report_error(i8*, i32, i8*, i8*) noreturn

declare void @llvm.dbg.value(metadata, i64, metadata) nounwind readnone

define internal void @klee.ctor_stub() {
entry:
  call void @_GLOBAL__I_a()
  ret void
}

!llvm.dbg.cu = !{!0, !16, !61, !72, !96, !112}

!0 = metadata !{i32 786449, i32 0, i32 4, metadata !"DivergenceTest.cu", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Divergence", metadata !"clang version 3.2 (trunk 162409)", i1 true, i1 false, metadata !"", 
!1 = metadata !{metadata !2}
!2 = metadata !{i32 0}
!3 = metadata !{metadata !4}
!4 = metadata !{metadata !5}
!5 = metadata !{i32 786478, i32 0, metadata !6, metadata !"divergence", metadata !"divergence", metadata !"_Z10divergencev", metadata !6, i32 7, metadata !7, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void ()* @_Z10divergencev, null, null,
!6 = metadata !{i32 786473, metadata !"DivergenceTest.cu", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Divergence", null} ; [ DW_TAG_file_type ]
!7 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !8, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!8 = metadata !{null}
!9 = metadata !{metadata !10}
!10 = metadata !{metadata !11}
!11 = metadata !{i32 786484, i32 0, null, metadata !"v", metadata !"v", metadata !"", metadata !6, i32 5, metadata !12, i32 0, i32 1, [100 x i32]* @v} ; [ DW_TAG_variable ] [v] [line 5] [def]
!12 = metadata !{i32 786433, null, metadata !"", null, i32 0, i64 3200, i64 32, i32 0, i32 0, metadata !13, metadata !14, i32 0, i32 0} ; [ DW_TAG_array_type ] [line 0, size 3200, align 32, offset 0] [from int]
!13 = metadata !{i32 786468, null, metadata !"int", null, i32 0, i64 32, i64 32, i64 0, i32 0, i32 5} ; [ DW_TAG_base_type ] [int] [line 0, size 32, align 32, offset 0, enc DW_ATE_signed]
!14 = metadata !{metadata !15}
!15 = metadata !{i32 786465, i64 0, i64 99}       ; [ DW_TAG_subrange_type ] [0, 99]
!16 = metadata !{i32 786449, i32 0, i32 4, metadata !"DivergenceTest.cu", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Divergence", metadata !"clang version 3.2 (trunk 162409)", i1 true, i1 false, metadata !"",
!17 = metadata !{metadata !18}
!18 = metadata !{metadata !19, metadata !21, metadata !22, metadata !23, metadata !5, metadata !24, metadata !27, metadata !53}
!19 = metadata !{i32 786478, i32 0, metadata !20, metadata !"__cxx_global_var_init", metadata !"__cxx_global_var_init", metadata !"", metadata !20, i32 26, metadata !7, i1 true, i1 true, i32 0, i32 0, null, i32 256, i1 false, void ()* @__cxx_global_var_i
!20 = metadata !{i32 786473, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/include/klee/gklee.h", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Divergence", null} ; [ DW_TAG_file_type ]
!21 = metadata !{i32 786478, i32 0, metadata !20, metadata !"__cxx_global_var_init1", metadata !"__cxx_global_var_init1", metadata !"", metadata !20, i32 27, metadata !7, i1 true, i1 true, i32 0, i32 0, null, i32 256, i1 false, void ()* @__cxx_global_var
!22 = metadata !{i32 786478, i32 0, metadata !20, metadata !"__cxx_global_var_init2", metadata !"__cxx_global_var_init2", metadata !"", metadata !20, i32 28, metadata !7, i1 true, i1 true, i32 0, i32 0, null, i32 256, i1 false, void ()* @__cxx_global_var
!23 = metadata !{i32 786478, i32 0, metadata !20, metadata !"__cxx_global_var_init3", metadata !"__cxx_global_var_init3", metadata !"", metadata !20, i32 29, metadata !7, i1 true, i1 true, i32 0, i32 0, null, i32 256, i1 false, void ()* @__cxx_global_var
!24 = metadata !{i32 786478, i32 0, metadata !6, metadata !"main", metadata !"main", metadata !"", metadata !6, i32 16, metadata !25, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, i32 ()* @main, null, null, metadata !1, i32 16} ; [ DW_TAG_sub
!25 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !26, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!26 = metadata !{metadata !13}
!27 = metadata !{i32 786478, i32 0, null, metadata !"dim3", metadata !"dim3", metadata !"_ZN4dim3C1Ejjj", metadata !28, i32 397, metadata !29, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (%struct.dim3*, i32, i32, i32)* @_ZN4dim3C1Ejjj,
!28 = metadata !{i32 786473, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/include/cuda/vector_types.h", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Divergence", null} ; [ DW_TAG_file_type ]
!29 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !30, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!30 = metadata !{null, metadata !31, metadata !35, metadata !35, metadata !35}
!31 = metadata !{i32 786447, i32 0, metadata !"", i32 0, i32 0, i64 64, i64 64, i64 0, i32 64, metadata !32} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from dim3]
!32 = metadata !{i32 786434, null, metadata !"dim3", metadata !28, i32 393, i64 96, i64 32, i32 0, i32 0, null, metadata !33, i32 0, null, null} ; [ DW_TAG_class_type ] [dim3] [line 393, size 96, align 32, offset 0] [from ]
!33 = metadata !{metadata !34, metadata !36, metadata !37, metadata !38, metadata !41, metadata !50}
!34 = metadata !{i32 786445, metadata !32, metadata !"x", metadata !28, i32 395, i64 32, i64 32, i64 0, i32 0, metadata !35} ; [ DW_TAG_member ] [x] [line 395, size 32, align 32, offset 0] [from unsigned int]
!35 = metadata !{i32 786468, null, metadata !"unsigned int", null, i32 0, i64 32, i64 32, i64 0, i32 0, i32 7} ; [ DW_TAG_base_type ] [unsigned int] [line 0, size 32, align 32, offset 0, enc DW_ATE_unsigned]
!36 = metadata !{i32 786445, metadata !32, metadata !"y", metadata !28, i32 395, i64 32, i64 32, i64 32, i32 0, metadata !35} ; [ DW_TAG_member ] [y] [line 395, size 32, align 32, offset 32] [from unsigned int]
!37 = metadata !{i32 786445, metadata !32, metadata !"z", metadata !28, i32 395, i64 32, i64 32, i64 64, i32 0, metadata !35} ; [ DW_TAG_member ] [z] [line 395, size 32, align 32, offset 64] [from unsigned int]
!38 = metadata !{i32 786478, i32 0, metadata !32, metadata !"dim3", metadata !"dim3", metadata !"", metadata !28, i32 397, metadata !29, i1 false, i1 false, i32 0, i32 0, null, i32 256, i1 false, null, null, i32 0, metadata !39, i32 397} ; [ DW_TAG_subpr
!39 = metadata !{metadata !40}
!40 = metadata !{i32 786468}                      ; [ DW_TAG_base_type ] [line 0, size 0, align 0, offset 0]
!41 = metadata !{i32 786478, i32 0, metadata !32, metadata !"dim3", metadata !"dim3", metadata !"", metadata !28, i32 398, metadata !42, i1 false, i1 false, i32 0, i32 0, null, i32 256, i1 false, null, null, i32 0, metadata !39, i32 398} ; [ DW_TAG_subpr
!42 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !43, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!43 = metadata !{null, metadata !31, metadata !44}
!44 = metadata !{i32 786454, null, metadata !"uint3", metadata !28, i32 359, i64 0, i64 0, i64 0, i32 0, metadata !45} ; [ DW_TAG_typedef ] [uint3] [line 359, size 0, align 0, offset 0] [from uint3]
!45 = metadata !{i32 786434, null, metadata !"uint3", metadata !28, i32 186, i64 96, i64 32, i32 0, i32 0, null, metadata !46, i32 0, null, null} ; [ DW_TAG_class_type ] [uint3] [line 186, size 96, align 32, offset 0] [from ]
!46 = metadata !{metadata !47, metadata !48, metadata !49}
!47 = metadata !{i32 786445, metadata !45, metadata !"x", metadata !28, i32 188, i64 32, i64 32, i64 0, i32 0, metadata !35} ; [ DW_TAG_member ] [x] [line 188, size 32, align 32, offset 0] [from unsigned int]
!48 = metadata !{i32 786445, metadata !45, metadata !"y", metadata !28, i32 188, i64 32, i64 32, i64 32, i32 0, metadata !35} ; [ DW_TAG_member ] [y] [line 188, size 32, align 32, offset 32] [from unsigned int]
!49 = metadata !{i32 786445, metadata !45, metadata !"z", metadata !28, i32 188, i64 32, i64 32, i64 64, i32 0, metadata !35} ; [ DW_TAG_member ] [z] [line 188, size 32, align 32, offset 64] [from unsigned int]
!50 = metadata !{i32 786478, i32 0, metadata !32, metadata !"operator uint3", metadata !"operator uint3", metadata !"_ZN4dim3cv5uint3Ev", metadata !28, i32 399, metadata !51, i1 false, i1 false, i32 0, i32 0, null, i32 256, i1 false, null, null, i32 0, m
!51 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !52, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!52 = metadata !{metadata !44, metadata !31}
!53 = metadata !{i32 786478, i32 0, null, metadata !"dim3", metadata !"dim3", metadata !"_ZN4dim3C2Ejjj", metadata !28, i32 397, metadata !29, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (%struct.dim3*, i32, i32, i32)* @_ZN4dim3C2Ejjj,
!54 = metadata !{metadata !55}
!55 = metadata !{metadata !56, metadata !58, metadata !59, metadata !60}
!56 = metadata !{i32 786484, i32 0, null, metadata !"gridDim", metadata !"gridDim", metadata !"", metadata !20, i32 26, metadata !57, i32 0, i32 1, %struct.dim3* @gridDim} ; [ DW_TAG_variable ] [gridDim] [line 26] [def]
!57 = metadata !{i32 786454, null, metadata !"dim3", metadata !20, i32 403, i64 0, i64 0, i64 0, i32 0, metadata !32} ; [ DW_TAG_typedef ] [dim3] [line 403, size 0, align 0, offset 0] [from dim3]
!58 = metadata !{i32 786484, i32 0, null, metadata !"blockIdx", metadata !"blockIdx", metadata !"", metadata !20, i32 27, metadata !57, i32 0, i32 1, %struct.dim3* @blockIdx} ; [ DW_TAG_variable ] [blockIdx] [line 27] [def]
!59 = metadata !{i32 786484, i32 0, null, metadata !"blockDim", metadata !"blockDim", metadata !"", metadata !20, i32 28, metadata !57, i32 0, i32 1, %struct.dim3* @blockDim} ; [ DW_TAG_variable ] [blockDim] [line 28] [def]
!60 = metadata !{i32 786484, i32 0, null, metadata !"threadIdx", metadata !"threadIdx", metadata !"", metadata !20, i32 29, metadata !57, i32 0, i32 1, %struct.dim3* @threadIdx} ; [ DW_TAG_variable ] [threadIdx] [line 29] [def]
!61 = metadata !{i32 786449, i32 0, i32 1, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/klee_div_zero_check.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", metadata !"clang version 3.2 (trunk 162409)",
!62 = metadata !{metadata !63}
!63 = metadata !{metadata !64}
!64 = metadata !{i32 786478, i32 0, metadata !65, metadata !"klee_div_zero_check", metadata !"klee_div_zero_check", metadata !"", metadata !65, i32 12, metadata !66, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, void (i64)* @klee_div_zero_chec
!65 = metadata !{i32 786473, metadata !"klee_div_zero_check.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!66 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !67, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!67 = metadata !{null, metadata !68}
!68 = metadata !{i32 786468, null, metadata !"long long int", null, i32 0, i64 64, i64 64, i64 0, i32 0, i32 5} ; [ DW_TAG_base_type ] [long long int] [line 0, size 64, align 64, offset 0, enc DW_ATE_signed]
!69 = metadata !{metadata !70}
!70 = metadata !{metadata !71}
!71 = metadata !{i32 786689, metadata !64, metadata !"z", metadata !65, i32 16777228, metadata !68, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [z] [line 12]
!72 = metadata !{i32 786449, i32 0, i32 1, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memcpy.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", metadata !"clang version 3.2 (trunk 162409)", i1 true, i1 
!73 = metadata !{metadata !74}
!74 = metadata !{metadata !75}
!75 = metadata !{i32 786478, i32 0, metadata !76, metadata !"memcpy", metadata !"memcpy", metadata !"", metadata !76, i32 12, metadata !77, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, null, null, null, metadata !84, i32 12} ; [ DW_TAG_subpro
!76 = metadata !{i32 786473, metadata !"memcpy.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!77 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !78, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!78 = metadata !{metadata !79, metadata !79, metadata !80, metadata !82}
!79 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, null} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!80 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !81} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!81 = metadata !{i32 786470, null, metadata !"", null, i32 0, i64 0, i64 0, i64 0, i32 0, null} ; [ DW_TAG_const_type ] [line 0, size 0, align 0, offset 0] [from ]
!82 = metadata !{i32 786454, null, metadata !"size_t", metadata !76, i32 35, i64 0, i64 0, i64 0, i32 0, metadata !83} ; [ DW_TAG_typedef ] [size_t] [line 35, size 0, align 0, offset 0] [from long unsigned int]
!83 = metadata !{i32 786468, null, metadata !"long unsigned int", null, i32 0, i64 64, i64 64, i64 0, i32 0, i32 7} ; [ DW_TAG_base_type ] [long unsigned int] [line 0, size 64, align 64, offset 0, enc DW_ATE_unsigned]
!84 = metadata !{metadata !85}
!85 = metadata !{metadata !86, metadata !87, metadata !88, metadata !89, metadata !93}
!86 = metadata !{i32 786689, metadata !75, metadata !"destaddr", metadata !76, i32 16777228, metadata !79, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [destaddr] [line 12]
!87 = metadata !{i32 786689, metadata !75, metadata !"srcaddr", metadata !76, i32 33554444, metadata !80, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [srcaddr] [line 12]
!88 = metadata !{i32 786689, metadata !75, metadata !"len", metadata !76, i32 50331660, metadata !82, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [len] [line 12]
!89 = metadata !{i32 786688, metadata !90, metadata !"dest", metadata !76, i32 13, metadata !91, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [dest] [line 13]
!90 = metadata !{i32 786443, metadata !75, i32 12, i32 63, metadata !76, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memcpy.c]
!91 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !92} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from char]
!92 = metadata !{i32 786468, null, metadata !"char", null, i32 0, i64 8, i64 8, i64 0, i32 0, i32 6} ; [ DW_TAG_base_type ] [char] [line 0, size 8, align 8, offset 0, enc DW_ATE_signed_char]
!93 = metadata !{i32 786688, metadata !90, metadata !"src", metadata !76, i32 14, metadata !94, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [src] [line 14]
!94 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !95} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!95 = metadata !{i32 786470, null, metadata !"", null, i32 0, i64 0, i64 0, i64 0, i32 0, metadata !92} ; [ DW_TAG_const_type ] [line 0, size 0, align 0, offset 0] [from char]
!96 = metadata !{i32 786449, i32 0, i32 1, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memmove.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", metadata !"clang version 3.2 (trunk 162409)", i1 true, i1
!97 = metadata !{metadata !98}
!98 = metadata !{metadata !99}
!99 = metadata !{i32 786478, i32 0, metadata !100, metadata !"memmove", metadata !"memmove", metadata !"", metadata !100, i32 12, metadata !101, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, null, null, null, metadata !104, i32 12} ; [ DW_TAG_
!100 = metadata !{i32 786473, metadata !"memmove.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!101 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !102, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!102 = metadata !{metadata !79, metadata !79, metadata !80, metadata !103}
!103 = metadata !{i32 786454, null, metadata !"size_t", metadata !100, i32 35, i64 0, i64 0, i64 0, i32 0, metadata !83} ; [ DW_TAG_typedef ] [size_t] [line 35, size 0, align 0, offset 0] [from long unsigned int]
!104 = metadata !{metadata !105}
!105 = metadata !{metadata !106, metadata !107, metadata !108, metadata !109, metadata !111}
!106 = metadata !{i32 786689, metadata !99, metadata !"dst", metadata !100, i32 16777228, metadata !79, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [dst] [line 12]
!107 = metadata !{i32 786689, metadata !99, metadata !"src", metadata !100, i32 33554444, metadata !80, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [src] [line 12]
!108 = metadata !{i32 786689, metadata !99, metadata !"count", metadata !100, i32 50331660, metadata !103, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [count] [line 12]
!109 = metadata !{i32 786688, metadata !110, metadata !"a", metadata !100, i32 14, metadata !91, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [a] [line 14]
!110 = metadata !{i32 786443, metadata !99, i32 12, i32 57, metadata !100, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memmove.c]
!111 = metadata !{i32 786688, metadata !110, metadata !"b", metadata !100, i32 15, metadata !94, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [b] [line 15]
!112 = metadata !{i32 786449, i32 0, i32 1, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memset.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", metadata !"clang version 3.2 (trunk 162409)", i1 true, i1
!113 = metadata !{metadata !114}
!114 = metadata !{metadata !115}
!115 = metadata !{i32 786478, i32 0, metadata !116, metadata !"memset", metadata !"memset", metadata !"", metadata !116, i32 12, metadata !117, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, null, null, null, metadata !120, i32 12} ; [ DW_TAG_s
!116 = metadata !{i32 786473, metadata !"memset.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!117 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !118, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!118 = metadata !{metadata !79, metadata !79, metadata !13, metadata !119}
!119 = metadata !{i32 786454, null, metadata !"size_t", metadata !116, i32 35, i64 0, i64 0, i64 0, i32 0, metadata !83} ; [ DW_TAG_typedef ] [size_t] [line 35, size 0, align 0, offset 0] [from long unsigned int]
!120 = metadata !{metadata !121}
!121 = metadata !{metadata !122, metadata !123, metadata !124, metadata !125}
!122 = metadata !{i32 786689, metadata !115, metadata !"dst", metadata !116, i32 16777228, metadata !79, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [dst] [line 12]
!123 = metadata !{i32 786689, metadata !115, metadata !"s", metadata !116, i32 33554444, metadata !13, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [s] [line 12]
!124 = metadata !{i32 786689, metadata !115, metadata !"count", metadata !116, i32 50331660, metadata !119, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [count] [line 12]
!125 = metadata !{i32 786688, metadata !126, metadata !"a", metadata !116, i32 13, metadata !127, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [a] [line 13]
!126 = metadata !{i32 786443, metadata !115, i32 12, i32 47, metadata !116, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memset.c]
!127 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !128} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!128 = metadata !{i32 786485, null, metadata !"", null, i32 0, i64 0, i64 0, i64 0, i32 0, metadata !92} ; [ DW_TAG_volatile_type ] [line 0, size 0, align 0, offset 0] [from char]
!129 = metadata !{i32 8, i32 3, metadata !130, null}
!130 = metadata !{i32 786443, metadata !5, i32 7, i32 30, metadata !6, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Divergence/DivergenceTest.cu]
!131 = metadata !{i32 9, i32 5, metadata !132, null}
!132 = metadata !{i32 786443, metadata !130, i32 8, i32 23, metadata !6, i32 1} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Divergence/DivergenceTest.cu]
!133 = metadata !{i32 10, i32 3, metadata !132, null}
!134 = metadata !{i32 12, i32 5, metadata !135, null}
!135 = metadata !{i32 786443, metadata !130, i32 11, i32 8, metadata !6, i32 2} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Divergence/DivergenceTest.cu]
!136 = metadata !{i32 14, i32 1, metadata !130, null}
!137 = metadata !{i32 26, i32 6, metadata !19, null}
!138 = metadata !{i32 397, i32 116, metadata !27, null}
!139 = metadata !{i32 27, i32 6, metadata !21, null}
!140 = metadata !{i32 28, i32 6, metadata !22, null}
!141 = metadata !{i32 29, i32 6, metadata !23, null}
!142 = metadata !{i32 17, i32 13, metadata !143, null}
!143 = metadata !{i32 786443, metadata !24, i32 16, i32 12, metadata !6, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Divergence/DivergenceTest.cu]
!144 = metadata !{i32 19, i32 3, metadata !143, null}
!145 = metadata !{i32 397, i32 115, metadata !53, null}
!146 = metadata !{i32 397, i32 116, metadata !147, null}
!147 = metadata !{i32 786443, metadata !53, i32 397, i32 115, metadata !28, i32 1} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Divergence//home/peng/gklee-clang/gklee/trunk/Gklee/include/cuda/
!148 = metadata !{i32 13, i32 3, metadata !149, null}
!149 = metadata !{i32 786443, metadata !64, i32 12, i32 39, metadata !65, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/klee_div_zero_check.c]
!150 = metadata !{i32 14, i32 5, metadata !149, null}
!151 = metadata !{i32 15, i32 1, metadata !149, null}
