; ModuleID = 'Warp_Dependent_Race'
target datalayout = "e-p:64:64:64-i1:8:8-i8:8:8-i16:16:16-i32:32:32-i64:64:64-f32:32:32-f64:64:64-v64:64:64-v128:128:128-a0:0:64-s0:64:64-f80:128:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%struct.uint3 = type { i32, i32, i32 }
%struct.CUstream_st = type opaque

@gridDim = global %struct.uint3 zeroinitializer, align 4
@blockIdx = global %struct.uint3 zeroinitializer, align 4
@blockDim = global %struct.uint3 zeroinitializer, align 4
@threadIdx = global %struct.uint3 zeroinitializer, align 4
@llvm.global_ctors = appending global [1 x { i32, void ()* }] [{ i32, void ()* } { i32 65535, void ()* @_GLOBAL__I_a }]

define void @_Z6kernelPiS_(i32* %x, i32* %y) nounwind uwtable {
entry:
  %x.addr = alloca i32*, align 8
  %y.addr = alloca i32*, align 8
  %__cuda_local_var_16173_7_non_const_index = alloca i32, align 4
  store i32* %x, i32** %x.addr, align 8
  store i32* %y, i32** %y.addr, align 8
  %0 = load i32* getelementptr inbounds (%struct.uint3* @threadIdx, i32 0, i32 0), align 4, !dbg !234
  store i32 %0, i32* %__cuda_local_var_16173_7_non_const_index, align 4, !dbg !234
  %1 = load i32* %__cuda_local_var_16173_7_non_const_index, align 4, !dbg !237
  %idxprom = sext i32 %1 to i64, !dbg !237
  %2 = load i32** %x.addr, align 8, !dbg !237
  %arrayidx = getelementptr inbounds i32* %2, i64 %idxprom, !dbg !237
  %3 = load i32* %arrayidx, align 4, !dbg !237
  %4 = load i32* %__cuda_local_var_16173_7_non_const_index, align 4, !dbg !237
  %idxprom1 = sext i32 %4 to i64, !dbg !237
  %5 = load i32** %y.addr, align 8, !dbg !237
  %arrayidx2 = getelementptr inbounds i32* %5, i64 %idxprom1, !dbg !237
  %6 = load i32* %arrayidx2, align 4, !dbg !237
  %add = add nsw i32 %3, %6, !dbg !237
  %7 = load i32* %__cuda_local_var_16173_7_non_const_index, align 4, !dbg !237
  %idxprom3 = sext i32 %7 to i64, !dbg !237
  %8 = load i32** %y.addr, align 8, !dbg !237
  %arrayidx4 = getelementptr inbounds i32* %8, i64 %idxprom3, !dbg !237
  store i32 %add, i32* %arrayidx4, align 4, !dbg !237
  %9 = load i32* %__cuda_local_var_16173_7_non_const_index, align 4, !dbg !238
  %cmp = icmp ne i32 %9, 63, !dbg !238
  %10 = load i32* %__cuda_local_var_16173_7_non_const_index, align 4, !dbg !238
  %cmp5 = icmp ne i32 %10, 31, !dbg !238
  %or.cond = and i1 %cmp, %cmp5, !dbg !238
  br i1 %or.cond, label %if.then, label %if.end, !dbg !238

if.then:                                          ; preds = %entry
  %11 = load i32* %__cuda_local_var_16173_7_non_const_index, align 4, !dbg !239
  %add6 = add nsw i32 %11, 1, !dbg !239
  %idxprom7 = sext i32 %add6 to i64, !dbg !239
  %12 = load i32** %y.addr, align 8, !dbg !239
  %arrayidx8 = getelementptr inbounds i32* %12, i64 %idxprom7, !dbg !239
  store i32 1111, i32* %arrayidx8, align 4, !dbg !239
  br label %if.end, !dbg !241

if.end:                                           ; preds = %if.then, %entry
  ret void, !dbg !242
}

declare void @llvm.dbg.declare(metadata, metadata) nounwind readnone

define internal void @__cxx_global_var_init() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.uint3* @gridDim, i32 1, i32 1, i32 1), !dbg !243
  ret void, !dbg !243
}

define linkonce_odr void @_ZN4dim3C1Ejjj(%struct.uint3* %this, i32 %vx, i32 %vy, i32 %vz) unnamed_addr uwtable section "__device__" align 2 {
entry:
  %this.addr = alloca %struct.uint3*, align 8
  %vx.addr = alloca i32, align 4
  %vy.addr = alloca i32, align 4
  %vz.addr = alloca i32, align 4
  store %struct.uint3* %this, %struct.uint3** %this.addr, align 8
  store i32 %vx, i32* %vx.addr, align 4
  store i32 %vy, i32* %vy.addr, align 4
  store i32 %vz, i32* %vz.addr, align 4
  %this1 = load %struct.uint3** %this.addr
  %0 = load i32* %vx.addr, align 4, !dbg !244
  %1 = load i32* %vy.addr, align 4, !dbg !244
  %2 = load i32* %vz.addr, align 4, !dbg !244
  call void @_ZN4dim3C2Ejjj(%struct.uint3* %this1, i32 %0, i32 %1, i32 %2), !dbg !244
  ret void, !dbg !244
}

define internal void @__cxx_global_var_init1() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.uint3* @blockIdx, i32 1, i32 1, i32 1), !dbg !245
  ret void, !dbg !245
}

define internal void @__cxx_global_var_init2() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.uint3* @blockDim, i32 1, i32 1, i32 1), !dbg !246
  ret void, !dbg !246
}

define internal void @__cxx_global_var_init3() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.uint3* @threadIdx, i32 1, i32 1, i32 1), !dbg !247
  ret void, !dbg !247
}

declare i32 @cudaSetupArgument(i8*, i64, i64)

declare i32 @cudaLaunch(i8*)

define i32 @main() uwtable {
entry:
  call void @klee.ctor_stub()
  %retval = alloca i32, align 4
  %vector_hx = alloca i32*, align 8
  %vector_dx = alloca i32*, align 8
  %vector_hy = alloca i32*, align 8
  %vector_dy = alloca i32*, align 8
  %i = alloca i32, align 4
  %agg.tmp = alloca %struct.uint3, align 4
  %agg.tmp8 = alloca %struct.uint3, align 4
  store i32 0, i32* %retval
  %0 = bitcast i32** %vector_dx to i8**, !dbg !248
  %call = call i32 @cudaMalloc(i8** %0, i64 256), !dbg !248
  %1 = bitcast i32** %vector_dy to i8**, !dbg !250
  %call1 = call i32 @cudaMalloc(i8** %1, i64 256), !dbg !250
  %call2 = call noalias i8* @_Znam(i64 256), !dbg !251
  %2 = bitcast i8* %call2 to i32*, !dbg !251
  store i32* %2, i32** %vector_hx, align 8, !dbg !251
  %call3 = call noalias i8* @_Znam(i64 256), !dbg !252
  %3 = bitcast i8* %call3 to i32*, !dbg !252
  store i32* %3, i32** %vector_hy, align 8, !dbg !252
  store i32 0, i32* %i, align 4, !dbg !253
  br label %for.cond, !dbg !253

for.cond:                                         ; preds = %for.body, %entry
  %4 = load i32* %i, align 4, !dbg !253
  %cmp = icmp slt i32 %4, 64, !dbg !253
  br i1 %cmp, label %for.body, label %for.end, !dbg !253

for.body:                                         ; preds = %for.cond
  %5 = load i32* %i, align 4, !dbg !255
  %6 = load i32* %i, align 4, !dbg !255
  %idxprom = sext i32 %6 to i64, !dbg !255
  %7 = load i32** %vector_hy, align 8, !dbg !255
  %arrayidx = getelementptr inbounds i32* %7, i64 %idxprom, !dbg !255
  store i32 %5, i32* %arrayidx, align 4, !dbg !255
  %8 = load i32* %i, align 4, !dbg !255
  %idxprom4 = sext i32 %8 to i64, !dbg !255
  %9 = load i32** %vector_hx, align 8, !dbg !255
  %arrayidx5 = getelementptr inbounds i32* %9, i64 %idxprom4, !dbg !255
  store i32 %5, i32* %arrayidx5, align 4, !dbg !255
  %10 = load i32* %i, align 4, !dbg !257
  %inc = add nsw i32 %10, 1, !dbg !257
  store i32 %inc, i32* %i, align 4, !dbg !257
  br label %for.cond, !dbg !257

for.end:                                          ; preds = %for.cond
  %11 = load i32** %vector_dx, align 8, !dbg !258
  %12 = bitcast i32* %11 to i8*, !dbg !258
  %13 = load i32** %vector_hx, align 8, !dbg !258
  %14 = bitcast i32* %13 to i8*, !dbg !258
  %call6 = call i32 @cudaMemcpy(i8* %12, i8* %14, i64 256, i32 1), !dbg !258
  %15 = load i32** %vector_dy, align 8, !dbg !259
  %16 = bitcast i32* %15 to i8*, !dbg !259
  %17 = load i32** %vector_hy, align 8, !dbg !259
  %18 = bitcast i32* %17 to i8*, !dbg !259
  %call7 = call i32 @cudaMemcpy(i8* %16, i8* %18, i64 256, i32 1), !dbg !259
  call void @_ZN4dim3C1Ejjj(%struct.uint3* %agg.tmp, i32 1, i32 1, i32 1), !dbg !260
  call void @_ZN4dim3C1Ejjj(%struct.uint3* %agg.tmp8, i32 64, i32 1, i32 1), !dbg !260
  %19 = bitcast %struct.uint3* %agg.tmp to { i64, i32 }*, !dbg !260
  %20 = getelementptr { i64, i32 }* %19, i32 0, i32 0, !dbg !260
  %21 = load i64* %20, align 1, !dbg !260
  %22 = getelementptr { i64, i32 }* %19, i32 0, i32 1, !dbg !260
  %23 = load i32* %22, align 1, !dbg !260
  %24 = bitcast %struct.uint3* %agg.tmp8 to { i64, i32 }*, !dbg !260
  %25 = getelementptr { i64, i32 }* %24, i32 0, i32 0, !dbg !260
  %26 = load i64* %25, align 1, !dbg !260
  %27 = getelementptr { i64, i32 }* %24, i32 0, i32 1, !dbg !260
  %28 = load i32* %27, align 1, !dbg !260
  %call9 = call i32 @cudaConfigureCall(i64 %21, i32 %23, i64 %26, i32 %28, i64 0, %struct.CUstream_st* null), !dbg !260
  %tobool = icmp ne i32 %call9, 0, !dbg !260
  br i1 %tobool, label %kcall.end, label %kcall.configok, !dbg !260

kcall.configok:                                   ; preds = %for.end
  %29 = load i32** %vector_dx, align 8, !dbg !260
  %30 = load i32** %vector_dy, align 8, !dbg !260
  call void @_Z6kernelPiS_(i32* %29, i32* %30), !dbg !260
  br label %kcall.end, !dbg !260

kcall.end:                                        ; preds = %kcall.configok, %for.end
  %31 = load i32** %vector_hy, align 8, !dbg !261
  %32 = bitcast i32* %31 to i8*, !dbg !261
  %33 = load i32** %vector_dy, align 8, !dbg !261
  %34 = bitcast i32* %33 to i8*, !dbg !261
  %call10 = call i32 @cudaMemcpy(i8* %32, i8* %34, i64 256, i32 2), !dbg !261
  %35 = load i32** %vector_hx, align 8, !dbg !262
  %isnull = icmp eq i32* %35, null, !dbg !262
  br i1 %isnull, label %delete.end, label %delete.notnull, !dbg !262

delete.notnull:                                   ; preds = %kcall.end
  %36 = bitcast i32* %35 to i8*, !dbg !262
  call void @_ZdlPv(i8* %36) nounwind, !dbg !262
  br label %delete.end, !dbg !262

delete.end:                                       ; preds = %delete.notnull, %kcall.end
  %37 = load i32** %vector_hy, align 8, !dbg !263
  %isnull11 = icmp eq i32* %37, null, !dbg !263
  br i1 %isnull11, label %delete.end13, label %delete.notnull12, !dbg !263

delete.notnull12:                                 ; preds = %delete.end
  %38 = bitcast i32* %37 to i8*, !dbg !263
  call void @_ZdlPv(i8* %38) nounwind, !dbg !263
  br label %delete.end13, !dbg !263

delete.end13:                                     ; preds = %delete.notnull12, %delete.end
  %39 = load i32** %vector_dx, align 8, !dbg !264
  %40 = bitcast i32* %39 to i8*, !dbg !264
  %call14 = call i32 @cudaFree(i8* %40), !dbg !264
  %41 = load i32** %vector_dy, align 8, !dbg !265
  %42 = bitcast i32* %41 to i8*, !dbg !265
  %call15 = call i32 @cudaFree(i8* %42), !dbg !265
  ret i32 0, !dbg !266
}

declare noalias i8* @_Znam(i64)

declare i32 @cudaConfigureCall(i64, i32, i64, i32, i64, %struct.CUstream_st*)

declare void @_ZdlPv(i8*) nounwind

define linkonce_odr void @_ZN4dim3C2Ejjj(%struct.uint3* %this, i32 %vx, i32 %vy, i32 %vz) unnamed_addr nounwind uwtable section "__device__" align 2 {
entry:
  %this.addr = alloca %struct.uint3*, align 8
  %vx.addr = alloca i32, align 4
  %vy.addr = alloca i32, align 4
  %vz.addr = alloca i32, align 4
  store %struct.uint3* %this, %struct.uint3** %this.addr, align 8
  store i32 %vx, i32* %vx.addr, align 4
  store i32 %vy, i32* %vy.addr, align 4
  store i32 %vz, i32* %vz.addr, align 4
  %this1 = load %struct.uint3** %this.addr
  %x = getelementptr inbounds %struct.uint3* %this1, i32 0, i32 0, !dbg !267
  %0 = load i32* %vx.addr, align 4, !dbg !267
  store i32 %0, i32* %x, align 4, !dbg !267
  %y = getelementptr inbounds %struct.uint3* %this1, i32 0, i32 1, !dbg !267
  %1 = load i32* %vy.addr, align 4, !dbg !267
  store i32 %1, i32* %y, align 4, !dbg !267
  %z = getelementptr inbounds %struct.uint3* %this1, i32 0, i32 2, !dbg !267
  %2 = load i32* %vz.addr, align 4, !dbg !267
  store i32 %2, i32* %z, align 4, !dbg !267
  ret void, !dbg !268
}

define internal void @_GLOBAL__I_a() section ".text.startup" {
entry:
  call void @__cxx_global_var_init()
  call void @__cxx_global_var_init1()
  call void @__cxx_global_var_init2()
  call void @__cxx_global_var_init3()
  ret void
}

define i32 @cudaMalloc(i8** nocapture %devPtr, i64 %size) nounwind uwtable {
entry:
  %call = tail call i32 (...)* @__set_device() nounwind, !dbg !270
  %call1 = tail call noalias i8* @malloc(i64 %size) nounwind, !dbg !272
  store i8* %call1, i8** %devPtr, align 8, !dbg !272, !tbaa !273
  %call2 = tail call i32 (...)* @__clear_device() nounwind, !dbg !276
  ret i32 0, !dbg !277
}

declare i32 @__set_device(...)

declare noalias i8* @malloc(i64) nounwind

declare i32 @__clear_device(...)

define i32 @cudaMemcpy(i8* %dst, i8* %src, i64 %count, i32 %kind) nounwind uwtable {
entry:
  %call = tail call i32 (...)* bitcast (i8* (i8*, i8*, i64)* @memcpy to i32 (...)*)(i8* %dst, i8* %src, i64 %count) nounwind, !dbg !278
  ret i32 0, !dbg !280
}

define i32 @cudaMemset(i8* %devPtr, i32 %value, i64 %count) nounwind uwtable {
entry:
  %call = tail call i32 (...)* bitcast (i8* (i8*, i32, i64)* @memset to i32 (...)*)(i8* %devPtr, i32 %value, i64 %count) nounwind, !dbg !281
  ret i32 0, !dbg !283
}

define i32 @cudaFree(i8* nocapture %devPtr) nounwind uwtable {
entry:
  tail call void @free(i8* %devPtr) nounwind, !dbg !284
  ret i32 0, !dbg !286
}

declare void @free(i8* nocapture) nounwind

declare void @llvm.dbg.value(metadata, i64, metadata) nounwind readnone

define i8* @memcpy(i8* %destaddr, i8* nocapture %srcaddr, i64 %len) nounwind uwtable {
entry:
  %cmp2 = icmp eq i64 %len, 0, !dbg !287
  br i1 %cmp2, label %while.end, label %while.body, !dbg !287

while.body:                                       ; preds = %while.body, %entry
  %src.05 = phi i8* [ %incdec.ptr, %while.body ], [ %srcaddr, %entry ]
  %dest.04 = phi i8* [ %incdec.ptr1, %while.body ], [ %destaddr, %entry ]
  %len.addr.03 = phi i64 [ %dec, %while.body ], [ %len, %entry ]
  %dec = add i64 %len.addr.03, -1, !dbg !287
  %incdec.ptr = getelementptr inbounds i8* %src.05, i64 1, !dbg !288
  %0 = load i8* %src.05, align 1, !dbg !288, !tbaa !274
  %incdec.ptr1 = getelementptr inbounds i8* %dest.04, i64 1, !dbg !288
  store i8 %0, i8* %dest.04, align 1, !dbg !288, !tbaa !274
  %cmp = icmp eq i64 %dec, 0, !dbg !287
  br i1 %cmp, label %while.end, label %while.body, !dbg !287

while.end:                                        ; preds = %while.body, %entry
  ret i8* %destaddr, !dbg !289
}

define i8* @memset(i8* %dst, i32 %s, i64 %count) nounwind uwtable {
entry:
  %cmp1 = icmp eq i64 %count, 0, !dbg !290
  br i1 %cmp1, label %while.end, label %while.body.lr.ph, !dbg !290

while.body.lr.ph:                                 ; preds = %entry
  %conv = trunc i32 %s to i8, !dbg !291
  br label %while.body, !dbg !290

while.body:                                       ; preds = %while.body, %while.body.lr.ph
  %a.03 = phi i8* [ %dst, %while.body.lr.ph ], [ %incdec.ptr, %while.body ]
  %count.addr.02 = phi i64 [ %count, %while.body.lr.ph ], [ %dec, %while.body ]
  %dec = add i64 %count.addr.02, -1, !dbg !290
  %incdec.ptr = getelementptr inbounds i8* %a.03, i64 1, !dbg !291
  store volatile i8 %conv, i8* %a.03, align 1, !dbg !291, !tbaa !274
  %cmp = icmp eq i64 %dec, 0, !dbg !290
  br i1 %cmp, label %while.end, label %while.body, !dbg !290

while.end:                                        ; preds = %while.body, %entry
  ret i8* %dst, !dbg !292
}

define internal void @klee.ctor_stub() {
entry:
  call void @_GLOBAL__I_a()
  ret void
}

!llvm.dbg.cu = !{!0, !11, !70, !181, !201, !217}

!0 = metadata !{i32 786449, i32 0, i32 4, metadata !"Warp_Dependent_Race_device.cpp", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Warp_Dependent_Race", metadata !"clang version 3.2 (trunk 164283)", i1 true, i1
!1 = metadata !{metadata !2}
!2 = metadata !{i32 0}
!3 = metadata !{metadata !4}
!4 = metadata !{metadata !5}
!5 = metadata !{i32 786478, i32 0, metadata !6, metadata !"_Z6kernelPiS_", metadata !"_Z6kernelPiS_", metadata !"_Z13_Z6kernelPiS_PiS_", metadata !6, i32 1215, metadata !7, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (i32*, i32*)* @_Z6
!6 = metadata !{i32 786473, metadata !"Warp_Dependent_Race_device.cpp", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Warp_Dependent_Race", null} ; [ DW_TAG_file_type ]
!7 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !8, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!8 = metadata !{null, metadata !9, metadata !9}
!9 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !10} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from int]
!10 = metadata !{i32 786468, null, metadata !"int", null, i32 0, i64 32, i64 32, i64 0, i32 0, i32 5} ; [ DW_TAG_base_type ] [int] [line 0, size 32, align 32, offset 0, enc DW_ATE_signed]
!11 = metadata !{i32 786449, i32 0, i32 4, metadata !"Warp_Dependent_Race.cu", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Warp_Dependent_Race", metadata !"clang version 3.2 (trunk 164283)", i1 true, i1 false,
!12 = metadata !{metadata !13}
!13 = metadata !{metadata !14}
!14 = metadata !{i32 786436, null, metadata !"cudaMemcpyKind", metadata !15, i32 620, i64 32, i64 32, i32 0, i32 0, null, metadata !16, i32 0, i32 0} ; [ DW_TAG_enumeration_type ] [cudaMemcpyKind] [line 620, size 32, align 32, offset 0] [from ]
!15 = metadata !{i32 786473, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/include/cuda/driver_types.h", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Warp_Dependent_Race", null} ; [ DW_TAG_file_type ]
!16 = metadata !{metadata !17, metadata !18, metadata !19, metadata !20, metadata !21}
!17 = metadata !{i32 786472, metadata !"cudaMemcpyHostToHost", i64 0} ; [ DW_TAG_enumerator ] [cudaMemcpyHostToHost :: 0]
!18 = metadata !{i32 786472, metadata !"cudaMemcpyHostToDevice", i64 1} ; [ DW_TAG_enumerator ] [cudaMemcpyHostToDevice :: 1]
!19 = metadata !{i32 786472, metadata !"cudaMemcpyDeviceToHost", i64 2} ; [ DW_TAG_enumerator ] [cudaMemcpyDeviceToHost :: 2]
!20 = metadata !{i32 786472, metadata !"cudaMemcpyDeviceToDevice", i64 3} ; [ DW_TAG_enumerator ] [cudaMemcpyDeviceToDevice :: 3]
!21 = metadata !{i32 786472, metadata !"cudaMemcpyDefault", i64 4} ; [ DW_TAG_enumerator ] [cudaMemcpyDefault :: 4]
!22 = metadata !{metadata !23}
!23 = metadata !{metadata !24, metadata !28, metadata !29, metadata !30, metadata !31, metadata !33, metadata !36, metadata !62}
!24 = metadata !{i32 786478, i32 0, metadata !25, metadata !"__cxx_global_var_init", metadata !"__cxx_global_var_init", metadata !"", metadata !25, i32 26, metadata !26, i1 true, i1 true, i32 0, i32 0, null, i32 256, i1 false, void ()* @__cxx_global_var_
!25 = metadata !{i32 786473, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/include/klee/gklee.h", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Warp_Dependent_Race", null} ; [ DW_TAG_file_type ]
!26 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !27, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!27 = metadata !{null}
!28 = metadata !{i32 786478, i32 0, metadata !25, metadata !"__cxx_global_var_init1", metadata !"__cxx_global_var_init1", metadata !"", metadata !25, i32 27, metadata !26, i1 true, i1 true, i32 0, i32 0, null, i32 256, i1 false, void ()* @__cxx_global_va
!29 = metadata !{i32 786478, i32 0, metadata !25, metadata !"__cxx_global_var_init2", metadata !"__cxx_global_var_init2", metadata !"", metadata !25, i32 28, metadata !26, i1 true, i1 true, i32 0, i32 0, null, i32 256, i1 false, void ()* @__cxx_global_va
!30 = metadata !{i32 786478, i32 0, metadata !25, metadata !"__cxx_global_var_init3", metadata !"__cxx_global_var_init3", metadata !"", metadata !25, i32 29, metadata !26, i1 true, i1 true, i32 0, i32 0, null, i32 256, i1 false, void ()* @__cxx_global_va
!31 = metadata !{i32 786478, i32 0, metadata !32, metadata !"kernel", metadata !"kernel", metadata !"_Z6kernelPiS_", metadata !32, i32 11, metadata !7, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (i32*, i32*)* @_Z6kernelPiS_, null, nul
!32 = metadata !{i32 786473, metadata !"Warp_Dependent_Race.cu", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Warp_Dependent_Race", null} ; [ DW_TAG_file_type ]
!33 = metadata !{i32 786478, i32 0, metadata !32, metadata !"main", metadata !"main", metadata !"", metadata !32, i32 20, metadata !34, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, i32 ()* @main, null, null, metadata !1, i32 20} ; [ DW_TAG_s
!34 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !35, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!35 = metadata !{metadata !10}
!36 = metadata !{i32 786478, i32 0, null, metadata !"dim3", metadata !"dim3", metadata !"_ZN4dim3C1Ejjj", metadata !37, i32 397, metadata !38, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (%struct.uint3*, i32, i32, i32)* @_ZN4dim3C1Ejjj
!37 = metadata !{i32 786473, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/include/cuda/vector_types.h", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Warp_Dependent_Race", null} ; [ DW_TAG_file_type ]
!38 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !39, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!39 = metadata !{null, metadata !40, metadata !44, metadata !44, metadata !44}
!40 = metadata !{i32 786447, i32 0, metadata !"", i32 0, i32 0, i64 64, i64 64, i64 0, i32 1088, metadata !41} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from dim3]
!41 = metadata !{i32 786434, null, metadata !"dim3", metadata !37, i32 393, i64 96, i64 32, i32 0, i32 0, null, metadata !42, i32 0, null, null} ; [ DW_TAG_class_type ] [dim3] [line 393, size 96, align 32, offset 0] [from ]
!42 = metadata !{metadata !43, metadata !45, metadata !46, metadata !47, metadata !50, metadata !59}
!43 = metadata !{i32 786445, metadata !41, metadata !"x", metadata !37, i32 395, i64 32, i64 32, i64 0, i32 0, metadata !44} ; [ DW_TAG_member ] [x] [line 395, size 32, align 32, offset 0] [from unsigned int]
!44 = metadata !{i32 786468, null, metadata !"unsigned int", null, i32 0, i64 32, i64 32, i64 0, i32 0, i32 7} ; [ DW_TAG_base_type ] [unsigned int] [line 0, size 32, align 32, offset 0, enc DW_ATE_unsigned]
!45 = metadata !{i32 786445, metadata !41, metadata !"y", metadata !37, i32 395, i64 32, i64 32, i64 32, i32 0, metadata !44} ; [ DW_TAG_member ] [y] [line 395, size 32, align 32, offset 32] [from unsigned int]
!46 = metadata !{i32 786445, metadata !41, metadata !"z", metadata !37, i32 395, i64 32, i64 32, i64 64, i32 0, metadata !44} ; [ DW_TAG_member ] [z] [line 395, size 32, align 32, offset 64] [from unsigned int]
!47 = metadata !{i32 786478, i32 0, metadata !41, metadata !"dim3", metadata !"dim3", metadata !"", metadata !37, i32 397, metadata !38, i1 false, i1 false, i32 0, i32 0, null, i32 256, i1 false, null, null, i32 0, metadata !48, i32 397} ; [ DW_TAG_subpr
!48 = metadata !{metadata !49}
!49 = metadata !{i32 786468}                      ; [ DW_TAG_base_type ] [line 0, size 0, align 0, offset 0]
!50 = metadata !{i32 786478, i32 0, metadata !41, metadata !"dim3", metadata !"dim3", metadata !"", metadata !37, i32 398, metadata !51, i1 false, i1 false, i32 0, i32 0, null, i32 256, i1 false, null, null, i32 0, metadata !48, i32 398} ; [ DW_TAG_subpr
!51 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !52, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!52 = metadata !{null, metadata !40, metadata !53}
!53 = metadata !{i32 786454, null, metadata !"uint3", metadata !37, i32 359, i64 0, i64 0, i64 0, i32 0, metadata !54} ; [ DW_TAG_typedef ] [uint3] [line 359, size 0, align 0, offset 0] [from uint3]
!54 = metadata !{i32 786434, null, metadata !"uint3", metadata !37, i32 186, i64 96, i64 32, i32 0, i32 0, null, metadata !55, i32 0, null, null} ; [ DW_TAG_class_type ] [uint3] [line 186, size 96, align 32, offset 0] [from ]
!55 = metadata !{metadata !56, metadata !57, metadata !58}
!56 = metadata !{i32 786445, metadata !54, metadata !"x", metadata !37, i32 188, i64 32, i64 32, i64 0, i32 0, metadata !44} ; [ DW_TAG_member ] [x] [line 188, size 32, align 32, offset 0] [from unsigned int]
!57 = metadata !{i32 786445, metadata !54, metadata !"y", metadata !37, i32 188, i64 32, i64 32, i64 32, i32 0, metadata !44} ; [ DW_TAG_member ] [y] [line 188, size 32, align 32, offset 32] [from unsigned int]
!58 = metadata !{i32 786445, metadata !54, metadata !"z", metadata !37, i32 188, i64 32, i64 32, i64 64, i32 0, metadata !44} ; [ DW_TAG_member ] [z] [line 188, size 32, align 32, offset 64] [from unsigned int]
!59 = metadata !{i32 786478, i32 0, metadata !41, metadata !"operator uint3", metadata !"operator uint3", metadata !"_ZN4dim3cv5uint3Ev", metadata !37, i32 399, metadata !60, i1 false, i1 false, i32 0, i32 0, null, i32 256, i1 false, null, null, i32 0, m
!60 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !61, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!61 = metadata !{metadata !53, metadata !40}
!62 = metadata !{i32 786478, i32 0, null, metadata !"dim3", metadata !"dim3", metadata !"_ZN4dim3C2Ejjj", metadata !37, i32 397, metadata !38, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (%struct.uint3*, i32, i32, i32)* @_ZN4dim3C2Ejjj
!63 = metadata !{metadata !64}
!64 = metadata !{metadata !65, metadata !67, metadata !68, metadata !69}
!65 = metadata !{i32 786484, i32 0, null, metadata !"gridDim", metadata !"gridDim", metadata !"", metadata !25, i32 26, metadata !66, i32 0, i32 1, %struct.uint3* @gridDim} ; [ DW_TAG_variable ] [gridDim] [line 26] [def]
!66 = metadata !{i32 786454, null, metadata !"dim3", metadata !25, i32 403, i64 0, i64 0, i64 0, i32 0, metadata !41} ; [ DW_TAG_typedef ] [dim3] [line 403, size 0, align 0, offset 0] [from dim3]
!67 = metadata !{i32 786484, i32 0, null, metadata !"blockIdx", metadata !"blockIdx", metadata !"", metadata !25, i32 27, metadata !66, i32 0, i32 1, %struct.uint3* @blockIdx} ; [ DW_TAG_variable ] [blockIdx] [line 27] [def]
!68 = metadata !{i32 786484, i32 0, null, metadata !"blockDim", metadata !"blockDim", metadata !"", metadata !25, i32 28, metadata !66, i32 0, i32 1, %struct.uint3* @blockDim} ; [ DW_TAG_variable ] [blockDim] [line 28] [def]
!69 = metadata !{i32 786484, i32 0, null, metadata !"threadIdx", metadata !"threadIdx", metadata !"", metadata !25, i32 29, metadata !66, i32 0, i32 1, %struct.uint3* @threadIdx} ; [ DW_TAG_variable ] [threadIdx] [line 29] [def]
!70 = metadata !{i32 786449, i32 0, i32 1, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/cudaMemManage.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", metadata !"clang version 3.2 (trunk 164283)", i1 tr
!71 = metadata !{metadata !72}
!72 = metadata !{metadata !73, metadata !140}
!73 = metadata !{i32 786436, null, metadata !"cudaError", metadata !74, i32 126, i64 32, i64 32, i32 0, i32 0, null, metadata !75, i32 0, i32 0} ; [ DW_TAG_enumeration_type ] [cudaError] [line 126, size 32, align 32, offset 0] [from ]
!74 = metadata !{i32 786473, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/include/cuda/driver_types.h", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!75 = metadata !{metadata !76, metadata !77, metadata !78, metadata !79, metadata !80, metadata !81, metadata !82, metadata !83, metadata !84, metadata !85, metadata !86, metadata !87, metadata !88, metadata !89, metadata !90, metadata !91, metadata !92,
!76 = metadata !{i32 786472, metadata !"cudaSuccess", i64 0} ; [ DW_TAG_enumerator ] [cudaSuccess :: 0]
!77 = metadata !{i32 786472, metadata !"cudaErrorMissingConfiguration", i64 1} ; [ DW_TAG_enumerator ] [cudaErrorMissingConfiguration :: 1]
!78 = metadata !{i32 786472, metadata !"cudaErrorMemoryAllocation", i64 2} ; [ DW_TAG_enumerator ] [cudaErrorMemoryAllocation :: 2]
!79 = metadata !{i32 786472, metadata !"cudaErrorInitializationError", i64 3} ; [ DW_TAG_enumerator ] [cudaErrorInitializationError :: 3]
!80 = metadata !{i32 786472, metadata !"cudaErrorLaunchFailure", i64 4} ; [ DW_TAG_enumerator ] [cudaErrorLaunchFailure :: 4]
!81 = metadata !{i32 786472, metadata !"cudaErrorPriorLaunchFailure", i64 5} ; [ DW_TAG_enumerator ] [cudaErrorPriorLaunchFailure :: 5]
!82 = metadata !{i32 786472, metadata !"cudaErrorLaunchTimeout", i64 6} ; [ DW_TAG_enumerator ] [cudaErrorLaunchTimeout :: 6]
!83 = metadata !{i32 786472, metadata !"cudaErrorLaunchOutOfResources", i64 7} ; [ DW_TAG_enumerator ] [cudaErrorLaunchOutOfResources :: 7]
!84 = metadata !{i32 786472, metadata !"cudaErrorInvalidDeviceFunction", i64 8} ; [ DW_TAG_enumerator ] [cudaErrorInvalidDeviceFunction :: 8]
!85 = metadata !{i32 786472, metadata !"cudaErrorInvalidConfiguration", i64 9} ; [ DW_TAG_enumerator ] [cudaErrorInvalidConfiguration :: 9]
!86 = metadata !{i32 786472, metadata !"cudaErrorInvalidDevice", i64 10} ; [ DW_TAG_enumerator ] [cudaErrorInvalidDevice :: 10]
!87 = metadata !{i32 786472, metadata !"cudaErrorInvalidValue", i64 11} ; [ DW_TAG_enumerator ] [cudaErrorInvalidValue :: 11]
!88 = metadata !{i32 786472, metadata !"cudaErrorInvalidPitchValue", i64 12} ; [ DW_TAG_enumerator ] [cudaErrorInvalidPitchValue :: 12]
!89 = metadata !{i32 786472, metadata !"cudaErrorInvalidSymbol", i64 13} ; [ DW_TAG_enumerator ] [cudaErrorInvalidSymbol :: 13]
!90 = metadata !{i32 786472, metadata !"cudaErrorMapBufferObjectFailed", i64 14} ; [ DW_TAG_enumerator ] [cudaErrorMapBufferObjectFailed :: 14]
!91 = metadata !{i32 786472, metadata !"cudaErrorUnmapBufferObjectFailed", i64 15} ; [ DW_TAG_enumerator ] [cudaErrorUnmapBufferObjectFailed :: 15]
!92 = metadata !{i32 786472, metadata !"cudaErrorInvalidHostPointer", i64 16} ; [ DW_TAG_enumerator ] [cudaErrorInvalidHostPointer :: 16]
!93 = metadata !{i32 786472, metadata !"cudaErrorInvalidDevicePointer", i64 17} ; [ DW_TAG_enumerator ] [cudaErrorInvalidDevicePointer :: 17]
!94 = metadata !{i32 786472, metadata !"cudaErrorInvalidTexture", i64 18} ; [ DW_TAG_enumerator ] [cudaErrorInvalidTexture :: 18]
!95 = metadata !{i32 786472, metadata !"cudaErrorInvalidTextureBinding", i64 19} ; [ DW_TAG_enumerator ] [cudaErrorInvalidTextureBinding :: 19]
!96 = metadata !{i32 786472, metadata !"cudaErrorInvalidChannelDescriptor", i64 20} ; [ DW_TAG_enumerator ] [cudaErrorInvalidChannelDescriptor :: 20]
!97 = metadata !{i32 786472, metadata !"cudaErrorInvalidMemcpyDirection", i64 21} ; [ DW_TAG_enumerator ] [cudaErrorInvalidMemcpyDirection :: 21]
!98 = metadata !{i32 786472, metadata !"cudaErrorAddressOfConstant", i64 22} ; [ DW_TAG_enumerator ] [cudaErrorAddressOfConstant :: 22]
!99 = metadata !{i32 786472, metadata !"cudaErrorTextureFetchFailed", i64 23} ; [ DW_TAG_enumerator ] [cudaErrorTextureFetchFailed :: 23]
!100 = metadata !{i32 786472, metadata !"cudaErrorTextureNotBound", i64 24} ; [ DW_TAG_enumerator ] [cudaErrorTextureNotBound :: 24]
!101 = metadata !{i32 786472, metadata !"cudaErrorSynchronizationError", i64 25} ; [ DW_TAG_enumerator ] [cudaErrorSynchronizationError :: 25]
!102 = metadata !{i32 786472, metadata !"cudaErrorInvalidFilterSetting", i64 26} ; [ DW_TAG_enumerator ] [cudaErrorInvalidFilterSetting :: 26]
!103 = metadata !{i32 786472, metadata !"cudaErrorInvalidNormSetting", i64 27} ; [ DW_TAG_enumerator ] [cudaErrorInvalidNormSetting :: 27]
!104 = metadata !{i32 786472, metadata !"cudaErrorMixedDeviceExecution", i64 28} ; [ DW_TAG_enumerator ] [cudaErrorMixedDeviceExecution :: 28]
!105 = metadata !{i32 786472, metadata !"cudaErrorCudartUnloading", i64 29} ; [ DW_TAG_enumerator ] [cudaErrorCudartUnloading :: 29]
!106 = metadata !{i32 786472, metadata !"cudaErrorUnknown", i64 30} ; [ DW_TAG_enumerator ] [cudaErrorUnknown :: 30]
!107 = metadata !{i32 786472, metadata !"cudaErrorNotYetImplemented", i64 31} ; [ DW_TAG_enumerator ] [cudaErrorNotYetImplemented :: 31]
!108 = metadata !{i32 786472, metadata !"cudaErrorMemoryValueTooLarge", i64 32} ; [ DW_TAG_enumerator ] [cudaErrorMemoryValueTooLarge :: 32]
!109 = metadata !{i32 786472, metadata !"cudaErrorInvalidResourceHandle", i64 33} ; [ DW_TAG_enumerator ] [cudaErrorInvalidResourceHandle :: 33]
!110 = metadata !{i32 786472, metadata !"cudaErrorNotReady", i64 34} ; [ DW_TAG_enumerator ] [cudaErrorNotReady :: 34]
!111 = metadata !{i32 786472, metadata !"cudaErrorInsufficientDriver", i64 35} ; [ DW_TAG_enumerator ] [cudaErrorInsufficientDriver :: 35]
!112 = metadata !{i32 786472, metadata !"cudaErrorSetOnActiveProcess", i64 36} ; [ DW_TAG_enumerator ] [cudaErrorSetOnActiveProcess :: 36]
!113 = metadata !{i32 786472, metadata !"cudaErrorInvalidSurface", i64 37} ; [ DW_TAG_enumerator ] [cudaErrorInvalidSurface :: 37]
!114 = metadata !{i32 786472, metadata !"cudaErrorNoDevice", i64 38} ; [ DW_TAG_enumerator ] [cudaErrorNoDevice :: 38]
!115 = metadata !{i32 786472, metadata !"cudaErrorECCUncorrectable", i64 39} ; [ DW_TAG_enumerator ] [cudaErrorECCUncorrectable :: 39]
!116 = metadata !{i32 786472, metadata !"cudaErrorSharedObjectSymbolNotFound", i64 40} ; [ DW_TAG_enumerator ] [cudaErrorSharedObjectSymbolNotFound :: 40]
!117 = metadata !{i32 786472, metadata !"cudaErrorSharedObjectInitFailed", i64 41} ; [ DW_TAG_enumerator ] [cudaErrorSharedObjectInitFailed :: 41]
!118 = metadata !{i32 786472, metadata !"cudaErrorUnsupportedLimit", i64 42} ; [ DW_TAG_enumerator ] [cudaErrorUnsupportedLimit :: 42]
!119 = metadata !{i32 786472, metadata !"cudaErrorDuplicateVariableName", i64 43} ; [ DW_TAG_enumerator ] [cudaErrorDuplicateVariableName :: 43]
!120 = metadata !{i32 786472, metadata !"cudaErrorDuplicateTextureName", i64 44} ; [ DW_TAG_enumerator ] [cudaErrorDuplicateTextureName :: 44]
!121 = metadata !{i32 786472, metadata !"cudaErrorDuplicateSurfaceName", i64 45} ; [ DW_TAG_enumerator ] [cudaErrorDuplicateSurfaceName :: 45]
!122 = metadata !{i32 786472, metadata !"cudaErrorDevicesUnavailable", i64 46} ; [ DW_TAG_enumerator ] [cudaErrorDevicesUnavailable :: 46]
!123 = metadata !{i32 786472, metadata !"cudaErrorInvalidKernelImage", i64 47} ; [ DW_TAG_enumerator ] [cudaErrorInvalidKernelImage :: 47]
!124 = metadata !{i32 786472, metadata !"cudaErrorNoKernelImageForDevice", i64 48} ; [ DW_TAG_enumerator ] [cudaErrorNoKernelImageForDevice :: 48]
!125 = metadata !{i32 786472, metadata !"cudaErrorIncompatibleDriverContext", i64 49} ; [ DW_TAG_enumerator ] [cudaErrorIncompatibleDriverContext :: 49]
!126 = metadata !{i32 786472, metadata !"cudaErrorPeerAccessAlreadyEnabled", i64 50} ; [ DW_TAG_enumerator ] [cudaErrorPeerAccessAlreadyEnabled :: 50]
!127 = metadata !{i32 786472, metadata !"cudaErrorPeerAccessNotEnabled", i64 51} ; [ DW_TAG_enumerator ] [cudaErrorPeerAccessNotEnabled :: 51]
!128 = metadata !{i32 786472, metadata !"cudaErrorDeviceAlreadyInUse", i64 54} ; [ DW_TAG_enumerator ] [cudaErrorDeviceAlreadyInUse :: 54]
!129 = metadata !{i32 786472, metadata !"cudaErrorProfilerDisabled", i64 55} ; [ DW_TAG_enumerator ] [cudaErrorProfilerDisabled :: 55]
!130 = metadata !{i32 786472, metadata !"cudaErrorProfilerNotInitialized", i64 56} ; [ DW_TAG_enumerator ] [cudaErrorProfilerNotInitialized :: 56]
!131 = metadata !{i32 786472, metadata !"cudaErrorProfilerAlreadyStarted", i64 57} ; [ DW_TAG_enumerator ] [cudaErrorProfilerAlreadyStarted :: 57]
!132 = metadata !{i32 786472, metadata !"cudaErrorProfilerAlreadyStopped", i64 58} ; [ DW_TAG_enumerator ] [cudaErrorProfilerAlreadyStopped :: 58]
!133 = metadata !{i32 786472, metadata !"cudaErrorAssert", i64 59} ; [ DW_TAG_enumerator ] [cudaErrorAssert :: 59]
!134 = metadata !{i32 786472, metadata !"cudaErrorTooManyPeers", i64 60} ; [ DW_TAG_enumerator ] [cudaErrorTooManyPeers :: 60]
!135 = metadata !{i32 786472, metadata !"cudaErrorHostMemoryAlreadyRegistered", i64 61} ; [ DW_TAG_enumerator ] [cudaErrorHostMemoryAlreadyRegistered :: 61]
!136 = metadata !{i32 786472, metadata !"cudaErrorHostMemoryNotRegistered", i64 62} ; [ DW_TAG_enumerator ] [cudaErrorHostMemoryNotRegistered :: 62]
!137 = metadata !{i32 786472, metadata !"cudaErrorOperatingSystem", i64 63} ; [ DW_TAG_enumerator ] [cudaErrorOperatingSystem :: 63]
!138 = metadata !{i32 786472, metadata !"cudaErrorStartupFailure", i64 127} ; [ DW_TAG_enumerator ] [cudaErrorStartupFailure :: 127]
!139 = metadata !{i32 786472, metadata !"cudaErrorApiFailureBase", i64 10000} ; [ DW_TAG_enumerator ] [cudaErrorApiFailureBase :: 10000]
!140 = metadata !{i32 786436, null, metadata !"cudaMemcpyKind", metadata !74, i32 620, i64 32, i64 32, i32 0, i32 0, null, metadata !16, i32 0, i32 0} ; [ DW_TAG_enumeration_type ] [cudaMemcpyKind] [line 620, size 32, align 32, offset 0] [from ]
!141 = metadata !{metadata !142}
!142 = metadata !{metadata !143, metadata !156, metadata !167, metadata !175}
!143 = metadata !{i32 786478, i32 0, metadata !144, metadata !"cudaMalloc", metadata !"cudaMalloc", metadata !"", metadata !144, i32 13, metadata !145, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, i32 (i8**, i64)* @cudaMalloc, null, null, met
!144 = metadata !{i32 786473, metadata !"cudaMemManage.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!145 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !146, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!146 = metadata !{metadata !147, metadata !148, metadata !150}
!147 = metadata !{i32 786454, null, metadata !"cudaError_t", metadata !144, i32 1001, i64 0, i64 0, i64 0, i32 0, metadata !73} ; [ DW_TAG_typedef ] [cudaError_t] [line 1001, size 0, align 0, offset 0] [from cudaError]
!148 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !149} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!149 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, null} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!150 = metadata !{i32 786454, null, metadata !"size_t", metadata !144, i32 35, i64 0, i64 0, i64 0, i32 0, metadata !151} ; [ DW_TAG_typedef ] [size_t] [line 35, size 0, align 0, offset 0] [from long unsigned int]
!151 = metadata !{i32 786468, null, metadata !"long unsigned int", null, i32 0, i64 64, i64 64, i64 0, i32 0, i32 7} ; [ DW_TAG_base_type ] [long unsigned int] [line 0, size 64, align 64, offset 0, enc DW_ATE_unsigned]
!152 = metadata !{metadata !153}
!153 = metadata !{metadata !154, metadata !155}
!154 = metadata !{i32 786689, metadata !143, metadata !"devPtr", metadata !144, i32 16777229, metadata !148, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [devPtr] [line 13]
!155 = metadata !{i32 786689, metadata !143, metadata !"size", metadata !144, i32 33554445, metadata !150, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [size] [line 13]
!156 = metadata !{i32 786478, i32 0, metadata !144, metadata !"cudaMemcpy", metadata !"cudaMemcpy", metadata !"", metadata !144, i32 21, metadata !157, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, i32 (i8*, i8*, i64, i32)* @cudaMemcpy, null, 
!157 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !158, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!158 = metadata !{metadata !147, metadata !149, metadata !159, metadata !150, metadata !140}
!159 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !160} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!160 = metadata !{i32 786470, null, metadata !"", null, i32 0, i64 0, i64 0, i64 0, i32 0, null} ; [ DW_TAG_const_type ] [line 0, size 0, align 0, offset 0] [from ]
!161 = metadata !{metadata !162}
!162 = metadata !{metadata !163, metadata !164, metadata !165, metadata !166}
!163 = metadata !{i32 786689, metadata !156, metadata !"dst", metadata !144, i32 16777237, metadata !149, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [dst] [line 21]
!164 = metadata !{i32 786689, metadata !156, metadata !"src", metadata !144, i32 33554453, metadata !159, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [src] [line 21]
!165 = metadata !{i32 786689, metadata !156, metadata !"count", metadata !144, i32 50331669, metadata !150, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [count] [line 21]
!166 = metadata !{i32 786689, metadata !156, metadata !"kind", metadata !144, i32 67108885, metadata !140, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [kind] [line 21]
!167 = metadata !{i32 786478, i32 0, metadata !144, metadata !"cudaMemset", metadata !"cudaMemset", metadata !"", metadata !144, i32 26, metadata !168, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, i32 (i8*, i32, i64)* @cudaMemset, null, null,
!168 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !169, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!169 = metadata !{metadata !147, metadata !149, metadata !10, metadata !150}
!170 = metadata !{metadata !171}
!171 = metadata !{metadata !172, metadata !173, metadata !174}
!172 = metadata !{i32 786689, metadata !167, metadata !"devPtr", metadata !144, i32 16777242, metadata !149, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [devPtr] [line 26]
!173 = metadata !{i32 786689, metadata !167, metadata !"value", metadata !144, i32 33554458, metadata !10, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [value] [line 26]
!174 = metadata !{i32 786689, metadata !167, metadata !"count", metadata !144, i32 50331674, metadata !150, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [count] [line 26]
!175 = metadata !{i32 786478, i32 0, metadata !144, metadata !"cudaFree", metadata !"cudaFree", metadata !"", metadata !144, i32 31, metadata !176, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, i32 (i8*)* @cudaFree, null, null, metadata !178, 
!176 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !177, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!177 = metadata !{metadata !147, metadata !149}
!178 = metadata !{metadata !179}
!179 = metadata !{metadata !180}
!180 = metadata !{i32 786689, metadata !175, metadata !"devPtr", metadata !144, i32 16777247, metadata !149, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [devPtr] [line 31]
!181 = metadata !{i32 786449, i32 0, i32 1, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memcpy.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", metadata !"clang version 3.2 (trunk 164283)", i1 true, i1
!182 = metadata !{metadata !183}
!183 = metadata !{metadata !184}
!184 = metadata !{i32 786478, i32 0, metadata !185, metadata !"memcpy", metadata !"memcpy", metadata !"", metadata !185, i32 12, metadata !186, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, i8* (i8*, i8*, i64)* @memcpy, null, null, metadata !1
!185 = metadata !{i32 786473, metadata !"memcpy.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!186 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !187, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!187 = metadata !{metadata !149, metadata !149, metadata !159, metadata !188}
!188 = metadata !{i32 786454, null, metadata !"size_t", metadata !185, i32 35, i64 0, i64 0, i64 0, i32 0, metadata !151} ; [ DW_TAG_typedef ] [size_t] [line 35, size 0, align 0, offset 0] [from long unsigned int]
!189 = metadata !{metadata !190}
!190 = metadata !{metadata !191, metadata !192, metadata !193, metadata !194, metadata !198}
!191 = metadata !{i32 786689, metadata !184, metadata !"destaddr", metadata !185, i32 16777228, metadata !149, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [destaddr] [line 12]
!192 = metadata !{i32 786689, metadata !184, metadata !"srcaddr", metadata !185, i32 33554444, metadata !159, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [srcaddr] [line 12]
!193 = metadata !{i32 786689, metadata !184, metadata !"len", metadata !185, i32 50331660, metadata !188, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [len] [line 12]
!194 = metadata !{i32 786688, metadata !195, metadata !"dest", metadata !185, i32 13, metadata !196, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [dest] [line 13]
!195 = metadata !{i32 786443, metadata !184, i32 12, i32 63, metadata !185, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memcpy.c]
!196 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !197} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from char]
!197 = metadata !{i32 786468, null, metadata !"char", null, i32 0, i64 8, i64 8, i64 0, i32 0, i32 6} ; [ DW_TAG_base_type ] [char] [line 0, size 8, align 8, offset 0, enc DW_ATE_signed_char]
!198 = metadata !{i32 786688, metadata !195, metadata !"src", metadata !185, i32 14, metadata !199, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [src] [line 14]
!199 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !200} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!200 = metadata !{i32 786470, null, metadata !"", null, i32 0, i64 0, i64 0, i64 0, i32 0, metadata !197} ; [ DW_TAG_const_type ] [line 0, size 0, align 0, offset 0] [from char]
!201 = metadata !{i32 786449, i32 0, i32 1, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memmove.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", metadata !"clang version 3.2 (trunk 164283)", i1 true, i
!202 = metadata !{metadata !203}
!203 = metadata !{metadata !204}
!204 = metadata !{i32 786478, i32 0, metadata !205, metadata !"memmove", metadata !"memmove", metadata !"", metadata !205, i32 12, metadata !206, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, null, null, null, metadata !209, i32 12} ; [ DW_TAG
!205 = metadata !{i32 786473, metadata !"memmove.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!206 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !207, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!207 = metadata !{metadata !149, metadata !149, metadata !159, metadata !208}
!208 = metadata !{i32 786454, null, metadata !"size_t", metadata !205, i32 35, i64 0, i64 0, i64 0, i32 0, metadata !151} ; [ DW_TAG_typedef ] [size_t] [line 35, size 0, align 0, offset 0] [from long unsigned int]
!209 = metadata !{metadata !210}
!210 = metadata !{metadata !211, metadata !212, metadata !213, metadata !214, metadata !216}
!211 = metadata !{i32 786689, metadata !204, metadata !"dst", metadata !205, i32 16777228, metadata !149, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [dst] [line 12]
!212 = metadata !{i32 786689, metadata !204, metadata !"src", metadata !205, i32 33554444, metadata !159, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [src] [line 12]
!213 = metadata !{i32 786689, metadata !204, metadata !"count", metadata !205, i32 50331660, metadata !208, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [count] [line 12]
!214 = metadata !{i32 786688, metadata !215, metadata !"a", metadata !205, i32 14, metadata !196, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [a] [line 14]
!215 = metadata !{i32 786443, metadata !204, i32 12, i32 57, metadata !205, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memmove.c]
!216 = metadata !{i32 786688, metadata !215, metadata !"b", metadata !205, i32 15, metadata !199, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [b] [line 15]
!217 = metadata !{i32 786449, i32 0, i32 1, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memset.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", metadata !"clang version 3.2 (trunk 164283)", i1 true, i1
!218 = metadata !{metadata !219}
!219 = metadata !{metadata !220}
!220 = metadata !{i32 786478, i32 0, metadata !221, metadata !"memset", metadata !"memset", metadata !"", metadata !221, i32 12, metadata !222, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, i8* (i8*, i32, i64)* @memset, null, null, metadata !2
!221 = metadata !{i32 786473, metadata !"memset.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!222 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !223, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!223 = metadata !{metadata !149, metadata !149, metadata !10, metadata !224}
!224 = metadata !{i32 786454, null, metadata !"size_t", metadata !221, i32 35, i64 0, i64 0, i64 0, i32 0, metadata !151} ; [ DW_TAG_typedef ] [size_t] [line 35, size 0, align 0, offset 0] [from long unsigned int]
!225 = metadata !{metadata !226}
!226 = metadata !{metadata !227, metadata !228, metadata !229, metadata !230}
!227 = metadata !{i32 786689, metadata !220, metadata !"dst", metadata !221, i32 16777228, metadata !149, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [dst] [line 12]
!228 = metadata !{i32 786689, metadata !220, metadata !"s", metadata !221, i32 33554444, metadata !10, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [s] [line 12]
!229 = metadata !{i32 786689, metadata !220, metadata !"count", metadata !221, i32 50331660, metadata !224, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [count] [line 12]
!230 = metadata !{i32 786688, metadata !231, metadata !"a", metadata !221, i32 13, metadata !232, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [a] [line 13]
!231 = metadata !{i32 786443, metadata !220, i32 12, i32 47, metadata !221, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memset.c]
!232 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !233} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!233 = metadata !{i32 786485, null, metadata !"", null, i32 0, i64 0, i64 0, i64 0, i32 0, metadata !197} ; [ DW_TAG_volatile_type ] [line 0, size 0, align 0, offset 0] [from char]
!234 = metadata !{i32 1220, i32 1, metadata !235, null}
!235 = metadata !{i32 786443, metadata !236, i32 1218, i32 1, metadata !6, i32 1} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Warp_Dependent_Race/Warp_Dependent_Race_device.cpp]
!236 = metadata !{i32 786443, metadata !5, i32 1217, i32 8, metadata !6, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Warp_Dependent_Race/Warp_Dependent_Race_device.cpp]
!237 = metadata !{i32 1221, i32 1, metadata !235, null}
!238 = metadata !{i32 1222, i32 1, metadata !235, null}
!239 = metadata !{i32 1223, i32 1, metadata !240, null}
!240 = metadata !{i32 786443, metadata !235, i32 1222, i32 107, metadata !6, i32 2} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Warp_Dependent_Race/Warp_Dependent_Race_device.cpp]
!241 = metadata !{i32 1223, i32 61, metadata !240, null}
!242 = metadata !{i32 1224, i32 2, metadata !236, null}
!243 = metadata !{i32 26, i32 6, metadata !24, null}
!244 = metadata !{i32 397, i32 116, metadata !36, null}
!245 = metadata !{i32 27, i32 6, metadata !28, null}
!246 = metadata !{i32 28, i32 6, metadata !29, null}
!247 = metadata !{i32 29, i32 6, metadata !30, null}
!248 = metadata !{i32 26, i32 3, metadata !249, null}
!249 = metadata !{i32 786443, metadata !33, i32 20, i32 18, metadata !32, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Warp_Dependent_Race/Warp_Dependent_Race.cu]
!250 = metadata !{i32 27, i32 3, metadata !249, null}
!251 = metadata !{i32 29, i32 3, metadata !249, null}
!252 = metadata !{i32 30, i32 3, metadata !249, null}
!253 = metadata !{i32 34, i32 17, metadata !254, null}
!254 = metadata !{i32 786443, metadata !249, i32 34, i32 3, metadata !32, i32 1} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Warp_Dependent_Race/Warp_Dependent_Race.cu]
!255 = metadata !{i32 36, i32 7, metadata !256, null}
!256 = metadata !{i32 786443, metadata !254, i32 35, i32 5, metadata !32, i32 2} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Warp_Dependent_Race/Warp_Dependent_Race.cu]
!257 = metadata !{i32 34, i32 29, metadata !254, null}
!258 = metadata !{i32 40, i32 3, metadata !249, null}
!259 = metadata !{i32 41, i32 3, metadata !249, null}
!260 = metadata !{i32 44, i32 9, metadata !249, null}
!261 = metadata !{i32 46, i32 3, metadata !249, null}
!262 = metadata !{i32 53, i32 3, metadata !249, null}
!263 = metadata !{i32 54, i32 3, metadata !249, null}
!264 = metadata !{i32 56, i32 3, metadata !249, null}
!265 = metadata !{i32 57, i32 3, metadata !249, null}
!266 = metadata !{i32 59, i32 3, metadata !249, null}
!267 = metadata !{i32 397, i32 115, metadata !62, null}
!268 = metadata !{i32 397, i32 116, metadata !269, null}
!269 = metadata !{i32 786443, metadata !62, i32 397, i32 115, metadata !37, i32 3} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Warp_Dependent_Race//home/peng/gklee-clang/gklee/trunk/Gklee/incl
!270 = metadata !{i32 14, i32 3, metadata !271, null}
!271 = metadata !{i32 786443, metadata !143, i32 13, i32 52, metadata !144, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/cudaMemManage.c]
!272 = metadata !{i32 15, i32 21, metadata !271, null}
!273 = metadata !{metadata !"any pointer", metadata !274}
!274 = metadata !{metadata !"omnipotent char", metadata !275}
!275 = metadata !{metadata !"Simple C/C++ TBAA"}
!276 = metadata !{i32 16, i32 3, metadata !271, null}
!277 = metadata !{i32 18, i32 3, metadata !271, null}
!278 = metadata !{i32 22, i32 3, metadata !279, null}
!279 = metadata !{i32 786443, metadata !156, i32 21, i32 92, metadata !144, i32 1} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/cudaMemManage.c]
!280 = metadata !{i32 23, i32 3, metadata !279, null}
!281 = metadata !{i32 27, i32 3, metadata !282, null}
!282 = metadata !{i32 786443, metadata !167, i32 26, i32 63, metadata !144, i32 2} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/cudaMemManage.c]
!283 = metadata !{i32 28, i32 3, metadata !282, null}
!284 = metadata !{i32 32, i32 3, metadata !285, null}
!285 = metadata !{i32 786443, metadata !175, i32 31, i32 36, metadata !144, i32 3} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/cudaMemManage.c]
!286 = metadata !{i32 33, i32 3, metadata !285, null}
!287 = metadata !{i32 16, i32 3, metadata !195, null}
!288 = metadata !{i32 17, i32 5, metadata !195, null}
!289 = metadata !{i32 18, i32 3, metadata !195, null}
!290 = metadata !{i32 14, i32 5, metadata !231, null}
!291 = metadata !{i32 15, i32 7, metadata !231, null}
!292 = metadata !{i32 16, i32 5, metadata !231, null}
