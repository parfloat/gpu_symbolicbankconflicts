; ModuleID = 'bitonic'
target datalayout = "e-p:64:64:64-i1:8:8-i8:8:8-i16:16:16-i32:32:32-i64:64:64-f32:32:32-f64:64:64-v64:64:64-v128:128:128-a0:0:64-s0:64:64-f80:128:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%struct.dim3 = type { i32, i32, i32 }
%struct.CUstream_st = type opaque

@shared = global [4 x i32] zeroinitializer, section "__shared__", align 16
@gridDim = global %struct.dim3 zeroinitializer, align 4
@blockIdx = global %struct.dim3 zeroinitializer, align 4
@blockDim = global %struct.dim3 zeroinitializer, align 4
@threadIdx = global %struct.dim3 zeroinitializer, align 4
@.str = private unnamed_addr constant [6 x i8] c"input\00", align 1
@.str4 = private unnamed_addr constant [67 x i8] c"The sorting algorithm is incorrect since values[%d] < values[%d]!\0A\00", align 1
@llvm.global_ctors = appending global [1 x { i32, void ()* }] [{ i32, void ()* } { i32 65535, void ()* @_GLOBAL__I_a }]
@.str7 = private unnamed_addr constant [22 x i8] c"klee_div_zero_check.c\00", align 1
@.str1 = private unnamed_addr constant [15 x i8] c"divide by zero\00", align 1
@.str2 = private unnamed_addr constant [8 x i8] c"div.err\00", align 1

define void @_Z13BitonicKernelPi(i32* %values) uwtable {
entry:
  %values.addr = alloca i32*, align 8
  %tid = alloca i32, align 4
  %k = alloca i32, align 4
  %j = alloca i32, align 4
  %ixj = alloca i32, align 4
  store i32* %values, i32** %values.addr, align 8
  %0 = load i32* getelementptr inbounds (%struct.dim3* @threadIdx, i32 0, i32 0), align 4
  store i32 %0, i32* %tid, align 4
  %1 = load i32* %tid, align 4
  %idxprom = zext i32 %1 to i64
  %2 = load i32** %values.addr, align 8
  %arrayidx = getelementptr inbounds i32* %2, i64 %idxprom
  %3 = load i32* %arrayidx, align 4
  %4 = load i32* %tid, align 4
  %idxprom1 = zext i32 %4 to i64
  %arrayidx2 = getelementptr inbounds [4 x i32]* @shared, i32 0, i64 %idxprom1
  store i32 %3, i32* %arrayidx2, align 4
  call void @__syncthreads()
  store i32 2, i32* %k, align 4
  br label %for.cond

for.cond:                                         ; preds = %for.inc33, %entry
  %5 = load i32* %k, align 4
  %6 = load i32* getelementptr inbounds (%struct.dim3* @blockDim, i32 0, i32 0), align 4
  %cmp = icmp ule i32 %5, %6
  br i1 %cmp, label %for.body, label %for.end34

for.body:                                         ; preds = %for.cond
  %7 = load i32* %k, align 4
  %int_cast_to_i64 = zext i32 2 to i64
  call void @klee_div_zero_check(i64 %int_cast_to_i64)
  %div = udiv i32 %7, 2
  store i32 %div, i32* %j, align 4
  br label %for.cond3

for.cond3:                                        ; preds = %if.end31, %for.body
  %8 = load i32* %j, align 4
  %cmp4 = icmp ugt i32 %8, 0
  br i1 %cmp4, label %for.body5, label %for.inc33

for.body5:                                        ; preds = %for.cond3
  %9 = load i32* %tid, align 4
  %10 = load i32* %j, align 4
  %xor = xor i32 %9, %10
  store i32 %xor, i32* %ixj, align 4
  %11 = load i32* %ixj, align 4
  %12 = load i32* %tid, align 4
  %cmp6 = icmp ugt i32 %11, %12
  br i1 %cmp6, label %if.then, label %if.end31

if.then:                                          ; preds = %for.body5
  %13 = load i32* %tid, align 4
  %14 = load i32* %k, align 4
  %and = and i32 %13, %14
  %cmp7 = icmp eq i32 %and, 0
  %15 = load i32* %tid, align 4
  %idxprom9 = zext i32 %15 to i64
  %arrayidx10 = getelementptr inbounds [4 x i32]* @shared, i32 0, i64 %idxprom9
  %16 = load i32* %arrayidx10, align 4
  %17 = load i32* %ixj, align 4
  %idxprom11 = zext i32 %17 to i64
  %arrayidx12 = getelementptr inbounds [4 x i32]* @shared, i32 0, i64 %idxprom11
  %18 = load i32* %arrayidx12, align 4
  br i1 %cmp7, label %if.then8, label %if.else

if.then8:                                         ; preds = %if.then
  %cmp13 = icmp sgt i32 %16, %18
  br i1 %cmp13, label %if.then14, label %if.end31

if.then14:                                        ; preds = %if.then8
  %19 = load i32* %tid, align 4
  %idxprom15 = zext i32 %19 to i64
  %arrayidx16 = getelementptr inbounds [4 x i32]* @shared, i32 0, i64 %idxprom15
  %20 = load i32* %ixj, align 4
  %idxprom17 = zext i32 %20 to i64
  %arrayidx18 = getelementptr inbounds [4 x i32]* @shared, i32 0, i64 %idxprom17
  call void @_Z4swapRiS_(i32* %arrayidx16, i32* %arrayidx18)
  br label %if.end31

if.else:                                          ; preds = %if.then
  %cmp23 = icmp slt i32 %16, %18
  br i1 %cmp23, label %if.then24, label %if.end31

if.then24:                                        ; preds = %if.else
  %21 = load i32* %tid, align 4
  %idxprom25 = zext i32 %21 to i64
  %arrayidx26 = getelementptr inbounds [4 x i32]* @shared, i32 0, i64 %idxprom25
  %22 = load i32* %ixj, align 4
  %idxprom27 = zext i32 %22 to i64
  %arrayidx28 = getelementptr inbounds [4 x i32]* @shared, i32 0, i64 %idxprom27
  call void @_Z4swapRiS_(i32* %arrayidx26, i32* %arrayidx28)
  br label %if.end31

if.end31:                                         ; preds = %if.then14, %if.then8, %if.then24, %if.else, %for.body5
  call void @__syncthreads()
  %23 = load i32* %j, align 4
  %int_cast_to_i641 = zext i32 2 to i64
  call void @klee_div_zero_check(i64 %int_cast_to_i641)
  %div32 = udiv i32 %23, 2
  store i32 %div32, i32* %j, align 4
  br label %for.cond3

for.inc33:                                        ; preds = %for.cond3
  %24 = load i32* %k, align 4
  %mul = mul i32 %24, 2
  store i32 %mul, i32* %k, align 4
  br label %for.cond

for.end34:                                        ; preds = %for.cond
  %25 = load i32* %tid, align 4
  %idxprom35 = zext i32 %25 to i64
  %arrayidx36 = getelementptr inbounds [4 x i32]* @shared, i32 0, i64 %idxprom35
  %26 = load i32* %arrayidx36, align 4
  %27 = load i32* %tid, align 4
  %idxprom37 = zext i32 %27 to i64
  %28 = load i32** %values.addr, align 8
  %arrayidx38 = getelementptr inbounds i32* %28, i64 %idxprom37
  store i32 %26, i32* %arrayidx38, align 4
  ret void
}

declare void @__syncthreads() section "__device__"

define linkonce_odr void @_Z4swapRiS_(i32* %a, i32* %b) nounwind uwtable inlinehint section "__device__" {
entry:
  %a.addr = alloca i32*, align 8
  %b.addr = alloca i32*, align 8
  %tmp = alloca i32, align 4
  store i32* %a, i32** %a.addr, align 8
  store i32* %b, i32** %b.addr, align 8
  %0 = load i32** %a.addr, align 8
  %1 = load i32* %0, align 4
  store i32 %1, i32* %tmp, align 4
  %2 = load i32** %b.addr, align 8
  %3 = load i32* %2, align 4
  %4 = load i32** %a.addr, align 8
  store i32 %3, i32* %4, align 4
  %5 = load i32* %tmp, align 4
  %6 = load i32** %b.addr, align 8
  store i32 %5, i32* %6, align 4
  ret void
}

define internal void @__cxx_global_var_init() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @gridDim, i32 1, i32 1, i32 1)
  ret void
}

define linkonce_odr void @_ZN4dim3C1Ejjj(%struct.dim3* %this, i32 %vx, i32 %vy, i32 %vz) unnamed_addr uwtable section "__device__" align 2 {
entry:
  %this.addr = alloca %struct.dim3*, align 8
  %vx.addr = alloca i32, align 4
  %vy.addr = alloca i32, align 4
  %vz.addr = alloca i32, align 4
  store %struct.dim3* %this, %struct.dim3** %this.addr, align 8
  store i32 %vx, i32* %vx.addr, align 4
  store i32 %vy, i32* %vy.addr, align 4
  store i32 %vz, i32* %vz.addr, align 4
  %this1 = load %struct.dim3** %this.addr
  %0 = load i32* %vx.addr, align 4
  %1 = load i32* %vy.addr, align 4
  %2 = load i32* %vz.addr, align 4
  call void @_ZN4dim3C2Ejjj(%struct.dim3* %this1, i32 %0, i32 %1, i32 %2)
  ret void
}

define internal void @__cxx_global_var_init1() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @blockIdx, i32 1, i32 1, i32 1)
  ret void
}

define internal void @__cxx_global_var_init2() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @blockDim, i32 1, i32 1, i32 1)
  ret void
}

define internal void @__cxx_global_var_init3() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @threadIdx, i32 1, i32 1, i32 1)
  ret void
}

declare i32 @cudaSetupArgument(i8*, i64, i64)

declare i32 @cudaLaunch(i8*)

define i32 @main() uwtable {
entry:
  call void @klee.ctor_stub()
  %retval = alloca i32, align 4
  %values = alloca [4 x i32], align 16
  %dvalues = alloca i32*, align 8
  %agg.tmp = alloca %struct.dim3, align 4
  %agg.tmp3 = alloca %struct.dim3, align 4
  %i = alloca i32, align 4
  store i32 0, i32* %retval
  %arraydecay = getelementptr inbounds [4 x i32]* %values, i32 0, i32 0
  %0 = bitcast i32* %arraydecay to i8*
  call void @klee_make_symbolic(i8* %0, i64 16, i8* getelementptr inbounds ([6 x i8]* @.str, i32 0, i32 0))
  %1 = bitcast i32** %dvalues to i8**
  %call = call i32 @cudaMalloc(i8** %1, i64 16)
  %2 = load i32** %dvalues, align 8
  %3 = bitcast i32* %2 to i8*
  %arraydecay1 = getelementptr inbounds [4 x i32]* %values, i32 0, i32 0
  %4 = bitcast i32* %arraydecay1 to i8*
  %call2 = call i32 @cudaMemcpy(i8* %3, i8* %4, i64 16, i32 1)
  call void @_ZN4dim3C1Ejjj(%struct.dim3* %agg.tmp, i32 1, i32 1, i32 1)
  call void @_ZN4dim3C1Ejjj(%struct.dim3* %agg.tmp3, i32 4, i32 1, i32 1)
  %5 = bitcast %struct.dim3* %agg.tmp to { i64, i32 }*
  %6 = getelementptr { i64, i32 }* %5, i32 0, i32 0
  %7 = load i64* %6, align 1
  %8 = getelementptr { i64, i32 }* %5, i32 0, i32 1
  %9 = load i32* %8, align 1
  %10 = bitcast %struct.dim3* %agg.tmp3 to { i64, i32 }*
  %11 = getelementptr { i64, i32 }* %10, i32 0, i32 0
  %12 = load i64* %11, align 1
  %13 = getelementptr { i64, i32 }* %10, i32 0, i32 1
  %14 = load i32* %13, align 1
  %call4 = call i32 @cudaConfigureCall(i64 %7, i32 %9, i64 %12, i32 %14, i64 0, %struct.CUstream_st* null)
  %tobool = icmp ne i32 %call4, 0
  br i1 %tobool, label %kcall.end, label %kcall.configok

kcall.configok:                                   ; preds = %entry
  %15 = load i32** %dvalues, align 8
  call void @_Z13BitonicKernelPi(i32* %15)
  br label %kcall.end

kcall.end:                                        ; preds = %kcall.configok, %entry
  %arraydecay5 = getelementptr inbounds [4 x i32]* %values, i32 0, i32 0
  %16 = bitcast i32* %arraydecay5 to i8*
  %17 = load i32** %dvalues, align 8
  %18 = bitcast i32* %17 to i8*
  %call6 = call i32 @cudaMemcpy(i8* %16, i8* %18, i64 16, i32 1)
  store i32 1, i32* %i, align 4
  br label %for.cond

for.cond:                                         ; preds = %for.inc, %kcall.end
  %19 = load i32* %i, align 4
  %cmp = icmp slt i32 %19, 4
  br i1 %cmp, label %for.body, label %for.end

for.body:                                         ; preds = %for.cond
  %20 = load i32* %i, align 4
  %idxprom = sext i32 %20 to i64
  %arrayidx = getelementptr inbounds [4 x i32]* %values, i32 0, i64 %idxprom
  %21 = load i32* %arrayidx, align 4
  %22 = load i32* %i, align 4
  %sub = sub nsw i32 %22, 1
  %idxprom7 = sext i32 %sub to i64
  %arrayidx8 = getelementptr inbounds [4 x i32]* %values, i32 0, i64 %idxprom7
  %23 = load i32* %arrayidx8, align 4
  %cmp9 = icmp slt i32 %21, %23
  br i1 %cmp9, label %if.then, label %for.inc

if.then:                                          ; preds = %for.body
  %24 = load i32* %i, align 4
  %25 = load i32* %i, align 4
  %sub10 = sub nsw i32 %25, 1
  %call11 = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([67 x i8]* @.str4, i32 0, i32 0), i32 %24, i32 %sub10)
  br label %for.inc

for.inc:                                          ; preds = %for.body, %if.then
  %26 = load i32* %i, align 4
  %inc = add nsw i32 %26, 1
  store i32 %inc, i32* %i, align 4
  br label %for.cond

for.end:                                          ; preds = %for.cond
  %27 = load i32** %dvalues, align 8
  %28 = bitcast i32* %27 to i8*
  %call12 = call i32 @cudaFree(i8* %28)
  ret i32 0
}

declare void @klee_make_symbolic(i8*, i64, i8*)

declare i32 @cudaConfigureCall(i64, i32, i64, i32, i64, %struct.CUstream_st*)

declare i32 @printf(i8*, ...)

define linkonce_odr void @_ZN4dim3C2Ejjj(%struct.dim3* %this, i32 %vx, i32 %vy, i32 %vz) unnamed_addr nounwind uwtable section "__device__" align 2 {
entry:
  %this.addr = alloca %struct.dim3*, align 8
  %vx.addr = alloca i32, align 4
  %vy.addr = alloca i32, align 4
  %vz.addr = alloca i32, align 4
  store %struct.dim3* %this, %struct.dim3** %this.addr, align 8
  store i32 %vx, i32* %vx.addr, align 4
  store i32 %vy, i32* %vy.addr, align 4
  store i32 %vz, i32* %vz.addr, align 4
  %this1 = load %struct.dim3** %this.addr
  %x = getelementptr inbounds %struct.dim3* %this1, i32 0, i32 0
  %0 = load i32* %vx.addr, align 4
  store i32 %0, i32* %x, align 4
  %y = getelementptr inbounds %struct.dim3* %this1, i32 0, i32 1
  %1 = load i32* %vy.addr, align 4
  store i32 %1, i32* %y, align 4
  %z = getelementptr inbounds %struct.dim3* %this1, i32 0, i32 2
  %2 = load i32* %vz.addr, align 4
  store i32 %2, i32* %z, align 4
  ret void
}

define internal void @_GLOBAL__I_a() section ".text.startup" {
entry:
  call void @__cxx_global_var_init()
  call void @__cxx_global_var_init1()
  call void @__cxx_global_var_init2()
  call void @__cxx_global_var_init3()
  ret void
}

define i32 @cudaMalloc(i8** nocapture %devPtr, i64 %size) nounwind uwtable {
entry:
  %call = tail call i32 (...)* @__set_device() nounwind, !dbg !184
  %call1 = tail call noalias i8* @malloc(i64 %size) nounwind, !dbg !186
  store i8* %call1, i8** %devPtr, align 8, !dbg !186, !tbaa !187
  %call2 = tail call i32 (...)* @__clear_device() nounwind, !dbg !190
  ret i32 0, !dbg !191
}

declare i32 @__set_device(...)

declare noalias i8* @malloc(i64) nounwind

declare i32 @__clear_device(...)

define i32 @cudaMemcpy(i8* %dst, i8* %src, i64 %count, i32 %kind) nounwind uwtable {
entry:
  %call = tail call i32 (...)* bitcast (i8* (i8*, i8*, i64)* @memcpy to i32 (...)*)(i8* %dst, i8* %src, i64 %count) nounwind, !dbg !192
  ret i32 0, !dbg !194
}

define i32 @cudaMemset(i8* %devPtr, i32 %value, i64 %count) nounwind uwtable {
entry:
  %call = tail call i32 (...)* bitcast (i8* (i8*, i32, i64)* @memset to i32 (...)*)(i8* %devPtr, i32 %value, i64 %count) nounwind, !dbg !195
  ret i32 0, !dbg !197
}

define i32 @cudaFree(i8* nocapture %devPtr) nounwind uwtable {
entry:
  tail call void @free(i8* %devPtr) nounwind, !dbg !198
  ret i32 0, !dbg !200
}

declare void @free(i8* nocapture) nounwind

declare void @llvm.dbg.value(metadata, i64, metadata) nounwind readnone

define void @klee_div_zero_check(i64 %z) nounwind uwtable {
entry:
  %cmp = icmp eq i64 %z, 0, !dbg !201
  br i1 %cmp, label %if.then, label %if.end, !dbg !201

if.then:                                          ; preds = %entry
  tail call void @klee_report_error(i8* getelementptr inbounds ([22 x i8]* @.str7, i64 0, i64 0), i32 14, i8* getelementptr inbounds ([15 x i8]* @.str1, i64 0, i64 0), i8* getelementptr inbounds ([8 x i8]* @.str2, i64 0, i64 0)) noreturn nounwind, !dbg !
  unreachable, !dbg !203

if.end:                                           ; preds = %entry
  ret void, !dbg !204
}

declare void @klee_report_error(i8*, i32, i8*, i8*) noreturn

define i8* @memcpy(i8* %destaddr, i8* nocapture %srcaddr, i64 %len) nounwind uwtable {
entry:
  %cmp2 = icmp eq i64 %len, 0, !dbg !205
  br i1 %cmp2, label %while.end, label %while.body, !dbg !205

while.body:                                       ; preds = %while.body, %entry
  %src.05 = phi i8* [ %incdec.ptr, %while.body ], [ %srcaddr, %entry ]
  %dest.04 = phi i8* [ %incdec.ptr1, %while.body ], [ %destaddr, %entry ]
  %len.addr.03 = phi i64 [ %dec, %while.body ], [ %len, %entry ]
  %dec = add i64 %len.addr.03, -1, !dbg !205
  %incdec.ptr = getelementptr inbounds i8* %src.05, i64 1, !dbg !206
  %0 = load i8* %src.05, align 1, !dbg !206, !tbaa !188
  %incdec.ptr1 = getelementptr inbounds i8* %dest.04, i64 1, !dbg !206
  store i8 %0, i8* %dest.04, align 1, !dbg !206, !tbaa !188
  %cmp = icmp eq i64 %dec, 0, !dbg !205
  br i1 %cmp, label %while.end, label %while.body, !dbg !205

while.end:                                        ; preds = %while.body, %entry
  ret i8* %destaddr, !dbg !207
}

define i8* @memset(i8* %dst, i32 %s, i64 %count) nounwind uwtable {
entry:
  %cmp1 = icmp eq i64 %count, 0, !dbg !208
  br i1 %cmp1, label %while.end, label %while.body.lr.ph, !dbg !208

while.body.lr.ph:                                 ; preds = %entry
  %conv = trunc i32 %s to i8, !dbg !209
  br label %while.body, !dbg !208

while.body:                                       ; preds = %while.body, %while.body.lr.ph
  %a.03 = phi i8* [ %dst, %while.body.lr.ph ], [ %incdec.ptr, %while.body ]
  %count.addr.02 = phi i64 [ %count, %while.body.lr.ph ], [ %dec, %while.body ]
  %dec = add i64 %count.addr.02, -1, !dbg !208
  %incdec.ptr = getelementptr inbounds i8* %a.03, i64 1, !dbg !209
  store volatile i8 %conv, i8* %a.03, align 1, !dbg !209, !tbaa !188
  %cmp = icmp eq i64 %dec, 0, !dbg !208
  br i1 %cmp, label %while.end, label %while.body, !dbg !208

while.end:                                        ; preds = %while.body, %entry
  ret i8* %dst, !dbg !210
}

define internal void @klee.ctor_stub() {
entry:
  call void @_GLOBAL__I_a()
  ret void
}

!llvm.dbg.cu = !{!0, !120, !131, !151, !167}

!0 = metadata !{i32 786449, i32 0, i32 1, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/cudaMemManage.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", metadata !"clang version 3.2 (trunk 162409)", i1 tru
!1 = metadata !{metadata !2}
!2 = metadata !{metadata !3, metadata !70}
!3 = metadata !{i32 786436, null, metadata !"cudaError", metadata !4, i32 126, i64 32, i64 32, i32 0, i32 0, null, metadata !5, i32 0, i32 0} ; [ DW_TAG_enumeration_type ] [cudaError] [line 126, size 32, align 32, offset 0] [from ]
!4 = metadata !{i32 786473, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/include/cuda/driver_types.h", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!5 = metadata !{metadata !6, metadata !7, metadata !8, metadata !9, metadata !10, metadata !11, metadata !12, metadata !13, metadata !14, metadata !15, metadata !16, metadata !17, metadata !18, metadata !19, metadata !20, metadata !21, metadata !22, meta
!6 = metadata !{i32 786472, metadata !"cudaSuccess", i64 0} ; [ DW_TAG_enumerator ] [cudaSuccess :: 0]
!7 = metadata !{i32 786472, metadata !"cudaErrorMissingConfiguration", i64 1} ; [ DW_TAG_enumerator ] [cudaErrorMissingConfiguration :: 1]
!8 = metadata !{i32 786472, metadata !"cudaErrorMemoryAllocation", i64 2} ; [ DW_TAG_enumerator ] [cudaErrorMemoryAllocation :: 2]
!9 = metadata !{i32 786472, metadata !"cudaErrorInitializationError", i64 3} ; [ DW_TAG_enumerator ] [cudaErrorInitializationError :: 3]
!10 = metadata !{i32 786472, metadata !"cudaErrorLaunchFailure", i64 4} ; [ DW_TAG_enumerator ] [cudaErrorLaunchFailure :: 4]
!11 = metadata !{i32 786472, metadata !"cudaErrorPriorLaunchFailure", i64 5} ; [ DW_TAG_enumerator ] [cudaErrorPriorLaunchFailure :: 5]
!12 = metadata !{i32 786472, metadata !"cudaErrorLaunchTimeout", i64 6} ; [ DW_TAG_enumerator ] [cudaErrorLaunchTimeout :: 6]
!13 = metadata !{i32 786472, metadata !"cudaErrorLaunchOutOfResources", i64 7} ; [ DW_TAG_enumerator ] [cudaErrorLaunchOutOfResources :: 7]
!14 = metadata !{i32 786472, metadata !"cudaErrorInvalidDeviceFunction", i64 8} ; [ DW_TAG_enumerator ] [cudaErrorInvalidDeviceFunction :: 8]
!15 = metadata !{i32 786472, metadata !"cudaErrorInvalidConfiguration", i64 9} ; [ DW_TAG_enumerator ] [cudaErrorInvalidConfiguration :: 9]
!16 = metadata !{i32 786472, metadata !"cudaErrorInvalidDevice", i64 10} ; [ DW_TAG_enumerator ] [cudaErrorInvalidDevice :: 10]
!17 = metadata !{i32 786472, metadata !"cudaErrorInvalidValue", i64 11} ; [ DW_TAG_enumerator ] [cudaErrorInvalidValue :: 11]
!18 = metadata !{i32 786472, metadata !"cudaErrorInvalidPitchValue", i64 12} ; [ DW_TAG_enumerator ] [cudaErrorInvalidPitchValue :: 12]
!19 = metadata !{i32 786472, metadata !"cudaErrorInvalidSymbol", i64 13} ; [ DW_TAG_enumerator ] [cudaErrorInvalidSymbol :: 13]
!20 = metadata !{i32 786472, metadata !"cudaErrorMapBufferObjectFailed", i64 14} ; [ DW_TAG_enumerator ] [cudaErrorMapBufferObjectFailed :: 14]
!21 = metadata !{i32 786472, metadata !"cudaErrorUnmapBufferObjectFailed", i64 15} ; [ DW_TAG_enumerator ] [cudaErrorUnmapBufferObjectFailed :: 15]
!22 = metadata !{i32 786472, metadata !"cudaErrorInvalidHostPointer", i64 16} ; [ DW_TAG_enumerator ] [cudaErrorInvalidHostPointer :: 16]
!23 = metadata !{i32 786472, metadata !"cudaErrorInvalidDevicePointer", i64 17} ; [ DW_TAG_enumerator ] [cudaErrorInvalidDevicePointer :: 17]
!24 = metadata !{i32 786472, metadata !"cudaErrorInvalidTexture", i64 18} ; [ DW_TAG_enumerator ] [cudaErrorInvalidTexture :: 18]
!25 = metadata !{i32 786472, metadata !"cudaErrorInvalidTextureBinding", i64 19} ; [ DW_TAG_enumerator ] [cudaErrorInvalidTextureBinding :: 19]
!26 = metadata !{i32 786472, metadata !"cudaErrorInvalidChannelDescriptor", i64 20} ; [ DW_TAG_enumerator ] [cudaErrorInvalidChannelDescriptor :: 20]
!27 = metadata !{i32 786472, metadata !"cudaErrorInvalidMemcpyDirection", i64 21} ; [ DW_TAG_enumerator ] [cudaErrorInvalidMemcpyDirection :: 21]
!28 = metadata !{i32 786472, metadata !"cudaErrorAddressOfConstant", i64 22} ; [ DW_TAG_enumerator ] [cudaErrorAddressOfConstant :: 22]
!29 = metadata !{i32 786472, metadata !"cudaErrorTextureFetchFailed", i64 23} ; [ DW_TAG_enumerator ] [cudaErrorTextureFetchFailed :: 23]
!30 = metadata !{i32 786472, metadata !"cudaErrorTextureNotBound", i64 24} ; [ DW_TAG_enumerator ] [cudaErrorTextureNotBound :: 24]
!31 = metadata !{i32 786472, metadata !"cudaErrorSynchronizationError", i64 25} ; [ DW_TAG_enumerator ] [cudaErrorSynchronizationError :: 25]
!32 = metadata !{i32 786472, metadata !"cudaErrorInvalidFilterSetting", i64 26} ; [ DW_TAG_enumerator ] [cudaErrorInvalidFilterSetting :: 26]
!33 = metadata !{i32 786472, metadata !"cudaErrorInvalidNormSetting", i64 27} ; [ DW_TAG_enumerator ] [cudaErrorInvalidNormSetting :: 27]
!34 = metadata !{i32 786472, metadata !"cudaErrorMixedDeviceExecution", i64 28} ; [ DW_TAG_enumerator ] [cudaErrorMixedDeviceExecution :: 28]
!35 = metadata !{i32 786472, metadata !"cudaErrorCudartUnloading", i64 29} ; [ DW_TAG_enumerator ] [cudaErrorCudartUnloading :: 29]
!36 = metadata !{i32 786472, metadata !"cudaErrorUnknown", i64 30} ; [ DW_TAG_enumerator ] [cudaErrorUnknown :: 30]
!37 = metadata !{i32 786472, metadata !"cudaErrorNotYetImplemented", i64 31} ; [ DW_TAG_enumerator ] [cudaErrorNotYetImplemented :: 31]
!38 = metadata !{i32 786472, metadata !"cudaErrorMemoryValueTooLarge", i64 32} ; [ DW_TAG_enumerator ] [cudaErrorMemoryValueTooLarge :: 32]
!39 = metadata !{i32 786472, metadata !"cudaErrorInvalidResourceHandle", i64 33} ; [ DW_TAG_enumerator ] [cudaErrorInvalidResourceHandle :: 33]
!40 = metadata !{i32 786472, metadata !"cudaErrorNotReady", i64 34} ; [ DW_TAG_enumerator ] [cudaErrorNotReady :: 34]
!41 = metadata !{i32 786472, metadata !"cudaErrorInsufficientDriver", i64 35} ; [ DW_TAG_enumerator ] [cudaErrorInsufficientDriver :: 35]
!42 = metadata !{i32 786472, metadata !"cudaErrorSetOnActiveProcess", i64 36} ; [ DW_TAG_enumerator ] [cudaErrorSetOnActiveProcess :: 36]
!43 = metadata !{i32 786472, metadata !"cudaErrorInvalidSurface", i64 37} ; [ DW_TAG_enumerator ] [cudaErrorInvalidSurface :: 37]
!44 = metadata !{i32 786472, metadata !"cudaErrorNoDevice", i64 38} ; [ DW_TAG_enumerator ] [cudaErrorNoDevice :: 38]
!45 = metadata !{i32 786472, metadata !"cudaErrorECCUncorrectable", i64 39} ; [ DW_TAG_enumerator ] [cudaErrorECCUncorrectable :: 39]
!46 = metadata !{i32 786472, metadata !"cudaErrorSharedObjectSymbolNotFound", i64 40} ; [ DW_TAG_enumerator ] [cudaErrorSharedObjectSymbolNotFound :: 40]
!47 = metadata !{i32 786472, metadata !"cudaErrorSharedObjectInitFailed", i64 41} ; [ DW_TAG_enumerator ] [cudaErrorSharedObjectInitFailed :: 41]
!48 = metadata !{i32 786472, metadata !"cudaErrorUnsupportedLimit", i64 42} ; [ DW_TAG_enumerator ] [cudaErrorUnsupportedLimit :: 42]
!49 = metadata !{i32 786472, metadata !"cudaErrorDuplicateVariableName", i64 43} ; [ DW_TAG_enumerator ] [cudaErrorDuplicateVariableName :: 43]
!50 = metadata !{i32 786472, metadata !"cudaErrorDuplicateTextureName", i64 44} ; [ DW_TAG_enumerator ] [cudaErrorDuplicateTextureName :: 44]
!51 = metadata !{i32 786472, metadata !"cudaErrorDuplicateSurfaceName", i64 45} ; [ DW_TAG_enumerator ] [cudaErrorDuplicateSurfaceName :: 45]
!52 = metadata !{i32 786472, metadata !"cudaErrorDevicesUnavailable", i64 46} ; [ DW_TAG_enumerator ] [cudaErrorDevicesUnavailable :: 46]
!53 = metadata !{i32 786472, metadata !"cudaErrorInvalidKernelImage", i64 47} ; [ DW_TAG_enumerator ] [cudaErrorInvalidKernelImage :: 47]
!54 = metadata !{i32 786472, metadata !"cudaErrorNoKernelImageForDevice", i64 48} ; [ DW_TAG_enumerator ] [cudaErrorNoKernelImageForDevice :: 48]
!55 = metadata !{i32 786472, metadata !"cudaErrorIncompatibleDriverContext", i64 49} ; [ DW_TAG_enumerator ] [cudaErrorIncompatibleDriverContext :: 49]
!56 = metadata !{i32 786472, metadata !"cudaErrorPeerAccessAlreadyEnabled", i64 50} ; [ DW_TAG_enumerator ] [cudaErrorPeerAccessAlreadyEnabled :: 50]
!57 = metadata !{i32 786472, metadata !"cudaErrorPeerAccessNotEnabled", i64 51} ; [ DW_TAG_enumerator ] [cudaErrorPeerAccessNotEnabled :: 51]
!58 = metadata !{i32 786472, metadata !"cudaErrorDeviceAlreadyInUse", i64 54} ; [ DW_TAG_enumerator ] [cudaErrorDeviceAlreadyInUse :: 54]
!59 = metadata !{i32 786472, metadata !"cudaErrorProfilerDisabled", i64 55} ; [ DW_TAG_enumerator ] [cudaErrorProfilerDisabled :: 55]
!60 = metadata !{i32 786472, metadata !"cudaErrorProfilerNotInitialized", i64 56} ; [ DW_TAG_enumerator ] [cudaErrorProfilerNotInitialized :: 56]
!61 = metadata !{i32 786472, metadata !"cudaErrorProfilerAlreadyStarted", i64 57} ; [ DW_TAG_enumerator ] [cudaErrorProfilerAlreadyStarted :: 57]
!62 = metadata !{i32 786472, metadata !"cudaErrorProfilerAlreadyStopped", i64 58} ; [ DW_TAG_enumerator ] [cudaErrorProfilerAlreadyStopped :: 58]
!63 = metadata !{i32 786472, metadata !"cudaErrorAssert", i64 59} ; [ DW_TAG_enumerator ] [cudaErrorAssert :: 59]
!64 = metadata !{i32 786472, metadata !"cudaErrorTooManyPeers", i64 60} ; [ DW_TAG_enumerator ] [cudaErrorTooManyPeers :: 60]
!65 = metadata !{i32 786472, metadata !"cudaErrorHostMemoryAlreadyRegistered", i64 61} ; [ DW_TAG_enumerator ] [cudaErrorHostMemoryAlreadyRegistered :: 61]
!66 = metadata !{i32 786472, metadata !"cudaErrorHostMemoryNotRegistered", i64 62} ; [ DW_TAG_enumerator ] [cudaErrorHostMemoryNotRegistered :: 62]
!67 = metadata !{i32 786472, metadata !"cudaErrorOperatingSystem", i64 63} ; [ DW_TAG_enumerator ] [cudaErrorOperatingSystem :: 63]
!68 = metadata !{i32 786472, metadata !"cudaErrorStartupFailure", i64 127} ; [ DW_TAG_enumerator ] [cudaErrorStartupFailure :: 127]
!69 = metadata !{i32 786472, metadata !"cudaErrorApiFailureBase", i64 10000} ; [ DW_TAG_enumerator ] [cudaErrorApiFailureBase :: 10000]
!70 = metadata !{i32 786436, null, metadata !"cudaMemcpyKind", metadata !4, i32 620, i64 32, i64 32, i32 0, i32 0, null, metadata !71, i32 0, i32 0} ; [ DW_TAG_enumeration_type ] [cudaMemcpyKind] [line 620, size 32, align 32, offset 0] [from ]
!71 = metadata !{metadata !72, metadata !73, metadata !74, metadata !75, metadata !76}
!72 = metadata !{i32 786472, metadata !"cudaMemcpyHostToHost", i64 0} ; [ DW_TAG_enumerator ] [cudaMemcpyHostToHost :: 0]
!73 = metadata !{i32 786472, metadata !"cudaMemcpyHostToDevice", i64 1} ; [ DW_TAG_enumerator ] [cudaMemcpyHostToDevice :: 1]
!74 = metadata !{i32 786472, metadata !"cudaMemcpyDeviceToHost", i64 2} ; [ DW_TAG_enumerator ] [cudaMemcpyDeviceToHost :: 2]
!75 = metadata !{i32 786472, metadata !"cudaMemcpyDeviceToDevice", i64 3} ; [ DW_TAG_enumerator ] [cudaMemcpyDeviceToDevice :: 3]
!76 = metadata !{i32 786472, metadata !"cudaMemcpyDefault", i64 4} ; [ DW_TAG_enumerator ] [cudaMemcpyDefault :: 4]
!77 = metadata !{metadata !78}
!78 = metadata !{i32 0}
!79 = metadata !{metadata !80}
!80 = metadata !{metadata !81, metadata !94, metadata !105, metadata !114}
!81 = metadata !{i32 786478, i32 0, metadata !82, metadata !"cudaMalloc", metadata !"cudaMalloc", metadata !"", metadata !82, i32 13, metadata !83, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, i32 (i8**, i64)* @cudaMalloc, null, null, metadat
!82 = metadata !{i32 786473, metadata !"cudaMemManage.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!83 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !84, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!84 = metadata !{metadata !85, metadata !86, metadata !88}
!85 = metadata !{i32 786454, null, metadata !"cudaError_t", metadata !82, i32 1001, i64 0, i64 0, i64 0, i32 0, metadata !3} ; [ DW_TAG_typedef ] [cudaError_t] [line 1001, size 0, align 0, offset 0] [from cudaError]
!86 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !87} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!87 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, null} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!88 = metadata !{i32 786454, null, metadata !"size_t", metadata !82, i32 35, i64 0, i64 0, i64 0, i32 0, metadata !89} ; [ DW_TAG_typedef ] [size_t] [line 35, size 0, align 0, offset 0] [from long unsigned int]
!89 = metadata !{i32 786468, null, metadata !"long unsigned int", null, i32 0, i64 64, i64 64, i64 0, i32 0, i32 7} ; [ DW_TAG_base_type ] [long unsigned int] [line 0, size 64, align 64, offset 0, enc DW_ATE_unsigned]
!90 = metadata !{metadata !91}
!91 = metadata !{metadata !92, metadata !93}
!92 = metadata !{i32 786689, metadata !81, metadata !"devPtr", metadata !82, i32 16777229, metadata !86, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [devPtr] [line 13]
!93 = metadata !{i32 786689, metadata !81, metadata !"size", metadata !82, i32 33554445, metadata !88, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [size] [line 13]
!94 = metadata !{i32 786478, i32 0, metadata !82, metadata !"cudaMemcpy", metadata !"cudaMemcpy", metadata !"", metadata !82, i32 21, metadata !95, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, i32 (i8*, i8*, i64, i32)* @cudaMemcpy, null, null
!95 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !96, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!96 = metadata !{metadata !85, metadata !87, metadata !97, metadata !88, metadata !70}
!97 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !98} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!98 = metadata !{i32 786470, null, metadata !"", null, i32 0, i64 0, i64 0, i64 0, i32 0, null} ; [ DW_TAG_const_type ] [line 0, size 0, align 0, offset 0] [from ]
!99 = metadata !{metadata !100}
!100 = metadata !{metadata !101, metadata !102, metadata !103, metadata !104}
!101 = metadata !{i32 786689, metadata !94, metadata !"dst", metadata !82, i32 16777237, metadata !87, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [dst] [line 21]
!102 = metadata !{i32 786689, metadata !94, metadata !"src", metadata !82, i32 33554453, metadata !97, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [src] [line 21]
!103 = metadata !{i32 786689, metadata !94, metadata !"count", metadata !82, i32 50331669, metadata !88, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [count] [line 21]
!104 = metadata !{i32 786689, metadata !94, metadata !"kind", metadata !82, i32 67108885, metadata !70, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [kind] [line 21]
!105 = metadata !{i32 786478, i32 0, metadata !82, metadata !"cudaMemset", metadata !"cudaMemset", metadata !"", metadata !82, i32 26, metadata !106, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, i32 (i8*, i32, i64)* @cudaMemset, null, null, m
!106 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !107, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!107 = metadata !{metadata !85, metadata !87, metadata !108, metadata !88}
!108 = metadata !{i32 786468, null, metadata !"int", null, i32 0, i64 32, i64 32, i64 0, i32 0, i32 5} ; [ DW_TAG_base_type ] [int] [line 0, size 32, align 32, offset 0, enc DW_ATE_signed]
!109 = metadata !{metadata !110}
!110 = metadata !{metadata !111, metadata !112, metadata !113}
!111 = metadata !{i32 786689, metadata !105, metadata !"devPtr", metadata !82, i32 16777242, metadata !87, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [devPtr] [line 26]
!112 = metadata !{i32 786689, metadata !105, metadata !"value", metadata !82, i32 33554458, metadata !108, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [value] [line 26]
!113 = metadata !{i32 786689, metadata !105, metadata !"count", metadata !82, i32 50331674, metadata !88, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [count] [line 26]
!114 = metadata !{i32 786478, i32 0, metadata !82, metadata !"cudaFree", metadata !"cudaFree", metadata !"", metadata !82, i32 31, metadata !115, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, i32 (i8*)* @cudaFree, null, null, metadata !117, i3
!115 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !116, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!116 = metadata !{metadata !85, metadata !87}
!117 = metadata !{metadata !118}
!118 = metadata !{metadata !119}
!119 = metadata !{i32 786689, metadata !114, metadata !"devPtr", metadata !82, i32 16777247, metadata !87, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [devPtr] [line 31]
!120 = metadata !{i32 786449, i32 0, i32 1, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/klee_div_zero_check.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", metadata !"clang version 3.2 (trunk 162409)"
!121 = metadata !{metadata !122}
!122 = metadata !{metadata !123}
!123 = metadata !{i32 786478, i32 0, metadata !124, metadata !"klee_div_zero_check", metadata !"klee_div_zero_check", metadata !"", metadata !124, i32 12, metadata !125, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, void (i64)* @klee_div_zero_
!124 = metadata !{i32 786473, metadata !"klee_div_zero_check.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!125 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !126, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!126 = metadata !{null, metadata !127}
!127 = metadata !{i32 786468, null, metadata !"long long int", null, i32 0, i64 64, i64 64, i64 0, i32 0, i32 5} ; [ DW_TAG_base_type ] [long long int] [line 0, size 64, align 64, offset 0, enc DW_ATE_signed]
!128 = metadata !{metadata !129}
!129 = metadata !{metadata !130}
!130 = metadata !{i32 786689, metadata !123, metadata !"z", metadata !124, i32 16777228, metadata !127, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [z] [line 12]
!131 = metadata !{i32 786449, i32 0, i32 1, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memcpy.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", metadata !"clang version 3.2 (trunk 162409)", i1 true, i1
!132 = metadata !{metadata !133}
!133 = metadata !{metadata !134}
!134 = metadata !{i32 786478, i32 0, metadata !135, metadata !"memcpy", metadata !"memcpy", metadata !"", metadata !135, i32 12, metadata !136, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, i8* (i8*, i8*, i64)* @memcpy, null, null, metadata !1
!135 = metadata !{i32 786473, metadata !"memcpy.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!136 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !137, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!137 = metadata !{metadata !87, metadata !87, metadata !97, metadata !138}
!138 = metadata !{i32 786454, null, metadata !"size_t", metadata !135, i32 35, i64 0, i64 0, i64 0, i32 0, metadata !89} ; [ DW_TAG_typedef ] [size_t] [line 35, size 0, align 0, offset 0] [from long unsigned int]
!139 = metadata !{metadata !140}
!140 = metadata !{metadata !141, metadata !142, metadata !143, metadata !144, metadata !148}
!141 = metadata !{i32 786689, metadata !134, metadata !"destaddr", metadata !135, i32 16777228, metadata !87, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [destaddr] [line 12]
!142 = metadata !{i32 786689, metadata !134, metadata !"srcaddr", metadata !135, i32 33554444, metadata !97, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [srcaddr] [line 12]
!143 = metadata !{i32 786689, metadata !134, metadata !"len", metadata !135, i32 50331660, metadata !138, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [len] [line 12]
!144 = metadata !{i32 786688, metadata !145, metadata !"dest", metadata !135, i32 13, metadata !146, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [dest] [line 13]
!145 = metadata !{i32 786443, metadata !134, i32 12, i32 63, metadata !135, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memcpy.c]
!146 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !147} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from char]
!147 = metadata !{i32 786468, null, metadata !"char", null, i32 0, i64 8, i64 8, i64 0, i32 0, i32 6} ; [ DW_TAG_base_type ] [char] [line 0, size 8, align 8, offset 0, enc DW_ATE_signed_char]
!148 = metadata !{i32 786688, metadata !145, metadata !"src", metadata !135, i32 14, metadata !149, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [src] [line 14]
!149 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !150} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!150 = metadata !{i32 786470, null, metadata !"", null, i32 0, i64 0, i64 0, i64 0, i32 0, metadata !147} ; [ DW_TAG_const_type ] [line 0, size 0, align 0, offset 0] [from char]
!151 = metadata !{i32 786449, i32 0, i32 1, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memmove.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", metadata !"clang version 3.2 (trunk 162409)", i1 true, i
!152 = metadata !{metadata !153}
!153 = metadata !{metadata !154}
!154 = metadata !{i32 786478, i32 0, metadata !155, metadata !"memmove", metadata !"memmove", metadata !"", metadata !155, i32 12, metadata !156, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, null, null, null, metadata !159, i32 12} ; [ DW_TAG
!155 = metadata !{i32 786473, metadata !"memmove.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!156 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !157, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!157 = metadata !{metadata !87, metadata !87, metadata !97, metadata !158}
!158 = metadata !{i32 786454, null, metadata !"size_t", metadata !155, i32 35, i64 0, i64 0, i64 0, i32 0, metadata !89} ; [ DW_TAG_typedef ] [size_t] [line 35, size 0, align 0, offset 0] [from long unsigned int]
!159 = metadata !{metadata !160}
!160 = metadata !{metadata !161, metadata !162, metadata !163, metadata !164, metadata !166}
!161 = metadata !{i32 786689, metadata !154, metadata !"dst", metadata !155, i32 16777228, metadata !87, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [dst] [line 12]
!162 = metadata !{i32 786689, metadata !154, metadata !"src", metadata !155, i32 33554444, metadata !97, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [src] [line 12]
!163 = metadata !{i32 786689, metadata !154, metadata !"count", metadata !155, i32 50331660, metadata !158, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [count] [line 12]
!164 = metadata !{i32 786688, metadata !165, metadata !"a", metadata !155, i32 14, metadata !146, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [a] [line 14]
!165 = metadata !{i32 786443, metadata !154, i32 12, i32 57, metadata !155, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memmove.c]
!166 = metadata !{i32 786688, metadata !165, metadata !"b", metadata !155, i32 15, metadata !149, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [b] [line 15]
!167 = metadata !{i32 786449, i32 0, i32 1, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memset.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", metadata !"clang version 3.2 (trunk 162409)", i1 true, i1
!168 = metadata !{metadata !169}
!169 = metadata !{metadata !170}
!170 = metadata !{i32 786478, i32 0, metadata !171, metadata !"memset", metadata !"memset", metadata !"", metadata !171, i32 12, metadata !172, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, i8* (i8*, i32, i64)* @memset, null, null, metadata !1
!171 = metadata !{i32 786473, metadata !"memset.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!172 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !173, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!173 = metadata !{metadata !87, metadata !87, metadata !108, metadata !174}
!174 = metadata !{i32 786454, null, metadata !"size_t", metadata !171, i32 35, i64 0, i64 0, i64 0, i32 0, metadata !89} ; [ DW_TAG_typedef ] [size_t] [line 35, size 0, align 0, offset 0] [from long unsigned int]
!175 = metadata !{metadata !176}
!176 = metadata !{metadata !177, metadata !178, metadata !179, metadata !180}
!177 = metadata !{i32 786689, metadata !170, metadata !"dst", metadata !171, i32 16777228, metadata !87, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [dst] [line 12]
!178 = metadata !{i32 786689, metadata !170, metadata !"s", metadata !171, i32 33554444, metadata !108, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [s] [line 12]
!179 = metadata !{i32 786689, metadata !170, metadata !"count", metadata !171, i32 50331660, metadata !174, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [count] [line 12]
!180 = metadata !{i32 786688, metadata !181, metadata !"a", metadata !171, i32 13, metadata !182, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [a] [line 13]
!181 = metadata !{i32 786443, metadata !170, i32 12, i32 47, metadata !171, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memset.c]
!182 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !183} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!183 = metadata !{i32 786485, null, metadata !"", null, i32 0, i64 0, i64 0, i64 0, i32 0, metadata !147} ; [ DW_TAG_volatile_type ] [line 0, size 0, align 0, offset 0] [from char]
!184 = metadata !{i32 14, i32 3, metadata !185, null}
!185 = metadata !{i32 786443, metadata !81, i32 13, i32 52, metadata !82, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/cudaMemManage.c]
!186 = metadata !{i32 15, i32 21, metadata !185, null}
!187 = metadata !{metadata !"any pointer", metadata !188}
!188 = metadata !{metadata !"omnipotent char", metadata !189}
!189 = metadata !{metadata !"Simple C/C++ TBAA"}
!190 = metadata !{i32 16, i32 3, metadata !185, null}
!191 = metadata !{i32 18, i32 3, metadata !185, null}
!192 = metadata !{i32 22, i32 3, metadata !193, null}
!193 = metadata !{i32 786443, metadata !94, i32 21, i32 92, metadata !82, i32 1} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/cudaMemManage.c]
!194 = metadata !{i32 23, i32 3, metadata !193, null}
!195 = metadata !{i32 27, i32 3, metadata !196, null}
!196 = metadata !{i32 786443, metadata !105, i32 26, i32 63, metadata !82, i32 2} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/cudaMemManage.c]
!197 = metadata !{i32 28, i32 3, metadata !196, null}
!198 = metadata !{i32 32, i32 3, metadata !199, null}
!199 = metadata !{i32 786443, metadata !114, i32 31, i32 36, metadata !82, i32 3} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/cudaMemManage.c]
!200 = metadata !{i32 33, i32 3, metadata !199, null}
!201 = metadata !{i32 13, i32 3, metadata !202, null}
!202 = metadata !{i32 786443, metadata !123, i32 12, i32 39, metadata !124, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/klee_div_zero_check.c]
!203 = metadata !{i32 14, i32 5, metadata !202, null}
!204 = metadata !{i32 15, i32 1, metadata !202, null}
!205 = metadata !{i32 16, i32 3, metadata !145, null}
!206 = metadata !{i32 17, i32 5, metadata !145, null}
!207 = metadata !{i32 18, i32 3, metadata !145, null}
!208 = metadata !{i32 14, i32 5, metadata !181, null}
!209 = metadata !{i32 15, i32 7, metadata !181, null}
!210 = metadata !{i32 16, i32 5, metadata !181, null}
