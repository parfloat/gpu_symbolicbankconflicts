; ModuleID = 'bitonic'
target datalayout = "e-p:64:64:64-i1:8:8-i8:8:8-i16:16:16-i32:32:32-i64:64:64-f32:32:32-f64:64:64-v64:64:64-v128:128:128-a0:0:64-s0:64:64-f80:128:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%struct.dim3 = type { i32, i32, i32 }
%struct.CUstream_st = type opaque

@shared = global [4 x i32] zeroinitializer, section "__shared__", align 16
@gridDim = global %struct.dim3 zeroinitializer, align 4
@blockIdx = global %struct.dim3 zeroinitializer, align 4
@blockDim = global %struct.dim3 zeroinitializer, align 4
@threadIdx = global %struct.dim3 zeroinitializer, align 4
@.str = private unnamed_addr constant [6 x i8] c"input\00", align 1
@.str4 = private unnamed_addr constant [67 x i8] c"The sorting algorithm is incorrect since values[%d] < values[%d]!\0A\00", align 1
@llvm.global_ctors = appending global [1 x { i32, void ()* }] [{ i32, void ()* } { i32 65535, void ()* @_GLOBAL__I_a }]

define void @_Z13BitonicKernelPi(i32* %values) uwtable {
entry:
  %values.addr = alloca i32*, align 8
  %tid = alloca i32, align 4
  %k = alloca i32, align 4
  %j = alloca i32, align 4
  %ixj = alloca i32, align 4
  store i32* %values, i32** %values.addr, align 8
  %0 = load i32* getelementptr inbounds (%struct.dim3* @threadIdx, i32 0, i32 0), align 4
  store i32 %0, i32* %tid, align 4
  %1 = load i32* %tid, align 4
  %idxprom = zext i32 %1 to i64
  %2 = load i32** %values.addr, align 8
  %arrayidx = getelementptr inbounds i32* %2, i64 %idxprom
  %3 = load i32* %arrayidx, align 4
  %4 = load i32* %tid, align 4
  %idxprom1 = zext i32 %4 to i64
  %arrayidx2 = getelementptr inbounds [4 x i32]* @shared, i32 0, i64 %idxprom1
  store i32 %3, i32* %arrayidx2, align 4
  call void @__syncthreads()
  store i32 2, i32* %k, align 4
  br label %for.cond

for.cond:                                         ; preds = %for.inc33, %entry
  %5 = load i32* %k, align 4
  %6 = load i32* getelementptr inbounds (%struct.dim3* @blockDim, i32 0, i32 0), align 4
  %cmp = icmp ule i32 %5, %6
  br i1 %cmp, label %for.body, label %for.end34

for.body:                                         ; preds = %for.cond
  %7 = load i32* %k, align 4
  %div = udiv i32 %7, 2
  store i32 %div, i32* %j, align 4
  br label %for.cond3

for.cond3:                                        ; preds = %for.inc, %for.body
  %8 = load i32* %j, align 4
  %cmp4 = icmp ugt i32 %8, 0
  br i1 %cmp4, label %for.body5, label %for.end

for.body5:                                        ; preds = %for.cond3
  %9 = load i32* %tid, align 4
  %10 = load i32* %j, align 4
  %xor = xor i32 %9, %10
  store i32 %xor, i32* %ixj, align 4
  %11 = load i32* %ixj, align 4
  %12 = load i32* %tid, align 4
  %cmp6 = icmp ugt i32 %11, %12
  br i1 %cmp6, label %if.then, label %if.end31

if.then:                                          ; preds = %for.body5
  %13 = load i32* %tid, align 4
  %14 = load i32* %k, align 4
  %and = and i32 %13, %14
  %cmp7 = icmp eq i32 %and, 0
  br i1 %cmp7, label %if.then8, label %if.else

if.then8:                                         ; preds = %if.then
  %15 = load i32* %tid, align 4
  %idxprom9 = zext i32 %15 to i64
  %arrayidx10 = getelementptr inbounds [4 x i32]* @shared, i32 0, i64 %idxprom9
  %16 = load i32* %arrayidx10, align 4
  %17 = load i32* %ixj, align 4
  %idxprom11 = zext i32 %17 to i64
  %arrayidx12 = getelementptr inbounds [4 x i32]* @shared, i32 0, i64 %idxprom11
  %18 = load i32* %arrayidx12, align 4
  %cmp13 = icmp sgt i32 %16, %18
  br i1 %cmp13, label %if.then14, label %if.end

if.then14:                                        ; preds = %if.then8
  %19 = load i32* %tid, align 4
  %idxprom15 = zext i32 %19 to i64
  %arrayidx16 = getelementptr inbounds [4 x i32]* @shared, i32 0, i64 %idxprom15
  %20 = load i32* %ixj, align 4
  %idxprom17 = zext i32 %20 to i64
  %arrayidx18 = getelementptr inbounds [4 x i32]* @shared, i32 0, i64 %idxprom17
  call void @_Z4swapRiS_(i32* %arrayidx16, i32* %arrayidx18)
  br label %if.end

if.end:                                           ; preds = %if.then14, %if.then8
  br label %if.end30

if.else:                                          ; preds = %if.then
  %21 = load i32* %tid, align 4
  %idxprom19 = zext i32 %21 to i64
  %arrayidx20 = getelementptr inbounds [4 x i32]* @shared, i32 0, i64 %idxprom19
  %22 = load i32* %arrayidx20, align 4
  %23 = load i32* %ixj, align 4
  %idxprom21 = zext i32 %23 to i64
  %arrayidx22 = getelementptr inbounds [4 x i32]* @shared, i32 0, i64 %idxprom21
  %24 = load i32* %arrayidx22, align 4
  %cmp23 = icmp slt i32 %22, %24
  br i1 %cmp23, label %if.then24, label %if.end29

if.then24:                                        ; preds = %if.else
  %25 = load i32* %tid, align 4
  %idxprom25 = zext i32 %25 to i64
  %arrayidx26 = getelementptr inbounds [4 x i32]* @shared, i32 0, i64 %idxprom25
  %26 = load i32* %ixj, align 4
  %idxprom27 = zext i32 %26 to i64
  %arrayidx28 = getelementptr inbounds [4 x i32]* @shared, i32 0, i64 %idxprom27
  call void @_Z4swapRiS_(i32* %arrayidx26, i32* %arrayidx28)
  br label %if.end29

if.end29:                                         ; preds = %if.then24, %if.else
  br label %if.end30

if.end30:                                         ; preds = %if.end29, %if.end
  br label %if.end31

if.end31:                                         ; preds = %if.end30, %for.body5
  call void @__syncthreads()
  br label %for.inc

for.inc:                                          ; preds = %if.end31
  %27 = load i32* %j, align 4
  %div32 = udiv i32 %27, 2
  store i32 %div32, i32* %j, align 4
  br label %for.cond3

for.end:                                          ; preds = %for.cond3
  br label %for.inc33

for.inc33:                                        ; preds = %for.end
  %28 = load i32* %k, align 4
  %mul = mul i32 %28, 2
  store i32 %mul, i32* %k, align 4
  br label %for.cond

for.end34:                                        ; preds = %for.cond
  %29 = load i32* %tid, align 4
  %idxprom35 = zext i32 %29 to i64
  %arrayidx36 = getelementptr inbounds [4 x i32]* @shared, i32 0, i64 %idxprom35
  %30 = load i32* %arrayidx36, align 4
  %31 = load i32* %tid, align 4
  %idxprom37 = zext i32 %31 to i64
  %32 = load i32** %values.addr, align 8
  %arrayidx38 = getelementptr inbounds i32* %32, i64 %idxprom37
  store i32 %30, i32* %arrayidx38, align 4
  ret void
}

declare void @__syncthreads() section "__device__"

define linkonce_odr void @_Z4swapRiS_(i32* %a, i32* %b) nounwind uwtable inlinehint section "__device__" {
entry:
  %a.addr = alloca i32*, align 8
  %b.addr = alloca i32*, align 8
  %tmp = alloca i32, align 4
  store i32* %a, i32** %a.addr, align 8
  store i32* %b, i32** %b.addr, align 8
  %0 = load i32** %a.addr, align 8
  %1 = load i32* %0, align 4
  store i32 %1, i32* %tmp, align 4
  %2 = load i32** %b.addr, align 8
  %3 = load i32* %2, align 4
  %4 = load i32** %a.addr, align 8
  store i32 %3, i32* %4, align 4
  %5 = load i32* %tmp, align 4
  %6 = load i32** %b.addr, align 8
  store i32 %5, i32* %6, align 4
  ret void
}

define internal void @__cxx_global_var_init() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @gridDim, i32 1, i32 1, i32 1)
  ret void
}

define linkonce_odr void @_ZN4dim3C1Ejjj(%struct.dim3* %this, i32 %vx, i32 %vy, i32 %vz) unnamed_addr uwtable section "__device__" align 2 {
entry:
  %this.addr = alloca %struct.dim3*, align 8
  %vx.addr = alloca i32, align 4
  %vy.addr = alloca i32, align 4
  %vz.addr = alloca i32, align 4
  store %struct.dim3* %this, %struct.dim3** %this.addr, align 8
  store i32 %vx, i32* %vx.addr, align 4
  store i32 %vy, i32* %vy.addr, align 4
  store i32 %vz, i32* %vz.addr, align 4
  %this1 = load %struct.dim3** %this.addr
  %0 = load i32* %vx.addr, align 4
  %1 = load i32* %vy.addr, align 4
  %2 = load i32* %vz.addr, align 4
  call void @_ZN4dim3C2Ejjj(%struct.dim3* %this1, i32 %0, i32 %1, i32 %2)
  ret void
}

define internal void @__cxx_global_var_init1() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @blockIdx, i32 1, i32 1, i32 1)
  ret void
}

define internal void @__cxx_global_var_init2() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @blockDim, i32 1, i32 1, i32 1)
  ret void
}

define internal void @__cxx_global_var_init3() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @threadIdx, i32 1, i32 1, i32 1)
  ret void
}

declare i32 @cudaSetupArgument(i8*, i64, i64)

declare i32 @cudaLaunch(i8*)

define i32 @main() uwtable {
entry:
  %retval = alloca i32, align 4
  %values = alloca [4 x i32], align 16
  %dvalues = alloca i32*, align 8
  %agg.tmp = alloca %struct.dim3, align 4
  %agg.tmp3 = alloca %struct.dim3, align 4
  %i = alloca i32, align 4
  store i32 0, i32* %retval
  %arraydecay = getelementptr inbounds [4 x i32]* %values, i32 0, i32 0
  %0 = bitcast i32* %arraydecay to i8*
  call void @klee_make_symbolic(i8* %0, i64 16, i8* getelementptr inbounds ([6 x i8]* @.str, i32 0, i32 0))
  %1 = bitcast i32** %dvalues to i8**
  %call = call i32 @cudaMalloc(i8** %1, i64 16)
  %2 = load i32** %dvalues, align 8
  %3 = bitcast i32* %2 to i8*
  %arraydecay1 = getelementptr inbounds [4 x i32]* %values, i32 0, i32 0
  %4 = bitcast i32* %arraydecay1 to i8*
  %call2 = call i32 @cudaMemcpy(i8* %3, i8* %4, i64 16, i32 1)
  call void @_ZN4dim3C1Ejjj(%struct.dim3* %agg.tmp, i32 1, i32 1, i32 1)
  call void @_ZN4dim3C1Ejjj(%struct.dim3* %agg.tmp3, i32 4, i32 1, i32 1)
  %5 = bitcast %struct.dim3* %agg.tmp to { i64, i32 }*
  %6 = getelementptr { i64, i32 }* %5, i32 0, i32 0
  %7 = load i64* %6, align 1
  %8 = getelementptr { i64, i32 }* %5, i32 0, i32 1
  %9 = load i32* %8, align 1
  %10 = bitcast %struct.dim3* %agg.tmp3 to { i64, i32 }*
  %11 = getelementptr { i64, i32 }* %10, i32 0, i32 0
  %12 = load i64* %11, align 1
  %13 = getelementptr { i64, i32 }* %10, i32 0, i32 1
  %14 = load i32* %13, align 1
  %call4 = call i32 @cudaConfigureCall(i64 %7, i32 %9, i64 %12, i32 %14, i64 0, %struct.CUstream_st* null)
  %tobool = icmp ne i32 %call4, 0
  br i1 %tobool, label %kcall.end, label %kcall.configok

kcall.configok:                                   ; preds = %entry
  %15 = load i32** %dvalues, align 8
  call void @_Z13BitonicKernelPi(i32* %15)
  br label %kcall.end

kcall.end:                                        ; preds = %kcall.configok, %entry
  %arraydecay5 = getelementptr inbounds [4 x i32]* %values, i32 0, i32 0
  %16 = bitcast i32* %arraydecay5 to i8*
  %17 = load i32** %dvalues, align 8
  %18 = bitcast i32* %17 to i8*
  %call6 = call i32 @cudaMemcpy(i8* %16, i8* %18, i64 16, i32 1)
  store i32 1, i32* %i, align 4
  br label %for.cond

for.cond:                                         ; preds = %for.inc, %kcall.end
  %19 = load i32* %i, align 4
  %cmp = icmp slt i32 %19, 4
  br i1 %cmp, label %for.body, label %for.end

for.body:                                         ; preds = %for.cond
  %20 = load i32* %i, align 4
  %idxprom = sext i32 %20 to i64
  %arrayidx = getelementptr inbounds [4 x i32]* %values, i32 0, i64 %idxprom
  %21 = load i32* %arrayidx, align 4
  %22 = load i32* %i, align 4
  %sub = sub nsw i32 %22, 1
  %idxprom7 = sext i32 %sub to i64
  %arrayidx8 = getelementptr inbounds [4 x i32]* %values, i32 0, i64 %idxprom7
  %23 = load i32* %arrayidx8, align 4
  %cmp9 = icmp slt i32 %21, %23
  br i1 %cmp9, label %if.then, label %if.end

if.then:                                          ; preds = %for.body
  %24 = load i32* %i, align 4
  %25 = load i32* %i, align 4
  %sub10 = sub nsw i32 %25, 1
  %call11 = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([67 x i8]* @.str4, i32 0, i32 0), i32 %24, i32 %sub10)
  br label %if.end

if.end:                                           ; preds = %if.then, %for.body
  br label %for.inc

for.inc:                                          ; preds = %if.end
  %26 = load i32* %i, align 4
  %inc = add nsw i32 %26, 1
  store i32 %inc, i32* %i, align 4
  br label %for.cond

for.end:                                          ; preds = %for.cond
  %27 = load i32** %dvalues, align 8
  %28 = bitcast i32* %27 to i8*
  %call12 = call i32 @cudaFree(i8* %28)
  ret i32 0
}

declare void @klee_make_symbolic(i8*, i64, i8*)

declare i32 @cudaMalloc(i8**, i64)

declare i32 @cudaMemcpy(i8*, i8*, i64, i32)

declare i32 @cudaConfigureCall(i64, i32, i64, i32, i64, %struct.CUstream_st*)

declare i32 @printf(i8*, ...)

declare i32 @cudaFree(i8*)

define linkonce_odr void @_ZN4dim3C2Ejjj(%struct.dim3* %this, i32 %vx, i32 %vy, i32 %vz) unnamed_addr nounwind uwtable section "__device__" align 2 {
entry:
  %this.addr = alloca %struct.dim3*, align 8
  %vx.addr = alloca i32, align 4
  %vy.addr = alloca i32, align 4
  %vz.addr = alloca i32, align 4
  store %struct.dim3* %this, %struct.dim3** %this.addr, align 8
  store i32 %vx, i32* %vx.addr, align 4
  store i32 %vy, i32* %vy.addr, align 4
  store i32 %vz, i32* %vz.addr, align 4
  %this1 = load %struct.dim3** %this.addr
  %x = getelementptr inbounds %struct.dim3* %this1, i32 0, i32 0
  %0 = load i32* %vx.addr, align 4
  store i32 %0, i32* %x, align 4
  %y = getelementptr inbounds %struct.dim3* %this1, i32 0, i32 1
  %1 = load i32* %vy.addr, align 4
  store i32 %1, i32* %y, align 4
  %z = getelementptr inbounds %struct.dim3* %this1, i32 0, i32 2
  %2 = load i32* %vz.addr, align 4
  store i32 %2, i32* %z, align 4
  ret void
}

define internal void @_GLOBAL__I_a() section ".text.startup" {
entry:
  call void @__cxx_global_var_init()
  call void @__cxx_global_var_init1()
  call void @__cxx_global_var_init2()
  call void @__cxx_global_var_init3()
  ret void
}
