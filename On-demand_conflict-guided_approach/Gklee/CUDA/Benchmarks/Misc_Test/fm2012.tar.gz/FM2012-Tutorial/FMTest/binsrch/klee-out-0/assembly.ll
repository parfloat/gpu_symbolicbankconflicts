; ModuleID = 'binsrch'
target datalayout = "e-p:64:64:64-i1:8:8-i8:8:8-i16:16:16-i32:32:32-i64:64:64-f32:32:32-f64:64:64-v64:64:64-v128:128:128-a0:0:64-s0:64:64-f80:128:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%struct.dim3 = type { i32, i32, i32 }

@gridDim = global %struct.dim3 zeroinitializer, align 4
@blockIdx = global %struct.dim3 zeroinitializer, align 4
@blockDim = global %struct.dim3 zeroinitializer, align 4
@threadIdx = global %struct.dim3 zeroinitializer, align 4
@.str = private unnamed_addr constant [5 x i8] c"item\00", align 1
@.str4 = private unnamed_addr constant [4 x i8] c"str\00", align 1
@.str5 = private unnamed_addr constant [2 x i8] c"*\00", align 1
@.str6 = private unnamed_addr constant [2 x i8] c"L\00", align 1
@.str7 = private unnamed_addr constant [2 x i8] c"H\00", align 1
@.str8 = private unnamed_addr constant [7 x i8] c"found\0A\00", align 1
@.str9 = private unnamed_addr constant [11 x i8] c"not found\0A\00", align 1
@llvm.global_ctors = appending global [1 x { i32, void ()* }] [{ i32, void ()* } { i32 65535, void ()* @_GLOBAL__I_a }]
@.str1 = private unnamed_addr constant [22 x i8] c"klee_div_zero_check.c\00", align 1
@.str12 = private unnamed_addr constant [15 x i8] c"divide by zero\00", align 1
@.str2 = private unnamed_addr constant [8 x i8] c"div.err\00", align 1

define internal void @__cxx_global_var_init() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @gridDim, i32 1, i32 1, i32 1)
  ret void
}

define linkonce_odr void @_ZN4dim3C1Ejjj(%struct.dim3* %this, i32 %vx, i32 %vy, i32 %vz) unnamed_addr uwtable section "__device__" align 2 {
entry:
  %this.addr = alloca %struct.dim3*, align 8
  %vx.addr = alloca i32, align 4
  %vy.addr = alloca i32, align 4
  %vz.addr = alloca i32, align 4
  store %struct.dim3* %this, %struct.dim3** %this.addr, align 8
  store i32 %vx, i32* %vx.addr, align 4
  store i32 %vy, i32* %vy.addr, align 4
  store i32 %vz, i32* %vz.addr, align 4
  %this1 = load %struct.dim3** %this.addr
  %0 = load i32* %vx.addr, align 4
  %1 = load i32* %vy.addr, align 4
  %2 = load i32* %vz.addr, align 4
  call void @_ZN4dim3C2Ejjj(%struct.dim3* %this1, i32 %0, i32 %1, i32 %2)
  ret void
}

define internal void @__cxx_global_var_init1() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @blockIdx, i32 1, i32 1, i32 1)
  ret void
}

define internal void @__cxx_global_var_init2() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @blockDim, i32 1, i32 1, i32 1)
  ret void
}

define internal void @__cxx_global_var_init3() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @threadIdx, i32 1, i32 1, i32 1)
  ret void
}

define i32 @main() uwtable {
entry:
  call void @klee.ctor_stub()
  %retval = alloca i32, align 4
  %item = alloca i8, align 1
  %str = alloca [5 x i8], align 1
  %lo = alloca i32, align 4
  %hi = alloca i32, align 4
  %mid = alloca i32, align 4
  %found = alloca i32, align 4
  store i32 0, i32* %retval
  store i32 0, i32* %lo, align 4
  store i32 0, i32* %found, align 4
  call void @klee_make_symbolic(i8* %item, i64 1, i8* getelementptr inbounds ([5 x i8]* @.str, i32 0, i32 0))
  %arraydecay = getelementptr inbounds [5 x i8]* %str, i32 0, i32 0
  call void @klee_make_symbolic(i8* %arraydecay, i64 5, i8* getelementptr inbounds ([4 x i8]* @.str4, i32 0, i32 0))
  %arrayidx = getelementptr inbounds [5 x i8]* %str, i32 0, i64 0
  %0 = load i8* %arrayidx, align 1
  %conv = sext i8 %0 to i32
  %arrayidx1 = getelementptr inbounds [5 x i8]* %str, i32 0, i64 1
  %1 = load i8* %arrayidx1, align 1
  %conv2 = sext i8 %1 to i32
  %cmp = icmp sle i32 %conv, %conv2
  %conv3 = zext i1 %cmp to i64
  call void @klee_assume(i64 %conv3)
  %arrayidx4 = getelementptr inbounds [5 x i8]* %str, i32 0, i64 1
  %2 = load i8* %arrayidx4, align 1
  %conv5 = sext i8 %2 to i32
  %arrayidx6 = getelementptr inbounds [5 x i8]* %str, i32 0, i64 2
  %3 = load i8* %arrayidx6, align 1
  %conv7 = sext i8 %3 to i32
  %cmp8 = icmp sle i32 %conv5, %conv7
  %conv9 = zext i1 %cmp8 to i64
  call void @klee_assume(i64 %conv9)
  %arrayidx10 = getelementptr inbounds [5 x i8]* %str, i32 0, i64 2
  %4 = load i8* %arrayidx10, align 1
  %conv11 = sext i8 %4 to i32
  %arrayidx12 = getelementptr inbounds [5 x i8]* %str, i32 0, i64 3
  %5 = load i8* %arrayidx12, align 1
  %conv13 = sext i8 %5 to i32
  %cmp14 = icmp sle i32 %conv11, %conv13
  %conv15 = zext i1 %cmp14 to i64
  call void @klee_assume(i64 %conv15)
  %arrayidx16 = getelementptr inbounds [5 x i8]* %str, i32 0, i64 3
  %6 = load i8* %arrayidx16, align 1
  %conv17 = sext i8 %6 to i32
  %arrayidx18 = getelementptr inbounds [5 x i8]* %str, i32 0, i64 4
  %7 = load i8* %arrayidx18, align 1
  %conv19 = sext i8 %7 to i32
  %cmp20 = icmp sle i32 %conv17, %conv19
  %conv21 = zext i1 %cmp20 to i64
  call void @klee_assume(i64 %conv21)
  %arrayidx22 = getelementptr inbounds [5 x i8]* %str, i32 0, i64 4
  store i8 0, i8* %arrayidx22, align 1
  store i32 4, i32* %hi, align 4
  br label %while.cond

while.cond:                                       ; preds = %if.then, %if.else35, %if.then33, %entry
  %8 = load i32* %found, align 4
  %tobool = icmp ne i32 %8, 0
  br i1 %tobool, label %while.end, label %land.rhs

land.rhs:                                         ; preds = %while.cond
  %9 = load i32* %lo, align 4
  %10 = load i32* %hi, align 4
  %cmp23 = icmp sle i32 %9, %10
  br i1 %cmp23, label %while.body, label %while.end

while.body:                                       ; preds = %land.rhs
  %11 = load i32* %lo, align 4
  %12 = load i32* %hi, align 4
  %add = add nsw i32 %11, %12
  %int_cast_to_i64 = zext i32 2 to i64
  call void @klee_div_zero_check(i64 %int_cast_to_i64)
  %div = sdiv i32 %add, 2
  store i32 %div, i32* %mid, align 4
  %13 = load i8* %item, align 1
  %conv24 = sext i8 %13 to i32
  %14 = load i32* %mid, align 4
  %idxprom = sext i32 %14 to i64
  %arrayidx25 = getelementptr inbounds [5 x i8]* %str, i32 0, i64 %idxprom
  %15 = load i8* %arrayidx25, align 1
  %conv26 = sext i8 %15 to i32
  %cmp27 = icmp eq i32 %conv24, %conv26
  br i1 %cmp27, label %if.then, label %if.else

if.then:                                          ; preds = %while.body
  %call = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([2 x i8]* @.str5, i32 0, i32 0))
  store i32 1, i32* %found, align 4
  br label %while.cond

if.else:                                          ; preds = %while.body
  %16 = load i8* %item, align 1
  %conv28 = sext i8 %16 to i32
  %17 = load i32* %mid, align 4
  %idxprom29 = sext i32 %17 to i64
  %arrayidx30 = getelementptr inbounds [5 x i8]* %str, i32 0, i64 %idxprom29
  %18 = load i8* %arrayidx30, align 1
  %conv31 = sext i8 %18 to i32
  %cmp32 = icmp slt i32 %conv28, %conv31
  %19 = load i32* %mid, align 4
  br i1 %cmp32, label %if.then33, label %if.else35

if.then33:                                        ; preds = %if.else
  %sub = sub nsw i32 %19, 1
  store i32 %sub, i32* %hi, align 4
  %call34 = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([2 x i8]* @.str6, i32 0, i32 0))
  br label %while.cond

if.else35:                                        ; preds = %if.else
  %add36 = add nsw i32 %19, 1
  store i32 %add36, i32* %lo, align 4
  %call37 = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([2 x i8]* @.str7, i32 0, i32 0))
  br label %while.cond

while.end:                                        ; preds = %while.cond, %land.rhs
  %20 = load i32* %found, align 4
  %tobool39 = icmp ne i32 %20, 0
  br i1 %tobool39, label %if.then40, label %if.else42

if.then40:                                        ; preds = %while.end
  %call41 = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([7 x i8]* @.str8, i32 0, i32 0))
  br label %if.end44

if.else42:                                        ; preds = %while.end
  %call43 = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([11 x i8]* @.str9, i32 0, i32 0))
  br label %if.end44

if.end44:                                         ; preds = %if.else42, %if.then40
  %21 = load i32* %found, align 4
  ret i32 %21
}

declare void @klee_make_symbolic(i8*, i64, i8*)

declare void @klee_assume(i64)

declare i32 @printf(i8*, ...)

define linkonce_odr void @_ZN4dim3C2Ejjj(%struct.dim3* %this, i32 %vx, i32 %vy, i32 %vz) unnamed_addr nounwind uwtable section "__device__" align 2 {
entry:
  %this.addr = alloca %struct.dim3*, align 8
  %vx.addr = alloca i32, align 4
  %vy.addr = alloca i32, align 4
  %vz.addr = alloca i32, align 4
  store %struct.dim3* %this, %struct.dim3** %this.addr, align 8
  store i32 %vx, i32* %vx.addr, align 4
  store i32 %vy, i32* %vy.addr, align 4
  store i32 %vz, i32* %vz.addr, align 4
  %this1 = load %struct.dim3** %this.addr
  %x = getelementptr inbounds %struct.dim3* %this1, i32 0, i32 0
  %0 = load i32* %vx.addr, align 4
  store i32 %0, i32* %x, align 4
  %y = getelementptr inbounds %struct.dim3* %this1, i32 0, i32 1
  %1 = load i32* %vy.addr, align 4
  store i32 %1, i32* %y, align 4
  %z = getelementptr inbounds %struct.dim3* %this1, i32 0, i32 2
  %2 = load i32* %vz.addr, align 4
  store i32 %2, i32* %z, align 4
  ret void
}

define internal void @_GLOBAL__I_a() section ".text.startup" {
entry:
  call void @__cxx_global_var_init()
  call void @__cxx_global_var_init1()
  call void @__cxx_global_var_init2()
  call void @__cxx_global_var_init3()
  ret void
}

define void @klee_div_zero_check(i64 %z) nounwind uwtable {
entry:
  %cmp = icmp eq i64 %z, 0, !dbg !71
  br i1 %cmp, label %if.then, label %if.end, !dbg !71

if.then:                                          ; preds = %entry
  tail call void @klee_report_error(i8* getelementptr inbounds ([22 x i8]* @.str1, i64 0, i64 0), i32 14, i8* getelementptr inbounds ([15 x i8]* @.str12, i64 0, i64 0), i8* getelementptr inbounds ([8 x i8]* @.str2, i64 0, i64 0)) noreturn nounwind, !dbg 
  unreachable, !dbg !73

if.end:                                           ; preds = %entry
  ret void, !dbg !74
}

declare void @klee_report_error(i8*, i32, i8*, i8*) noreturn

declare void @llvm.dbg.value(metadata, i64, metadata) nounwind readnone

define internal void @klee.ctor_stub() {
entry:
  call void @_GLOBAL__I_a()
  ret void
}

!llvm.dbg.cu = !{!0, !13, !37, !53}

!0 = metadata !{i32 786449, i32 0, i32 1, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/klee_div_zero_check.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", metadata !"clang version 3.2 (trunk 162409)", 
!1 = metadata !{metadata !2}
!2 = metadata !{i32 0}
!3 = metadata !{metadata !4}
!4 = metadata !{metadata !5}
!5 = metadata !{i32 786478, i32 0, metadata !6, metadata !"klee_div_zero_check", metadata !"klee_div_zero_check", metadata !"", metadata !6, i32 12, metadata !7, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, void (i64)* @klee_div_zero_check, n
!6 = metadata !{i32 786473, metadata !"klee_div_zero_check.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!7 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !8, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!8 = metadata !{null, metadata !9}
!9 = metadata !{i32 786468, null, metadata !"long long int", null, i32 0, i64 64, i64 64, i64 0, i32 0, i32 5} ; [ DW_TAG_base_type ] [long long int] [line 0, size 64, align 64, offset 0, enc DW_ATE_signed]
!10 = metadata !{metadata !11}
!11 = metadata !{metadata !12}
!12 = metadata !{i32 786689, metadata !5, metadata !"z", metadata !6, i32 16777228, metadata !9, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [z] [line 12]
!13 = metadata !{i32 786449, i32 0, i32 1, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memcpy.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", metadata !"clang version 3.2 (trunk 162409)", i1 true, i1 
!14 = metadata !{metadata !15}
!15 = metadata !{metadata !16}
!16 = metadata !{i32 786478, i32 0, metadata !17, metadata !"memcpy", metadata !"memcpy", metadata !"", metadata !17, i32 12, metadata !18, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, null, null, null, metadata !25, i32 12} ; [ DW_TAG_subpro
!17 = metadata !{i32 786473, metadata !"memcpy.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!18 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !19, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!19 = metadata !{metadata !20, metadata !20, metadata !21, metadata !23}
!20 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, null} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!21 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !22} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!22 = metadata !{i32 786470, null, metadata !"", null, i32 0, i64 0, i64 0, i64 0, i32 0, null} ; [ DW_TAG_const_type ] [line 0, size 0, align 0, offset 0] [from ]
!23 = metadata !{i32 786454, null, metadata !"size_t", metadata !17, i32 35, i64 0, i64 0, i64 0, i32 0, metadata !24} ; [ DW_TAG_typedef ] [size_t] [line 35, size 0, align 0, offset 0] [from long unsigned int]
!24 = metadata !{i32 786468, null, metadata !"long unsigned int", null, i32 0, i64 64, i64 64, i64 0, i32 0, i32 7} ; [ DW_TAG_base_type ] [long unsigned int] [line 0, size 64, align 64, offset 0, enc DW_ATE_unsigned]
!25 = metadata !{metadata !26}
!26 = metadata !{metadata !27, metadata !28, metadata !29, metadata !30, metadata !34}
!27 = metadata !{i32 786689, metadata !16, metadata !"destaddr", metadata !17, i32 16777228, metadata !20, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [destaddr] [line 12]
!28 = metadata !{i32 786689, metadata !16, metadata !"srcaddr", metadata !17, i32 33554444, metadata !21, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [srcaddr] [line 12]
!29 = metadata !{i32 786689, metadata !16, metadata !"len", metadata !17, i32 50331660, metadata !23, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [len] [line 12]
!30 = metadata !{i32 786688, metadata !31, metadata !"dest", metadata !17, i32 13, metadata !32, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [dest] [line 13]
!31 = metadata !{i32 786443, metadata !16, i32 12, i32 63, metadata !17, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memcpy.c]
!32 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !33} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from char]
!33 = metadata !{i32 786468, null, metadata !"char", null, i32 0, i64 8, i64 8, i64 0, i32 0, i32 6} ; [ DW_TAG_base_type ] [char] [line 0, size 8, align 8, offset 0, enc DW_ATE_signed_char]
!34 = metadata !{i32 786688, metadata !31, metadata !"src", metadata !17, i32 14, metadata !35, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [src] [line 14]
!35 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !36} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!36 = metadata !{i32 786470, null, metadata !"", null, i32 0, i64 0, i64 0, i64 0, i32 0, metadata !33} ; [ DW_TAG_const_type ] [line 0, size 0, align 0, offset 0] [from char]
!37 = metadata !{i32 786449, i32 0, i32 1, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memmove.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", metadata !"clang version 3.2 (trunk 162409)", i1 true, i1
!38 = metadata !{metadata !39}
!39 = metadata !{metadata !40}
!40 = metadata !{i32 786478, i32 0, metadata !41, metadata !"memmove", metadata !"memmove", metadata !"", metadata !41, i32 12, metadata !42, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, null, null, null, metadata !45, i32 12} ; [ DW_TAG_subp
!41 = metadata !{i32 786473, metadata !"memmove.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!42 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !43, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!43 = metadata !{metadata !20, metadata !20, metadata !21, metadata !44}
!44 = metadata !{i32 786454, null, metadata !"size_t", metadata !41, i32 35, i64 0, i64 0, i64 0, i32 0, metadata !24} ; [ DW_TAG_typedef ] [size_t] [line 35, size 0, align 0, offset 0] [from long unsigned int]
!45 = metadata !{metadata !46}
!46 = metadata !{metadata !47, metadata !48, metadata !49, metadata !50, metadata !52}
!47 = metadata !{i32 786689, metadata !40, metadata !"dst", metadata !41, i32 16777228, metadata !20, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [dst] [line 12]
!48 = metadata !{i32 786689, metadata !40, metadata !"src", metadata !41, i32 33554444, metadata !21, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [src] [line 12]
!49 = metadata !{i32 786689, metadata !40, metadata !"count", metadata !41, i32 50331660, metadata !44, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [count] [line 12]
!50 = metadata !{i32 786688, metadata !51, metadata !"a", metadata !41, i32 14, metadata !32, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [a] [line 14]
!51 = metadata !{i32 786443, metadata !40, i32 12, i32 57, metadata !41, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memmove.c]
!52 = metadata !{i32 786688, metadata !51, metadata !"b", metadata !41, i32 15, metadata !35, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [b] [line 15]
!53 = metadata !{i32 786449, i32 0, i32 1, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memset.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", metadata !"clang version 3.2 (trunk 162409)", i1 true, i1 
!54 = metadata !{metadata !55}
!55 = metadata !{metadata !56}
!56 = metadata !{i32 786478, i32 0, metadata !57, metadata !"memset", metadata !"memset", metadata !"", metadata !57, i32 12, metadata !58, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, null, null, null, metadata !62, i32 12} ; [ DW_TAG_subpro
!57 = metadata !{i32 786473, metadata !"memset.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!58 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !59, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!59 = metadata !{metadata !20, metadata !20, metadata !60, metadata !61}
!60 = metadata !{i32 786468, null, metadata !"int", null, i32 0, i64 32, i64 32, i64 0, i32 0, i32 5} ; [ DW_TAG_base_type ] [int] [line 0, size 32, align 32, offset 0, enc DW_ATE_signed]
!61 = metadata !{i32 786454, null, metadata !"size_t", metadata !57, i32 35, i64 0, i64 0, i64 0, i32 0, metadata !24} ; [ DW_TAG_typedef ] [size_t] [line 35, size 0, align 0, offset 0] [from long unsigned int]
!62 = metadata !{metadata !63}
!63 = metadata !{metadata !64, metadata !65, metadata !66, metadata !67}
!64 = metadata !{i32 786689, metadata !56, metadata !"dst", metadata !57, i32 16777228, metadata !20, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [dst] [line 12]
!65 = metadata !{i32 786689, metadata !56, metadata !"s", metadata !57, i32 33554444, metadata !60, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [s] [line 12]
!66 = metadata !{i32 786689, metadata !56, metadata !"count", metadata !57, i32 50331660, metadata !61, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [count] [line 12]
!67 = metadata !{i32 786688, metadata !68, metadata !"a", metadata !57, i32 13, metadata !69, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [a] [line 13]
!68 = metadata !{i32 786443, metadata !56, i32 12, i32 47, metadata !57, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memset.c]
!69 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !70} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!70 = metadata !{i32 786485, null, metadata !"", null, i32 0, i64 0, i64 0, i64 0, i32 0, metadata !33} ; [ DW_TAG_volatile_type ] [line 0, size 0, align 0, offset 0] [from char]
!71 = metadata !{i32 13, i32 3, metadata !72, null}
!72 = metadata !{i32 786443, metadata !5, i32 12, i32 39, metadata !6, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/klee_div_zero_check.c]
!73 = metadata !{i32 14, i32 5, metadata !72, null}
!74 = metadata !{i32 15, i32 1, metadata !72, null}
