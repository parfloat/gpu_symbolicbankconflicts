; ModuleID = 'simpleSummation'
target datalayout = "e-p:64:64:64-i1:8:8-i8:8:8-i16:16:16-i32:32:32-i64:64:64-f32:32:32-f64:64:64-v64:64:64-v128:128:128-a0:0:64-s0:64:64-f80:128:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%struct.uint3 = type { i32, i32, i32 }
%struct.CUstream_st = type opaque

@_ZL6shared = internal global [4 x i32] zeroinitializer, section "__shared__", align 16
@gridDim = global %struct.uint3 zeroinitializer, align 4
@blockIdx = global %struct.uint3 zeroinitializer, align 4
@blockDim = global %struct.uint3 zeroinitializer, align 4
@threadIdx = global %struct.uint3 zeroinitializer, align 4
@.str = private unnamed_addr constant [6 x i8] c"input\00", align 1
@.str4 = private unnamed_addr constant [62 x i8] c"The summation routine is behaving incorrectly at location %d\0A\00", align 1
@llvm.global_ctors = appending global [1 x { i32, void ()* }] [{ i32, void ()* } { i32 65535, void ()* @_GLOBAL__I_a }]

define void @_Z15simpleSummationPi(i32* %values) nounwind uwtable {
entry:
  %values.addr = alloca i32*, align 8
  %__cuda_local_var_16178_16_non_const_tid = alloca i32, align 4
  store i32* %values, i32** %values.addr, align 8
  %0 = load i32* getelementptr inbounds (%struct.uint3* @threadIdx, i32 0, i32 0), align 4, !dbg !240
  store i32 %0, i32* %__cuda_local_var_16178_16_non_const_tid, align 4, !dbg !240
  %1 = load i32* %__cuda_local_var_16178_16_non_const_tid, align 4, !dbg !243
  %idxprom = zext i32 %1 to i64, !dbg !243
  %2 = load i32** %values.addr, align 8, !dbg !243
  %arrayidx = getelementptr inbounds i32* %2, i64 %idxprom, !dbg !243
  %3 = load i32* %arrayidx, align 4, !dbg !243
  %4 = load i32* %__cuda_local_var_16178_16_non_const_tid, align 4, !dbg !243
  %idxprom1 = zext i32 %4 to i64, !dbg !243
  %arrayidx2 = getelementptr inbounds [4 x i32]* @_ZL6shared, i32 0, i64 %idxprom1, !dbg !243
  store i32 %3, i32* %arrayidx2, align 4, !dbg !243
  %5 = load i32* %__cuda_local_var_16178_16_non_const_tid, align 4, !dbg !244
  %6 = load i32* %__cuda_local_var_16178_16_non_const_tid, align 4, !dbg !244
  %idxprom3 = zext i32 %6 to i64, !dbg !244
  %arrayidx4 = getelementptr inbounds [4 x i32]* @_ZL6shared, i32 0, i64 %idxprom3, !dbg !244
  %7 = load i32* %arrayidx4, align 4, !dbg !244
  %add = add i32 %7, %5, !dbg !244
  store i32 %add, i32* %arrayidx4, align 4, !dbg !244
  %8 = load i32* %__cuda_local_var_16178_16_non_const_tid, align 4, !dbg !245
  %idxprom5 = zext i32 %8 to i64, !dbg !245
  %arrayidx6 = getelementptr inbounds [4 x i32]* @_ZL6shared, i32 0, i64 %idxprom5, !dbg !245
  %9 = load i32* %arrayidx6, align 4, !dbg !245
  %10 = load i32* %__cuda_local_var_16178_16_non_const_tid, align 4, !dbg !245
  %idxprom7 = zext i32 %10 to i64, !dbg !245
  %11 = load i32** %values.addr, align 8, !dbg !245
  %arrayidx8 = getelementptr inbounds i32* %11, i64 %idxprom7, !dbg !245
  store i32 %9, i32* %arrayidx8, align 4, !dbg !245
  ret void, !dbg !246
}

declare void @llvm.dbg.declare(metadata, metadata) nounwind readnone

define internal void @__cxx_global_var_init() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.uint3* @gridDim, i32 1, i32 1, i32 1), !dbg !247
  ret void, !dbg !247
}

define linkonce_odr void @_ZN4dim3C1Ejjj(%struct.uint3* %this, i32 %vx, i32 %vy, i32 %vz) unnamed_addr uwtable section "__device__" align 2 {
entry:
  %this.addr = alloca %struct.uint3*, align 8
  %vx.addr = alloca i32, align 4
  %vy.addr = alloca i32, align 4
  %vz.addr = alloca i32, align 4
  store %struct.uint3* %this, %struct.uint3** %this.addr, align 8
  store i32 %vx, i32* %vx.addr, align 4
  store i32 %vy, i32* %vy.addr, align 4
  store i32 %vz, i32* %vz.addr, align 4
  %this1 = load %struct.uint3** %this.addr
  %0 = load i32* %vx.addr, align 4, !dbg !248
  %1 = load i32* %vy.addr, align 4, !dbg !248
  %2 = load i32* %vz.addr, align 4, !dbg !248
  call void @_ZN4dim3C2Ejjj(%struct.uint3* %this1, i32 %0, i32 %1, i32 %2), !dbg !248
  ret void, !dbg !248
}

define internal void @__cxx_global_var_init1() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.uint3* @blockIdx, i32 1, i32 1, i32 1), !dbg !249
  ret void, !dbg !249
}

define internal void @__cxx_global_var_init2() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.uint3* @blockDim, i32 1, i32 1, i32 1), !dbg !250
  ret void, !dbg !250
}

define internal void @__cxx_global_var_init3() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.uint3* @threadIdx, i32 1, i32 1, i32 1), !dbg !251
  ret void, !dbg !251
}

declare i32 @cudaSetupArgument(i8*, i64, i64)

declare i32 @cudaLaunch(i8*)

define i32 @main() uwtable {
entry:
  call void @klee.ctor_stub()
  %retval = alloca i32, align 4
  %values = alloca [4 x i32], align 16
  %dvalues = alloca i32*, align 8
  %agg.tmp = alloca %struct.uint3, align 4
  %agg.tmp12 = alloca %struct.uint3, align 4
  %i = alloca i32, align 4
  store i32 0, i32* %retval
  %arraydecay = getelementptr inbounds [4 x i32]* %values, i32 0, i32 0, !dbg !252
  %0 = bitcast i32* %arraydecay to i8*, !dbg !252
  call void @klee_make_symbolic(i8* %0, i64 16, i8* getelementptr inbounds ([6 x i8]* @.str, i32 0, i32 0)), !dbg !252
  %arrayidx = getelementptr inbounds [4 x i32]* %values, i32 0, i64 0, !dbg !254
  %1 = load i32* %arrayidx, align 4, !dbg !254
  %arrayidx1 = getelementptr inbounds [4 x i32]* %values, i32 0, i64 1, !dbg !254
  %2 = load i32* %arrayidx1, align 4, !dbg !254
  %cmp = icmp eq i32 %1, %2, !dbg !254
  %conv = zext i1 %cmp to i64, !dbg !254
  call void @klee_assume(i64 %conv), !dbg !254
  %arrayidx2 = getelementptr inbounds [4 x i32]* %values, i32 0, i64 1, !dbg !255
  %3 = load i32* %arrayidx2, align 4, !dbg !255
  %arrayidx3 = getelementptr inbounds [4 x i32]* %values, i32 0, i64 2, !dbg !255
  %4 = load i32* %arrayidx3, align 4, !dbg !255
  %cmp4 = icmp eq i32 %3, %4, !dbg !255
  %conv5 = zext i1 %cmp4 to i64, !dbg !255
  call void @klee_assume(i64 %conv5), !dbg !255
  %arrayidx6 = getelementptr inbounds [4 x i32]* %values, i32 0, i64 2, !dbg !256
  %5 = load i32* %arrayidx6, align 4, !dbg !256
  %arrayidx7 = getelementptr inbounds [4 x i32]* %values, i32 0, i64 3, !dbg !256
  %6 = load i32* %arrayidx7, align 4, !dbg !256
  %cmp8 = icmp eq i32 %5, %6, !dbg !256
  %conv9 = zext i1 %cmp8 to i64, !dbg !256
  call void @klee_assume(i64 %conv9), !dbg !256
  %7 = bitcast i32** %dvalues to i8**, !dbg !257
  %call = call i32 @cudaMalloc(i8** %7, i64 16), !dbg !257
  %8 = load i32** %dvalues, align 8, !dbg !258
  %9 = bitcast i32* %8 to i8*, !dbg !258
  %arraydecay10 = getelementptr inbounds [4 x i32]* %values, i32 0, i32 0, !dbg !258
  %10 = bitcast i32* %arraydecay10 to i8*, !dbg !258
  %call11 = call i32 @cudaMemcpy(i8* %9, i8* %10, i64 16, i32 1), !dbg !258
  call void @_ZN4dim3C1Ejjj(%struct.uint3* %agg.tmp, i32 1, i32 1, i32 1), !dbg !259
  call void @_ZN4dim3C1Ejjj(%struct.uint3* %agg.tmp12, i32 4, i32 1, i32 1), !dbg !259
  %11 = bitcast %struct.uint3* %agg.tmp to { i64, i32 }*, !dbg !259
  %12 = getelementptr { i64, i32 }* %11, i32 0, i32 0, !dbg !259
  %13 = load i64* %12, align 1, !dbg !259
  %14 = getelementptr { i64, i32 }* %11, i32 0, i32 1, !dbg !259
  %15 = load i32* %14, align 1, !dbg !259
  %16 = bitcast %struct.uint3* %agg.tmp12 to { i64, i32 }*, !dbg !259
  %17 = getelementptr { i64, i32 }* %16, i32 0, i32 0, !dbg !259
  %18 = load i64* %17, align 1, !dbg !259
  %19 = getelementptr { i64, i32 }* %16, i32 0, i32 1, !dbg !259
  %20 = load i32* %19, align 1, !dbg !259
  %call13 = call i32 @cudaConfigureCall(i64 %13, i32 %15, i64 %18, i32 %20, i64 0, %struct.CUstream_st* null), !dbg !259
  %tobool = icmp ne i32 %call13, 0, !dbg !259
  br i1 %tobool, label %kcall.end, label %kcall.configok, !dbg !259

kcall.configok:                                   ; preds = %entry
  %21 = load i32** %dvalues, align 8, !dbg !259
  call void @_Z15simpleSummationPi(i32* %21), !dbg !259
  br label %kcall.end, !dbg !259

kcall.end:                                        ; preds = %kcall.configok, %entry
  %arraydecay14 = getelementptr inbounds [4 x i32]* %values, i32 0, i32 0, !dbg !260
  %22 = bitcast i32* %arraydecay14 to i8*, !dbg !260
  %23 = load i32** %dvalues, align 8, !dbg !260
  %24 = bitcast i32* %23 to i8*, !dbg !260
  %call15 = call i32 @cudaMemcpy(i8* %22, i8* %24, i64 16, i32 1), !dbg !260
  store i32 1, i32* %i, align 4, !dbg !261
  br label %for.cond, !dbg !261

for.cond:                                         ; preds = %for.inc, %kcall.end
  %25 = load i32* %i, align 4, !dbg !261
  %cmp16 = icmp slt i32 %25, 4, !dbg !261
  br i1 %cmp16, label %for.body, label %for.end, !dbg !261

for.body:                                         ; preds = %for.cond
  %26 = load i32* %i, align 4, !dbg !263
  %idxprom = sext i32 %26 to i64, !dbg !263
  %arrayidx17 = getelementptr inbounds [4 x i32]* %values, i32 0, i64 %idxprom, !dbg !263
  %27 = load i32* %arrayidx17, align 4, !dbg !263
  %28 = load i32* %i, align 4, !dbg !263
  %sub = sub nsw i32 %28, 1, !dbg !263
  %idxprom18 = sext i32 %sub to i64, !dbg !263
  %arrayidx19 = getelementptr inbounds [4 x i32]* %values, i32 0, i64 %idxprom18, !dbg !263
  %29 = load i32* %arrayidx19, align 4, !dbg !263
  %add = add nsw i32 %29, 1, !dbg !263
  %cmp20 = icmp ne i32 %27, %add, !dbg !263
  br i1 %cmp20, label %if.then, label %for.inc, !dbg !263

if.then:                                          ; preds = %for.body
  %30 = load i32* %i, align 4, !dbg !265
  %call21 = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([62 x i8]* @.str4, i32 0, i32 0), i32 %30), !dbg !265
  br label %for.inc, !dbg !267

for.inc:                                          ; preds = %for.body, %if.then
  %31 = load i32* %i, align 4, !dbg !268
  %inc = add nsw i32 %31, 1, !dbg !268
  store i32 %inc, i32* %i, align 4, !dbg !268
  br label %for.cond, !dbg !268

for.end:                                          ; preds = %for.cond
  ret i32 0, !dbg !269
}

declare void @klee_make_symbolic(i8*, i64, i8*)

declare void @klee_assume(i64)

declare i32 @cudaConfigureCall(i64, i32, i64, i32, i64, %struct.CUstream_st*)

declare i32 @printf(i8*, ...)

define linkonce_odr void @_ZN4dim3C2Ejjj(%struct.uint3* %this, i32 %vx, i32 %vy, i32 %vz) unnamed_addr nounwind uwtable section "__device__" align 2 {
entry:
  %this.addr = alloca %struct.uint3*, align 8
  %vx.addr = alloca i32, align 4
  %vy.addr = alloca i32, align 4
  %vz.addr = alloca i32, align 4
  store %struct.uint3* %this, %struct.uint3** %this.addr, align 8
  store i32 %vx, i32* %vx.addr, align 4
  store i32 %vy, i32* %vy.addr, align 4
  store i32 %vz, i32* %vz.addr, align 4
  %this1 = load %struct.uint3** %this.addr
  %x = getelementptr inbounds %struct.uint3* %this1, i32 0, i32 0, !dbg !270
  %0 = load i32* %vx.addr, align 4, !dbg !270
  store i32 %0, i32* %x, align 4, !dbg !270
  %y = getelementptr inbounds %struct.uint3* %this1, i32 0, i32 1, !dbg !270
  %1 = load i32* %vy.addr, align 4, !dbg !270
  store i32 %1, i32* %y, align 4, !dbg !270
  %z = getelementptr inbounds %struct.uint3* %this1, i32 0, i32 2, !dbg !270
  %2 = load i32* %vz.addr, align 4, !dbg !270
  store i32 %2, i32* %z, align 4, !dbg !270
  ret void, !dbg !271
}

define internal void @_GLOBAL__I_a() section ".text.startup" {
entry:
  call void @__cxx_global_var_init()
  call void @__cxx_global_var_init1()
  call void @__cxx_global_var_init2()
  call void @__cxx_global_var_init3()
  ret void
}

define i32 @cudaMalloc(i8** nocapture %devPtr, i64 %size) nounwind uwtable {
entry:
  %call = tail call i32 (...)* @__set_device() nounwind, !dbg !273
  %call1 = tail call noalias i8* @malloc(i64 %size) nounwind, !dbg !275
  store i8* %call1, i8** %devPtr, align 8, !dbg !275, !tbaa !276
  %call2 = tail call i32 (...)* @__clear_device() nounwind, !dbg !279
  ret i32 0, !dbg !280
}

declare i32 @__set_device(...)

declare noalias i8* @malloc(i64) nounwind

declare i32 @__clear_device(...)

define i32 @cudaMemcpy(i8* %dst, i8* %src, i64 %count, i32 %kind) nounwind uwtable {
entry:
  %call = tail call i32 (...)* bitcast (i8* (i8*, i8*, i64)* @memcpy to i32 (...)*)(i8* %dst, i8* %src, i64 %count) nounwind, !dbg !281
  ret i32 0, !dbg !283
}

define i32 @cudaMemset(i8* %devPtr, i32 %value, i64 %count) nounwind uwtable {
entry:
  %call = tail call i32 (...)* bitcast (i8* (i8*, i32, i64)* @memset to i32 (...)*)(i8* %devPtr, i32 %value, i64 %count) nounwind, !dbg !284
  ret i32 0, !dbg !286
}

define i32 @cudaFree(i8* nocapture %devPtr) nounwind uwtable {
entry:
  tail call void @free(i8* %devPtr) nounwind, !dbg !287
  ret i32 0, !dbg !289
}

declare void @free(i8* nocapture) nounwind

declare void @llvm.dbg.value(metadata, i64, metadata) nounwind readnone

define i8* @memcpy(i8* %destaddr, i8* nocapture %srcaddr, i64 %len) nounwind uwtable {
entry:
  %cmp2 = icmp eq i64 %len, 0, !dbg !290
  br i1 %cmp2, label %while.end, label %while.body, !dbg !290

while.body:                                       ; preds = %while.body, %entry
  %src.05 = phi i8* [ %incdec.ptr, %while.body ], [ %srcaddr, %entry ]
  %dest.04 = phi i8* [ %incdec.ptr1, %while.body ], [ %destaddr, %entry ]
  %len.addr.03 = phi i64 [ %dec, %while.body ], [ %len, %entry ]
  %dec = add i64 %len.addr.03, -1, !dbg !290
  %incdec.ptr = getelementptr inbounds i8* %src.05, i64 1, !dbg !291
  %0 = load i8* %src.05, align 1, !dbg !291, !tbaa !277
  %incdec.ptr1 = getelementptr inbounds i8* %dest.04, i64 1, !dbg !291
  store i8 %0, i8* %dest.04, align 1, !dbg !291, !tbaa !277
  %cmp = icmp eq i64 %dec, 0, !dbg !290
  br i1 %cmp, label %while.end, label %while.body, !dbg !290

while.end:                                        ; preds = %while.body, %entry
  ret i8* %destaddr, !dbg !292
}

define i8* @memset(i8* %dst, i32 %s, i64 %count) nounwind uwtable {
entry:
  %cmp1 = icmp eq i64 %count, 0, !dbg !293
  br i1 %cmp1, label %while.end, label %while.body.lr.ph, !dbg !293

while.body.lr.ph:                                 ; preds = %entry
  %conv = trunc i32 %s to i8, !dbg !294
  br label %while.body, !dbg !293

while.body:                                       ; preds = %while.body, %while.body.lr.ph
  %a.03 = phi i8* [ %dst, %while.body.lr.ph ], [ %incdec.ptr, %while.body ]
  %count.addr.02 = phi i64 [ %count, %while.body.lr.ph ], [ %dec, %while.body ]
  %dec = add i64 %count.addr.02, -1, !dbg !293
  %incdec.ptr = getelementptr inbounds i8* %a.03, i64 1, !dbg !294
  store volatile i8 %conv, i8* %a.03, align 1, !dbg !294, !tbaa !277
  %cmp = icmp eq i64 %dec, 0, !dbg !293
  br i1 %cmp, label %while.end, label %while.body, !dbg !293

while.end:                                        ; preds = %while.body, %entry
  ret i8* %dst, !dbg !295
}

define internal void @klee.ctor_stub() {
entry:
  call void @_GLOBAL__I_a()
  ret void
}

!llvm.dbg.cu = !{!0, !17, !76, !187, !207, !223}

!0 = metadata !{i32 786449, i32 0, i32 4, metadata !"simpleSummation_device.cpp", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/simpleSummation", metadata !"clang version 3.2 (trunk 164283)", i1 true, i1 false, 
!1 = metadata !{metadata !2}
!2 = metadata !{i32 0}
!3 = metadata !{metadata !4}
!4 = metadata !{metadata !5}
!5 = metadata !{i32 786478, i32 0, metadata !6, metadata !"_Z15simpleSummationPi", metadata !"_Z15simpleSummationPi", metadata !"_Z21_Z15simpleSummationPiPi", metadata !6, i32 1212, metadata !7, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, v
!6 = metadata !{i32 786473, metadata !"simpleSummation_device.cpp", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/simpleSummation", null} ; [ DW_TAG_file_type ]
!7 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !8, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!8 = metadata !{null, metadata !9}
!9 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !10} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from int]
!10 = metadata !{i32 786468, null, metadata !"int", null, i32 0, i64 32, i64 32, i64 0, i32 0, i32 5} ; [ DW_TAG_base_type ] [int] [line 0, size 32, align 32, offset 0, enc DW_ATE_signed]
!11 = metadata !{metadata !12}
!12 = metadata !{metadata !13}
!13 = metadata !{i32 786484, i32 0, null, metadata !"shared", metadata !"shared", metadata !"_ZL6shared", metadata !6, i32 1211, metadata !14, i32 1, i32 1, [4 x i32]* @_ZL6shared} ; [ DW_TAG_variable ] [shared] [line 1211] [local] [def]
!14 = metadata !{i32 786433, null, metadata !"", null, i32 0, i64 128, i64 32, i32 0, i32 0, metadata !10, metadata !15, i32 0, i32 0} ; [ DW_TAG_array_type ] [line 0, size 128, align 32, offset 0] [from int]
!15 = metadata !{metadata !16}
!16 = metadata !{i32 786465, i64 0, i64 3}        ; [ DW_TAG_subrange_type ] [0, 3]
!17 = metadata !{i32 786449, i32 0, i32 4, metadata !"simpleSummation.cu", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/simpleSummation", metadata !"clang version 3.2 (trunk 164283)", i1 true, i1 false, metadat
!18 = metadata !{metadata !19}
!19 = metadata !{metadata !20}
!20 = metadata !{i32 786436, null, metadata !"cudaMemcpyKind", metadata !21, i32 620, i64 32, i64 32, i32 0, i32 0, null, metadata !22, i32 0, i32 0} ; [ DW_TAG_enumeration_type ] [cudaMemcpyKind] [line 620, size 32, align 32, offset 0] [from ]
!21 = metadata !{i32 786473, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/include/cuda/driver_types.h", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/simpleSummation", null} ; [ DW_TAG_file_type ]
!22 = metadata !{metadata !23, metadata !24, metadata !25, metadata !26, metadata !27}
!23 = metadata !{i32 786472, metadata !"cudaMemcpyHostToHost", i64 0} ; [ DW_TAG_enumerator ] [cudaMemcpyHostToHost :: 0]
!24 = metadata !{i32 786472, metadata !"cudaMemcpyHostToDevice", i64 1} ; [ DW_TAG_enumerator ] [cudaMemcpyHostToDevice :: 1]
!25 = metadata !{i32 786472, metadata !"cudaMemcpyDeviceToHost", i64 2} ; [ DW_TAG_enumerator ] [cudaMemcpyDeviceToHost :: 2]
!26 = metadata !{i32 786472, metadata !"cudaMemcpyDeviceToDevice", i64 3} ; [ DW_TAG_enumerator ] [cudaMemcpyDeviceToDevice :: 3]
!27 = metadata !{i32 786472, metadata !"cudaMemcpyDefault", i64 4} ; [ DW_TAG_enumerator ] [cudaMemcpyDefault :: 4]
!28 = metadata !{metadata !29}
!29 = metadata !{metadata !30, metadata !34, metadata !35, metadata !36, metadata !37, metadata !39, metadata !42, metadata !68}
!30 = metadata !{i32 786478, i32 0, metadata !31, metadata !"__cxx_global_var_init", metadata !"__cxx_global_var_init", metadata !"", metadata !31, i32 26, metadata !32, i1 true, i1 true, i32 0, i32 0, null, i32 256, i1 false, void ()* @__cxx_global_var_
!31 = metadata !{i32 786473, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/include/klee/gklee.h", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/simpleSummation", null} ; [ DW_TAG_file_type ]
!32 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !33, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!33 = metadata !{null}
!34 = metadata !{i32 786478, i32 0, metadata !31, metadata !"__cxx_global_var_init1", metadata !"__cxx_global_var_init1", metadata !"", metadata !31, i32 27, metadata !32, i1 true, i1 true, i32 0, i32 0, null, i32 256, i1 false, void ()* @__cxx_global_va
!35 = metadata !{i32 786478, i32 0, metadata !31, metadata !"__cxx_global_var_init2", metadata !"__cxx_global_var_init2", metadata !"", metadata !31, i32 28, metadata !32, i1 true, i1 true, i32 0, i32 0, null, i32 256, i1 false, void ()* @__cxx_global_va
!36 = metadata !{i32 786478, i32 0, metadata !31, metadata !"__cxx_global_var_init3", metadata !"__cxx_global_var_init3", metadata !"", metadata !31, i32 29, metadata !32, i1 true, i1 true, i32 0, i32 0, null, i32 256, i1 false, void ()* @__cxx_global_va
!37 = metadata !{i32 786478, i32 0, metadata !38, metadata !"simpleSummation", metadata !"simpleSummation", metadata !"_Z15simpleSummationPi", metadata !38, i32 7, metadata !7, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (i32*)* @_Z15s
!38 = metadata !{i32 786473, metadata !"simpleSummation.cu", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/simpleSummation", null} ; [ DW_TAG_file_type ]
!39 = metadata !{i32 786478, i32 0, metadata !38, metadata !"main", metadata !"main", metadata !"", metadata !38, i32 28, metadata !40, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, i32 ()* @main, null, null, metadata !1, i32 28} ; [ DW_TAG_s
!40 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !41, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!41 = metadata !{metadata !10}
!42 = metadata !{i32 786478, i32 0, null, metadata !"dim3", metadata !"dim3", metadata !"_ZN4dim3C1Ejjj", metadata !43, i32 397, metadata !44, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (%struct.uint3*, i32, i32, i32)* @_ZN4dim3C1Ejjj
!43 = metadata !{i32 786473, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/include/cuda/vector_types.h", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/simpleSummation", null} ; [ DW_TAG_file_type ]
!44 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !45, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!45 = metadata !{null, metadata !46, metadata !50, metadata !50, metadata !50}
!46 = metadata !{i32 786447, i32 0, metadata !"", i32 0, i32 0, i64 64, i64 64, i64 0, i32 1088, metadata !47} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from dim3]
!47 = metadata !{i32 786434, null, metadata !"dim3", metadata !43, i32 393, i64 96, i64 32, i32 0, i32 0, null, metadata !48, i32 0, null, null} ; [ DW_TAG_class_type ] [dim3] [line 393, size 96, align 32, offset 0] [from ]
!48 = metadata !{metadata !49, metadata !51, metadata !52, metadata !53, metadata !56, metadata !65}
!49 = metadata !{i32 786445, metadata !47, metadata !"x", metadata !43, i32 395, i64 32, i64 32, i64 0, i32 0, metadata !50} ; [ DW_TAG_member ] [x] [line 395, size 32, align 32, offset 0] [from unsigned int]
!50 = metadata !{i32 786468, null, metadata !"unsigned int", null, i32 0, i64 32, i64 32, i64 0, i32 0, i32 7} ; [ DW_TAG_base_type ] [unsigned int] [line 0, size 32, align 32, offset 0, enc DW_ATE_unsigned]
!51 = metadata !{i32 786445, metadata !47, metadata !"y", metadata !43, i32 395, i64 32, i64 32, i64 32, i32 0, metadata !50} ; [ DW_TAG_member ] [y] [line 395, size 32, align 32, offset 32] [from unsigned int]
!52 = metadata !{i32 786445, metadata !47, metadata !"z", metadata !43, i32 395, i64 32, i64 32, i64 64, i32 0, metadata !50} ; [ DW_TAG_member ] [z] [line 395, size 32, align 32, offset 64] [from unsigned int]
!53 = metadata !{i32 786478, i32 0, metadata !47, metadata !"dim3", metadata !"dim3", metadata !"", metadata !43, i32 397, metadata !44, i1 false, i1 false, i32 0, i32 0, null, i32 256, i1 false, null, null, i32 0, metadata !54, i32 397} ; [ DW_TAG_subpr
!54 = metadata !{metadata !55}
!55 = metadata !{i32 786468}                      ; [ DW_TAG_base_type ] [line 0, size 0, align 0, offset 0]
!56 = metadata !{i32 786478, i32 0, metadata !47, metadata !"dim3", metadata !"dim3", metadata !"", metadata !43, i32 398, metadata !57, i1 false, i1 false, i32 0, i32 0, null, i32 256, i1 false, null, null, i32 0, metadata !54, i32 398} ; [ DW_TAG_subpr
!57 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !58, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!58 = metadata !{null, metadata !46, metadata !59}
!59 = metadata !{i32 786454, null, metadata !"uint3", metadata !43, i32 359, i64 0, i64 0, i64 0, i32 0, metadata !60} ; [ DW_TAG_typedef ] [uint3] [line 359, size 0, align 0, offset 0] [from uint3]
!60 = metadata !{i32 786434, null, metadata !"uint3", metadata !43, i32 186, i64 96, i64 32, i32 0, i32 0, null, metadata !61, i32 0, null, null} ; [ DW_TAG_class_type ] [uint3] [line 186, size 96, align 32, offset 0] [from ]
!61 = metadata !{metadata !62, metadata !63, metadata !64}
!62 = metadata !{i32 786445, metadata !60, metadata !"x", metadata !43, i32 188, i64 32, i64 32, i64 0, i32 0, metadata !50} ; [ DW_TAG_member ] [x] [line 188, size 32, align 32, offset 0] [from unsigned int]
!63 = metadata !{i32 786445, metadata !60, metadata !"y", metadata !43, i32 188, i64 32, i64 32, i64 32, i32 0, metadata !50} ; [ DW_TAG_member ] [y] [line 188, size 32, align 32, offset 32] [from unsigned int]
!64 = metadata !{i32 786445, metadata !60, metadata !"z", metadata !43, i32 188, i64 32, i64 32, i64 64, i32 0, metadata !50} ; [ DW_TAG_member ] [z] [line 188, size 32, align 32, offset 64] [from unsigned int]
!65 = metadata !{i32 786478, i32 0, metadata !47, metadata !"operator uint3", metadata !"operator uint3", metadata !"_ZN4dim3cv5uint3Ev", metadata !43, i32 399, metadata !66, i1 false, i1 false, i32 0, i32 0, null, i32 256, i1 false, null, null, i32 0, m
!66 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !67, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!67 = metadata !{metadata !59, metadata !46}
!68 = metadata !{i32 786478, i32 0, null, metadata !"dim3", metadata !"dim3", metadata !"_ZN4dim3C2Ejjj", metadata !43, i32 397, metadata !44, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (%struct.uint3*, i32, i32, i32)* @_ZN4dim3C2Ejjj
!69 = metadata !{metadata !70}
!70 = metadata !{metadata !71, metadata !73, metadata !74, metadata !75}
!71 = metadata !{i32 786484, i32 0, null, metadata !"gridDim", metadata !"gridDim", metadata !"", metadata !31, i32 26, metadata !72, i32 0, i32 1, %struct.uint3* @gridDim} ; [ DW_TAG_variable ] [gridDim] [line 26] [def]
!72 = metadata !{i32 786454, null, metadata !"dim3", metadata !31, i32 403, i64 0, i64 0, i64 0, i32 0, metadata !47} ; [ DW_TAG_typedef ] [dim3] [line 403, size 0, align 0, offset 0] [from dim3]
!73 = metadata !{i32 786484, i32 0, null, metadata !"blockIdx", metadata !"blockIdx", metadata !"", metadata !31, i32 27, metadata !72, i32 0, i32 1, %struct.uint3* @blockIdx} ; [ DW_TAG_variable ] [blockIdx] [line 27] [def]
!74 = metadata !{i32 786484, i32 0, null, metadata !"blockDim", metadata !"blockDim", metadata !"", metadata !31, i32 28, metadata !72, i32 0, i32 1, %struct.uint3* @blockDim} ; [ DW_TAG_variable ] [blockDim] [line 28] [def]
!75 = metadata !{i32 786484, i32 0, null, metadata !"threadIdx", metadata !"threadIdx", metadata !"", metadata !31, i32 29, metadata !72, i32 0, i32 1, %struct.uint3* @threadIdx} ; [ DW_TAG_variable ] [threadIdx] [line 29] [def]
!76 = metadata !{i32 786449, i32 0, i32 1, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/cudaMemManage.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", metadata !"clang version 3.2 (trunk 164283)", i1 tr
!77 = metadata !{metadata !78}
!78 = metadata !{metadata !79, metadata !146}
!79 = metadata !{i32 786436, null, metadata !"cudaError", metadata !80, i32 126, i64 32, i64 32, i32 0, i32 0, null, metadata !81, i32 0, i32 0} ; [ DW_TAG_enumeration_type ] [cudaError] [line 126, size 32, align 32, offset 0] [from ]
!80 = metadata !{i32 786473, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/include/cuda/driver_types.h", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!81 = metadata !{metadata !82, metadata !83, metadata !84, metadata !85, metadata !86, metadata !87, metadata !88, metadata !89, metadata !90, metadata !91, metadata !92, metadata !93, metadata !94, metadata !95, metadata !96, metadata !97, metadata !98,
!82 = metadata !{i32 786472, metadata !"cudaSuccess", i64 0} ; [ DW_TAG_enumerator ] [cudaSuccess :: 0]
!83 = metadata !{i32 786472, metadata !"cudaErrorMissingConfiguration", i64 1} ; [ DW_TAG_enumerator ] [cudaErrorMissingConfiguration :: 1]
!84 = metadata !{i32 786472, metadata !"cudaErrorMemoryAllocation", i64 2} ; [ DW_TAG_enumerator ] [cudaErrorMemoryAllocation :: 2]
!85 = metadata !{i32 786472, metadata !"cudaErrorInitializationError", i64 3} ; [ DW_TAG_enumerator ] [cudaErrorInitializationError :: 3]
!86 = metadata !{i32 786472, metadata !"cudaErrorLaunchFailure", i64 4} ; [ DW_TAG_enumerator ] [cudaErrorLaunchFailure :: 4]
!87 = metadata !{i32 786472, metadata !"cudaErrorPriorLaunchFailure", i64 5} ; [ DW_TAG_enumerator ] [cudaErrorPriorLaunchFailure :: 5]
!88 = metadata !{i32 786472, metadata !"cudaErrorLaunchTimeout", i64 6} ; [ DW_TAG_enumerator ] [cudaErrorLaunchTimeout :: 6]
!89 = metadata !{i32 786472, metadata !"cudaErrorLaunchOutOfResources", i64 7} ; [ DW_TAG_enumerator ] [cudaErrorLaunchOutOfResources :: 7]
!90 = metadata !{i32 786472, metadata !"cudaErrorInvalidDeviceFunction", i64 8} ; [ DW_TAG_enumerator ] [cudaErrorInvalidDeviceFunction :: 8]
!91 = metadata !{i32 786472, metadata !"cudaErrorInvalidConfiguration", i64 9} ; [ DW_TAG_enumerator ] [cudaErrorInvalidConfiguration :: 9]
!92 = metadata !{i32 786472, metadata !"cudaErrorInvalidDevice", i64 10} ; [ DW_TAG_enumerator ] [cudaErrorInvalidDevice :: 10]
!93 = metadata !{i32 786472, metadata !"cudaErrorInvalidValue", i64 11} ; [ DW_TAG_enumerator ] [cudaErrorInvalidValue :: 11]
!94 = metadata !{i32 786472, metadata !"cudaErrorInvalidPitchValue", i64 12} ; [ DW_TAG_enumerator ] [cudaErrorInvalidPitchValue :: 12]
!95 = metadata !{i32 786472, metadata !"cudaErrorInvalidSymbol", i64 13} ; [ DW_TAG_enumerator ] [cudaErrorInvalidSymbol :: 13]
!96 = metadata !{i32 786472, metadata !"cudaErrorMapBufferObjectFailed", i64 14} ; [ DW_TAG_enumerator ] [cudaErrorMapBufferObjectFailed :: 14]
!97 = metadata !{i32 786472, metadata !"cudaErrorUnmapBufferObjectFailed", i64 15} ; [ DW_TAG_enumerator ] [cudaErrorUnmapBufferObjectFailed :: 15]
!98 = metadata !{i32 786472, metadata !"cudaErrorInvalidHostPointer", i64 16} ; [ DW_TAG_enumerator ] [cudaErrorInvalidHostPointer :: 16]
!99 = metadata !{i32 786472, metadata !"cudaErrorInvalidDevicePointer", i64 17} ; [ DW_TAG_enumerator ] [cudaErrorInvalidDevicePointer :: 17]
!100 = metadata !{i32 786472, metadata !"cudaErrorInvalidTexture", i64 18} ; [ DW_TAG_enumerator ] [cudaErrorInvalidTexture :: 18]
!101 = metadata !{i32 786472, metadata !"cudaErrorInvalidTextureBinding", i64 19} ; [ DW_TAG_enumerator ] [cudaErrorInvalidTextureBinding :: 19]
!102 = metadata !{i32 786472, metadata !"cudaErrorInvalidChannelDescriptor", i64 20} ; [ DW_TAG_enumerator ] [cudaErrorInvalidChannelDescriptor :: 20]
!103 = metadata !{i32 786472, metadata !"cudaErrorInvalidMemcpyDirection", i64 21} ; [ DW_TAG_enumerator ] [cudaErrorInvalidMemcpyDirection :: 21]
!104 = metadata !{i32 786472, metadata !"cudaErrorAddressOfConstant", i64 22} ; [ DW_TAG_enumerator ] [cudaErrorAddressOfConstant :: 22]
!105 = metadata !{i32 786472, metadata !"cudaErrorTextureFetchFailed", i64 23} ; [ DW_TAG_enumerator ] [cudaErrorTextureFetchFailed :: 23]
!106 = metadata !{i32 786472, metadata !"cudaErrorTextureNotBound", i64 24} ; [ DW_TAG_enumerator ] [cudaErrorTextureNotBound :: 24]
!107 = metadata !{i32 786472, metadata !"cudaErrorSynchronizationError", i64 25} ; [ DW_TAG_enumerator ] [cudaErrorSynchronizationError :: 25]
!108 = metadata !{i32 786472, metadata !"cudaErrorInvalidFilterSetting", i64 26} ; [ DW_TAG_enumerator ] [cudaErrorInvalidFilterSetting :: 26]
!109 = metadata !{i32 786472, metadata !"cudaErrorInvalidNormSetting", i64 27} ; [ DW_TAG_enumerator ] [cudaErrorInvalidNormSetting :: 27]
!110 = metadata !{i32 786472, metadata !"cudaErrorMixedDeviceExecution", i64 28} ; [ DW_TAG_enumerator ] [cudaErrorMixedDeviceExecution :: 28]
!111 = metadata !{i32 786472, metadata !"cudaErrorCudartUnloading", i64 29} ; [ DW_TAG_enumerator ] [cudaErrorCudartUnloading :: 29]
!112 = metadata !{i32 786472, metadata !"cudaErrorUnknown", i64 30} ; [ DW_TAG_enumerator ] [cudaErrorUnknown :: 30]
!113 = metadata !{i32 786472, metadata !"cudaErrorNotYetImplemented", i64 31} ; [ DW_TAG_enumerator ] [cudaErrorNotYetImplemented :: 31]
!114 = metadata !{i32 786472, metadata !"cudaErrorMemoryValueTooLarge", i64 32} ; [ DW_TAG_enumerator ] [cudaErrorMemoryValueTooLarge :: 32]
!115 = metadata !{i32 786472, metadata !"cudaErrorInvalidResourceHandle", i64 33} ; [ DW_TAG_enumerator ] [cudaErrorInvalidResourceHandle :: 33]
!116 = metadata !{i32 786472, metadata !"cudaErrorNotReady", i64 34} ; [ DW_TAG_enumerator ] [cudaErrorNotReady :: 34]
!117 = metadata !{i32 786472, metadata !"cudaErrorInsufficientDriver", i64 35} ; [ DW_TAG_enumerator ] [cudaErrorInsufficientDriver :: 35]
!118 = metadata !{i32 786472, metadata !"cudaErrorSetOnActiveProcess", i64 36} ; [ DW_TAG_enumerator ] [cudaErrorSetOnActiveProcess :: 36]
!119 = metadata !{i32 786472, metadata !"cudaErrorInvalidSurface", i64 37} ; [ DW_TAG_enumerator ] [cudaErrorInvalidSurface :: 37]
!120 = metadata !{i32 786472, metadata !"cudaErrorNoDevice", i64 38} ; [ DW_TAG_enumerator ] [cudaErrorNoDevice :: 38]
!121 = metadata !{i32 786472, metadata !"cudaErrorECCUncorrectable", i64 39} ; [ DW_TAG_enumerator ] [cudaErrorECCUncorrectable :: 39]
!122 = metadata !{i32 786472, metadata !"cudaErrorSharedObjectSymbolNotFound", i64 40} ; [ DW_TAG_enumerator ] [cudaErrorSharedObjectSymbolNotFound :: 40]
!123 = metadata !{i32 786472, metadata !"cudaErrorSharedObjectInitFailed", i64 41} ; [ DW_TAG_enumerator ] [cudaErrorSharedObjectInitFailed :: 41]
!124 = metadata !{i32 786472, metadata !"cudaErrorUnsupportedLimit", i64 42} ; [ DW_TAG_enumerator ] [cudaErrorUnsupportedLimit :: 42]
!125 = metadata !{i32 786472, metadata !"cudaErrorDuplicateVariableName", i64 43} ; [ DW_TAG_enumerator ] [cudaErrorDuplicateVariableName :: 43]
!126 = metadata !{i32 786472, metadata !"cudaErrorDuplicateTextureName", i64 44} ; [ DW_TAG_enumerator ] [cudaErrorDuplicateTextureName :: 44]
!127 = metadata !{i32 786472, metadata !"cudaErrorDuplicateSurfaceName", i64 45} ; [ DW_TAG_enumerator ] [cudaErrorDuplicateSurfaceName :: 45]
!128 = metadata !{i32 786472, metadata !"cudaErrorDevicesUnavailable", i64 46} ; [ DW_TAG_enumerator ] [cudaErrorDevicesUnavailable :: 46]
!129 = metadata !{i32 786472, metadata !"cudaErrorInvalidKernelImage", i64 47} ; [ DW_TAG_enumerator ] [cudaErrorInvalidKernelImage :: 47]
!130 = metadata !{i32 786472, metadata !"cudaErrorNoKernelImageForDevice", i64 48} ; [ DW_TAG_enumerator ] [cudaErrorNoKernelImageForDevice :: 48]
!131 = metadata !{i32 786472, metadata !"cudaErrorIncompatibleDriverContext", i64 49} ; [ DW_TAG_enumerator ] [cudaErrorIncompatibleDriverContext :: 49]
!132 = metadata !{i32 786472, metadata !"cudaErrorPeerAccessAlreadyEnabled", i64 50} ; [ DW_TAG_enumerator ] [cudaErrorPeerAccessAlreadyEnabled :: 50]
!133 = metadata !{i32 786472, metadata !"cudaErrorPeerAccessNotEnabled", i64 51} ; [ DW_TAG_enumerator ] [cudaErrorPeerAccessNotEnabled :: 51]
!134 = metadata !{i32 786472, metadata !"cudaErrorDeviceAlreadyInUse", i64 54} ; [ DW_TAG_enumerator ] [cudaErrorDeviceAlreadyInUse :: 54]
!135 = metadata !{i32 786472, metadata !"cudaErrorProfilerDisabled", i64 55} ; [ DW_TAG_enumerator ] [cudaErrorProfilerDisabled :: 55]
!136 = metadata !{i32 786472, metadata !"cudaErrorProfilerNotInitialized", i64 56} ; [ DW_TAG_enumerator ] [cudaErrorProfilerNotInitialized :: 56]
!137 = metadata !{i32 786472, metadata !"cudaErrorProfilerAlreadyStarted", i64 57} ; [ DW_TAG_enumerator ] [cudaErrorProfilerAlreadyStarted :: 57]
!138 = metadata !{i32 786472, metadata !"cudaErrorProfilerAlreadyStopped", i64 58} ; [ DW_TAG_enumerator ] [cudaErrorProfilerAlreadyStopped :: 58]
!139 = metadata !{i32 786472, metadata !"cudaErrorAssert", i64 59} ; [ DW_TAG_enumerator ] [cudaErrorAssert :: 59]
!140 = metadata !{i32 786472, metadata !"cudaErrorTooManyPeers", i64 60} ; [ DW_TAG_enumerator ] [cudaErrorTooManyPeers :: 60]
!141 = metadata !{i32 786472, metadata !"cudaErrorHostMemoryAlreadyRegistered", i64 61} ; [ DW_TAG_enumerator ] [cudaErrorHostMemoryAlreadyRegistered :: 61]
!142 = metadata !{i32 786472, metadata !"cudaErrorHostMemoryNotRegistered", i64 62} ; [ DW_TAG_enumerator ] [cudaErrorHostMemoryNotRegistered :: 62]
!143 = metadata !{i32 786472, metadata !"cudaErrorOperatingSystem", i64 63} ; [ DW_TAG_enumerator ] [cudaErrorOperatingSystem :: 63]
!144 = metadata !{i32 786472, metadata !"cudaErrorStartupFailure", i64 127} ; [ DW_TAG_enumerator ] [cudaErrorStartupFailure :: 127]
!145 = metadata !{i32 786472, metadata !"cudaErrorApiFailureBase", i64 10000} ; [ DW_TAG_enumerator ] [cudaErrorApiFailureBase :: 10000]
!146 = metadata !{i32 786436, null, metadata !"cudaMemcpyKind", metadata !80, i32 620, i64 32, i64 32, i32 0, i32 0, null, metadata !22, i32 0, i32 0} ; [ DW_TAG_enumeration_type ] [cudaMemcpyKind] [line 620, size 32, align 32, offset 0] [from ]
!147 = metadata !{metadata !148}
!148 = metadata !{metadata !149, metadata !162, metadata !173, metadata !181}
!149 = metadata !{i32 786478, i32 0, metadata !150, metadata !"cudaMalloc", metadata !"cudaMalloc", metadata !"", metadata !150, i32 13, metadata !151, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, i32 (i8**, i64)* @cudaMalloc, null, null, met
!150 = metadata !{i32 786473, metadata !"cudaMemManage.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!151 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !152, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!152 = metadata !{metadata !153, metadata !154, metadata !156}
!153 = metadata !{i32 786454, null, metadata !"cudaError_t", metadata !150, i32 1001, i64 0, i64 0, i64 0, i32 0, metadata !79} ; [ DW_TAG_typedef ] [cudaError_t] [line 1001, size 0, align 0, offset 0] [from cudaError]
!154 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !155} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!155 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, null} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!156 = metadata !{i32 786454, null, metadata !"size_t", metadata !150, i32 35, i64 0, i64 0, i64 0, i32 0, metadata !157} ; [ DW_TAG_typedef ] [size_t] [line 35, size 0, align 0, offset 0] [from long unsigned int]
!157 = metadata !{i32 786468, null, metadata !"long unsigned int", null, i32 0, i64 64, i64 64, i64 0, i32 0, i32 7} ; [ DW_TAG_base_type ] [long unsigned int] [line 0, size 64, align 64, offset 0, enc DW_ATE_unsigned]
!158 = metadata !{metadata !159}
!159 = metadata !{metadata !160, metadata !161}
!160 = metadata !{i32 786689, metadata !149, metadata !"devPtr", metadata !150, i32 16777229, metadata !154, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [devPtr] [line 13]
!161 = metadata !{i32 786689, metadata !149, metadata !"size", metadata !150, i32 33554445, metadata !156, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [size] [line 13]
!162 = metadata !{i32 786478, i32 0, metadata !150, metadata !"cudaMemcpy", metadata !"cudaMemcpy", metadata !"", metadata !150, i32 21, metadata !163, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, i32 (i8*, i8*, i64, i32)* @cudaMemcpy, null, 
!163 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !164, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!164 = metadata !{metadata !153, metadata !155, metadata !165, metadata !156, metadata !146}
!165 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !166} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!166 = metadata !{i32 786470, null, metadata !"", null, i32 0, i64 0, i64 0, i64 0, i32 0, null} ; [ DW_TAG_const_type ] [line 0, size 0, align 0, offset 0] [from ]
!167 = metadata !{metadata !168}
!168 = metadata !{metadata !169, metadata !170, metadata !171, metadata !172}
!169 = metadata !{i32 786689, metadata !162, metadata !"dst", metadata !150, i32 16777237, metadata !155, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [dst] [line 21]
!170 = metadata !{i32 786689, metadata !162, metadata !"src", metadata !150, i32 33554453, metadata !165, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [src] [line 21]
!171 = metadata !{i32 786689, metadata !162, metadata !"count", metadata !150, i32 50331669, metadata !156, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [count] [line 21]
!172 = metadata !{i32 786689, metadata !162, metadata !"kind", metadata !150, i32 67108885, metadata !146, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [kind] [line 21]
!173 = metadata !{i32 786478, i32 0, metadata !150, metadata !"cudaMemset", metadata !"cudaMemset", metadata !"", metadata !150, i32 26, metadata !174, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, i32 (i8*, i32, i64)* @cudaMemset, null, null,
!174 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !175, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!175 = metadata !{metadata !153, metadata !155, metadata !10, metadata !156}
!176 = metadata !{metadata !177}
!177 = metadata !{metadata !178, metadata !179, metadata !180}
!178 = metadata !{i32 786689, metadata !173, metadata !"devPtr", metadata !150, i32 16777242, metadata !155, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [devPtr] [line 26]
!179 = metadata !{i32 786689, metadata !173, metadata !"value", metadata !150, i32 33554458, metadata !10, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [value] [line 26]
!180 = metadata !{i32 786689, metadata !173, metadata !"count", metadata !150, i32 50331674, metadata !156, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [count] [line 26]
!181 = metadata !{i32 786478, i32 0, metadata !150, metadata !"cudaFree", metadata !"cudaFree", metadata !"", metadata !150, i32 31, metadata !182, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, i32 (i8*)* @cudaFree, null, null, metadata !184, 
!182 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !183, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!183 = metadata !{metadata !153, metadata !155}
!184 = metadata !{metadata !185}
!185 = metadata !{metadata !186}
!186 = metadata !{i32 786689, metadata !181, metadata !"devPtr", metadata !150, i32 16777247, metadata !155, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [devPtr] [line 31]
!187 = metadata !{i32 786449, i32 0, i32 1, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memcpy.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", metadata !"clang version 3.2 (trunk 164283)", i1 true, i1
!188 = metadata !{metadata !189}
!189 = metadata !{metadata !190}
!190 = metadata !{i32 786478, i32 0, metadata !191, metadata !"memcpy", metadata !"memcpy", metadata !"", metadata !191, i32 12, metadata !192, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, i8* (i8*, i8*, i64)* @memcpy, null, null, metadata !1
!191 = metadata !{i32 786473, metadata !"memcpy.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!192 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !193, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!193 = metadata !{metadata !155, metadata !155, metadata !165, metadata !194}
!194 = metadata !{i32 786454, null, metadata !"size_t", metadata !191, i32 35, i64 0, i64 0, i64 0, i32 0, metadata !157} ; [ DW_TAG_typedef ] [size_t] [line 35, size 0, align 0, offset 0] [from long unsigned int]
!195 = metadata !{metadata !196}
!196 = metadata !{metadata !197, metadata !198, metadata !199, metadata !200, metadata !204}
!197 = metadata !{i32 786689, metadata !190, metadata !"destaddr", metadata !191, i32 16777228, metadata !155, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [destaddr] [line 12]
!198 = metadata !{i32 786689, metadata !190, metadata !"srcaddr", metadata !191, i32 33554444, metadata !165, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [srcaddr] [line 12]
!199 = metadata !{i32 786689, metadata !190, metadata !"len", metadata !191, i32 50331660, metadata !194, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [len] [line 12]
!200 = metadata !{i32 786688, metadata !201, metadata !"dest", metadata !191, i32 13, metadata !202, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [dest] [line 13]
!201 = metadata !{i32 786443, metadata !190, i32 12, i32 63, metadata !191, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memcpy.c]
!202 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !203} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from char]
!203 = metadata !{i32 786468, null, metadata !"char", null, i32 0, i64 8, i64 8, i64 0, i32 0, i32 6} ; [ DW_TAG_base_type ] [char] [line 0, size 8, align 8, offset 0, enc DW_ATE_signed_char]
!204 = metadata !{i32 786688, metadata !201, metadata !"src", metadata !191, i32 14, metadata !205, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [src] [line 14]
!205 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !206} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!206 = metadata !{i32 786470, null, metadata !"", null, i32 0, i64 0, i64 0, i64 0, i32 0, metadata !203} ; [ DW_TAG_const_type ] [line 0, size 0, align 0, offset 0] [from char]
!207 = metadata !{i32 786449, i32 0, i32 1, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memmove.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", metadata !"clang version 3.2 (trunk 164283)", i1 true, i
!208 = metadata !{metadata !209}
!209 = metadata !{metadata !210}
!210 = metadata !{i32 786478, i32 0, metadata !211, metadata !"memmove", metadata !"memmove", metadata !"", metadata !211, i32 12, metadata !212, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, null, null, null, metadata !215, i32 12} ; [ DW_TAG
!211 = metadata !{i32 786473, metadata !"memmove.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!212 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !213, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!213 = metadata !{metadata !155, metadata !155, metadata !165, metadata !214}
!214 = metadata !{i32 786454, null, metadata !"size_t", metadata !211, i32 35, i64 0, i64 0, i64 0, i32 0, metadata !157} ; [ DW_TAG_typedef ] [size_t] [line 35, size 0, align 0, offset 0] [from long unsigned int]
!215 = metadata !{metadata !216}
!216 = metadata !{metadata !217, metadata !218, metadata !219, metadata !220, metadata !222}
!217 = metadata !{i32 786689, metadata !210, metadata !"dst", metadata !211, i32 16777228, metadata !155, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [dst] [line 12]
!218 = metadata !{i32 786689, metadata !210, metadata !"src", metadata !211, i32 33554444, metadata !165, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [src] [line 12]
!219 = metadata !{i32 786689, metadata !210, metadata !"count", metadata !211, i32 50331660, metadata !214, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [count] [line 12]
!220 = metadata !{i32 786688, metadata !221, metadata !"a", metadata !211, i32 14, metadata !202, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [a] [line 14]
!221 = metadata !{i32 786443, metadata !210, i32 12, i32 57, metadata !211, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memmove.c]
!222 = metadata !{i32 786688, metadata !221, metadata !"b", metadata !211, i32 15, metadata !205, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [b] [line 15]
!223 = metadata !{i32 786449, i32 0, i32 1, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memset.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", metadata !"clang version 3.2 (trunk 164283)", i1 true, i1
!224 = metadata !{metadata !225}
!225 = metadata !{metadata !226}
!226 = metadata !{i32 786478, i32 0, metadata !227, metadata !"memset", metadata !"memset", metadata !"", metadata !227, i32 12, metadata !228, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 true, i8* (i8*, i32, i64)* @memset, null, null, metadata !2
!227 = metadata !{i32 786473, metadata !"memset.c", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic", null} ; [ DW_TAG_file_type ]
!228 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !229, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!229 = metadata !{metadata !155, metadata !155, metadata !10, metadata !230}
!230 = metadata !{i32 786454, null, metadata !"size_t", metadata !227, i32 35, i64 0, i64 0, i64 0, i32 0, metadata !157} ; [ DW_TAG_typedef ] [size_t] [line 35, size 0, align 0, offset 0] [from long unsigned int]
!231 = metadata !{metadata !232}
!232 = metadata !{metadata !233, metadata !234, metadata !235, metadata !236}
!233 = metadata !{i32 786689, metadata !226, metadata !"dst", metadata !227, i32 16777228, metadata !155, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [dst] [line 12]
!234 = metadata !{i32 786689, metadata !226, metadata !"s", metadata !227, i32 33554444, metadata !10, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [s] [line 12]
!235 = metadata !{i32 786689, metadata !226, metadata !"count", metadata !227, i32 50331660, metadata !230, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [count] [line 12]
!236 = metadata !{i32 786688, metadata !237, metadata !"a", metadata !227, i32 13, metadata !238, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [a] [line 13]
!237 = metadata !{i32 786443, metadata !226, i32 12, i32 47, metadata !227, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/memset.c]
!238 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !239} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!239 = metadata !{i32 786485, null, metadata !"", null, i32 0, i64 0, i64 0, i64 0, i32 0, metadata !203} ; [ DW_TAG_volatile_type ] [line 0, size 0, align 0, offset 0] [from char]
!240 = metadata !{i32 1216, i32 1, metadata !241, null}
!241 = metadata !{i32 786443, metadata !242, i32 1214, i32 1, metadata !6, i32 1} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/simpleSummation/simpleSummation_device.cpp]
!242 = metadata !{i32 786443, metadata !5, i32 1213, i32 13, metadata !6, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/simpleSummation/simpleSummation_device.cpp]
!243 = metadata !{i32 1217, i32 1, metadata !241, null}
!244 = metadata !{i32 1218, i32 1, metadata !241, null}
!245 = metadata !{i32 1219, i32 1, metadata !241, null}
!246 = metadata !{i32 1220, i32 2, metadata !242, null}
!247 = metadata !{i32 26, i32 6, metadata !30, null}
!248 = metadata !{i32 397, i32 116, metadata !42, null}
!249 = metadata !{i32 27, i32 6, metadata !34, null}
!250 = metadata !{i32 28, i32 6, metadata !35, null}
!251 = metadata !{i32 29, i32 6, metadata !36, null}
!252 = metadata !{i32 30, i32 3, metadata !253, null}
!253 = metadata !{i32 786443, metadata !39, i32 28, i32 12, metadata !38, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/simpleSummation/simpleSummation.cu]
!254 = metadata !{i32 32, i32 3, metadata !253, null}
!255 = metadata !{i32 33, i32 3, metadata !253, null}
!256 = metadata !{i32 34, i32 3, metadata !253, null}
!257 = metadata !{i32 37, i32 3, metadata !253, null}
!258 = metadata !{i32 38, i32 3, metadata !253, null}
!259 = metadata !{i32 40, i32 18, metadata !253, null}
!260 = metadata !{i32 41, i32 3, metadata !253, null}
!261 = metadata !{i32 44, i32 17, metadata !262, null}
!262 = metadata !{i32 786443, metadata !253, i32 44, i32 3, metadata !38, i32 1} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/simpleSummation/simpleSummation.cu]
!263 = metadata !{i32 45, i32 5, metadata !264, null}
!264 = metadata !{i32 786443, metadata !262, i32 44, i32 33, metadata !38, i32 2} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/simpleSummation/simpleSummation.cu]
!265 = metadata !{i32 46, i32 7, metadata !266, null}
!266 = metadata !{i32 786443, metadata !264, i32 45, i32 39, metadata !38, i32 3} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/simpleSummation/simpleSummation.cu]
!267 = metadata !{i32 47, i32 5, metadata !266, null}
!268 = metadata !{i32 44, i32 28, metadata !262, null}
!269 = metadata !{i32 49, i32 3, metadata !253, null}
!270 = metadata !{i32 397, i32 115, metadata !68, null}
!271 = metadata !{i32 397, i32 116, metadata !272, null}
!272 = metadata !{i32 786443, metadata !68, i32 397, i32 115, metadata !43, i32 4} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/simpleSummation//home/peng/gklee-clang/gklee/trunk/Gklee/include/
!273 = metadata !{i32 14, i32 3, metadata !274, null}
!274 = metadata !{i32 786443, metadata !149, i32 13, i32 52, metadata !150, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/cudaMemManage.c]
!275 = metadata !{i32 15, i32 21, metadata !274, null}
!276 = metadata !{metadata !"any pointer", metadata !277}
!277 = metadata !{metadata !"omnipotent char", metadata !278}
!278 = metadata !{metadata !"Simple C/C++ TBAA"}
!279 = metadata !{i32 16, i32 3, metadata !274, null}
!280 = metadata !{i32 18, i32 3, metadata !274, null}
!281 = metadata !{i32 22, i32 3, metadata !282, null}
!282 = metadata !{i32 786443, metadata !162, i32 21, i32 92, metadata !150, i32 1} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/cudaMemManage.c]
!283 = metadata !{i32 23, i32 3, metadata !282, null}
!284 = metadata !{i32 27, i32 3, metadata !285, null}
!285 = metadata !{i32 786443, metadata !173, i32 26, i32 63, metadata !150, i32 2} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/cudaMemManage.c]
!286 = metadata !{i32 28, i32 3, metadata !285, null}
!287 = metadata !{i32 32, i32 3, metadata !288, null}
!288 = metadata !{i32 786443, metadata !181, i32 31, i32 36, metadata !150, i32 3} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/runtime/Intrinsic/cudaMemManage.c]
!289 = metadata !{i32 33, i32 3, metadata !288, null}
!290 = metadata !{i32 16, i32 3, metadata !201, null}
!291 = metadata !{i32 17, i32 5, metadata !201, null}
!292 = metadata !{i32 18, i32 3, metadata !201, null}
!293 = metadata !{i32 14, i32 5, metadata !237, null}
!294 = metadata !{i32 15, i32 7, metadata !237, null}
!295 = metadata !{i32 16, i32 5, metadata !237, null}
