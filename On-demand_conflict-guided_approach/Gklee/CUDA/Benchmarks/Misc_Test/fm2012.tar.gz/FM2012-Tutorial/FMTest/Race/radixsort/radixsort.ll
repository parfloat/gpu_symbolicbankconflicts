; ModuleID = 'radixsort'
target datalayout = "e-p:64:64:64-i1:8:8-i8:8:8-i16:16:16-i32:32:32-i64:64:64-f32:32:32-f64:64:64-v64:64:64-v128:128:128-a0:0:64-s0:64:64-f80:128:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%struct.dim3 = type { i32, i32, i32 }
%struct.uint4 = type { i32, i32, i32, i32 }
%struct.uint3 = type { i32, i32, i32 }
%struct.CUDPPHandle = type { i8 }
%struct.CUstream_st = type opaque
%class.RadixSort = type { %struct.CUDPPHandle, i32, i32*, i32*, i32*, i32*, i32* }

@_ZZ14_Z5scan45uint45uint4E39__cuda_local_var_23520_34_non_const_ptr = internal global [1024 x i32] zeroinitializer, section "__shared__", align 16
@_ZZ44_Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4P5uint4E41__cuda_local_var_23682_34_non_const_sMem1 = internal global [4096 x i32] zeroinitializer, section "__shared__", align 16
@_ZZ25_Z5rank4ILi256EE5uint4S0_5uint4E43__cuda_local_var_23564_34_non_const_numtrue = internal global i32 0, section "__shared__", align 4
@gridDim = global %struct.dim3 zeroinitializer, align 4
@blockIdx = global %struct.dim3 zeroinitializer, align 4
@blockDim = global %struct.dim3 zeroinitializer, align 4
@threadIdx = global %struct.dim3 zeroinitializer, align 4
@bManualCoalesce = global i8 0, align 1
@numCTAs = global [6 x i32] zeroinitializer, align 16
@numSMs = global i32 0, align 4
@persistentCTAThreshold = global [2 x i32] zeroinitializer, align 4
@persistentCTAThresholdFullBlocks = global [2 x i32] zeroinitializer, align 4
@.str = private unnamed_addr constant [62 x i8] c"The sorting algorithm is incorrect since keys[%d] < keys[%d]!\00", align 1
@.str4 = private unnamed_addr constant [24 x i8] c"RadixSort::initialize()\00", align 1
@llvm.global_ctors = appending global [1 x { i32, void ()* }] [{ i32, void ()* } { i32 65535, void ()* @_GLOBAL__I_a }]

define i32 @_Z9floatFlipILb1EEjj(i32 %f) nounwind uwtable section "__device__" {
entry:
  %f.addr = alloca i32, align 4
  %__cuda_local_var_23427_14_non_const_mask = alloca i32, align 4
  store i32 %f, i32* %f.addr, align 4
  %0 = load i32* %f.addr, align 4
  %shr = lshr i32 %0, 31
  %sub = sub nsw i32 0, %shr
  %or = or i32 %sub, -2147483648
  store i32 %or, i32* %__cuda_local_var_23427_14_non_const_mask, align 4
  %1 = load i32* %f.addr, align 4
  %2 = load i32* %__cuda_local_var_23427_14_non_const_mask, align 4
  %xor = xor i32 %1, %2
  ret i32 %xor
}

define i32 @_Z11floatUnflipILb1EEjj(i32 %f) nounwind uwtable section "__device__" {
entry:
  %f.addr = alloca i32, align 4
  %__cuda_local_var_23445_14_non_const_mask = alloca i32, align 4
  store i32 %f, i32* %f.addr, align 4
  %0 = load i32* %f.addr, align 4
  %shr = lshr i32 %0, 31
  %sub = sub i32 %shr, 1
  %or = or i32 %sub, -2147483648
  store i32 %or, i32* %__cuda_local_var_23445_14_non_const_mask, align 4
  %1 = load i32* %f.addr, align 4
  %2 = load i32* %__cuda_local_var_23445_14_non_const_mask, align 4
  %xor = xor i32 %1, %2
  ret i32 %xor
}

define { i64, i64 } @_Z5scan45uint4(i64 %idata.coerce0, i64 %idata.coerce1) uwtable section "__device__" {
entry:
  %retval = alloca %struct.uint4, align 16
  %idata = alloca %struct.uint4, align 16
  %__cuda_local_var_23522_10_non_const_idx = alloca i32, align 4
  %__cuda_local_var_23525_10_non_const_sum = alloca [3 x i32], align 4
  %__cuda_local_var_23530_10_non_const_val = alloca i32, align 4
  %0 = bitcast %struct.uint4* %idata to { i64, i64 }*
  %1 = getelementptr { i64, i64 }* %0, i32 0, i32 0
  store i64 %idata.coerce0, i64* %1
  %2 = getelementptr { i64, i64 }* %0, i32 0, i32 1
  store i64 %idata.coerce1, i64* %2
  %3 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @threadIdx to %struct.uint3*), i32 0, i32 0), align 4
  store i32 %3, i32* %__cuda_local_var_23522_10_non_const_idx, align 4
  %4 = bitcast %struct.uint4* %retval to i8*
  %5 = bitcast %struct.uint4* %idata to i8*
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* %4, i8* %5, i64 16, i32 16, i1 false)
  %x = getelementptr inbounds %struct.uint4* %retval, i32 0, i32 0
  %6 = load i32* %x, align 4
  %arrayidx = getelementptr inbounds [3 x i32]* %__cuda_local_var_23525_10_non_const_sum, i32 0, i64 0
  store i32 %6, i32* %arrayidx, align 4
  %y = getelementptr inbounds %struct.uint4* %retval, i32 0, i32 1
  %7 = load i32* %y, align 4
  %arrayidx1 = getelementptr inbounds [3 x i32]* %__cuda_local_var_23525_10_non_const_sum, i32 0, i64 0
  %8 = load i32* %arrayidx1, align 4
  %add = add i32 %7, %8
  %arrayidx2 = getelementptr inbounds [3 x i32]* %__cuda_local_var_23525_10_non_const_sum, i32 0, i64 1
  store i32 %add, i32* %arrayidx2, align 4
  %z = getelementptr inbounds %struct.uint4* %retval, i32 0, i32 2
  %9 = load i32* %z, align 4
  %arrayidx3 = getelementptr inbounds [3 x i32]* %__cuda_local_var_23525_10_non_const_sum, i32 0, i64 1
  %10 = load i32* %arrayidx3, align 4
  %add4 = add i32 %9, %10
  %arrayidx5 = getelementptr inbounds [3 x i32]* %__cuda_local_var_23525_10_non_const_sum, i32 0, i64 2
  store i32 %add4, i32* %arrayidx5, align 4
  %w = getelementptr inbounds %struct.uint4* %retval, i32 0, i32 3
  %11 = load i32* %w, align 4
  %arrayidx6 = getelementptr inbounds [3 x i32]* %__cuda_local_var_23525_10_non_const_sum, i32 0, i64 2
  %12 = load i32* %arrayidx6, align 4
  %add7 = add i32 %11, %12
  store i32 %add7, i32* %__cuda_local_var_23530_10_non_const_val, align 4
  %13 = load i32* %__cuda_local_var_23530_10_non_const_val, align 4
  %call = call i32 @_Z8scanwarpIjLi4EET_S0_PS0_(i32 %13, i32* getelementptr inbounds ([1024 x i32]* @_ZZ14_Z5scan45uint45uint4E39__cuda_local_var_23520_34_non_const_ptr, i32 0, i32 0))
  store i32 %call, i32* %__cuda_local_var_23530_10_non_const_val, align 4
  call void @__syncthreads()
  %14 = load i32* %__cuda_local_var_23522_10_non_const_idx, align 4
  %and = and i32 %14, 31
  %cmp = icmp eq i32 %and, 31
  br i1 %cmp, label %if.then, label %if.end

if.then:                                          ; preds = %entry
  %15 = load i32* %__cuda_local_var_23530_10_non_const_val, align 4
  %w8 = getelementptr inbounds %struct.uint4* %retval, i32 0, i32 3
  %16 = load i32* %w8, align 4
  %add9 = add i32 %15, %16
  %arrayidx10 = getelementptr inbounds [3 x i32]* %__cuda_local_var_23525_10_non_const_sum, i32 0, i64 2
  %17 = load i32* %arrayidx10, align 4
  %add11 = add i32 %add9, %17
  %18 = load i32* %__cuda_local_var_23522_10_non_const_idx, align 4
  %shr = lshr i32 %18, 5
  %idxprom = zext i32 %shr to i64
  %arrayidx12 = getelementptr inbounds [1024 x i32]* @_ZZ14_Z5scan45uint45uint4E39__cuda_local_var_23520_34_non_const_ptr, i32 0, i64 %idxprom
  store i32 %add11, i32* %arrayidx12, align 4
  br label %if.end

if.end:                                           ; preds = %if.then, %entry
  call void @__syncthreads()
  %19 = load i32* %__cuda_local_var_23522_10_non_const_idx, align 4
  %idxprom13 = zext i32 %19 to i64
  %arrayidx14 = getelementptr inbounds [1024 x i32]* @_ZZ14_Z5scan45uint45uint4E39__cuda_local_var_23520_34_non_const_ptr, i32 0, i64 %idxprom13
  %20 = load i32* %arrayidx14, align 4
  %call15 = call i32 @_Z8scanwarpIjLi2EET_S0_PS0_(i32 %20, i32* getelementptr inbounds ([1024 x i32]* @_ZZ14_Z5scan45uint45uint4E39__cuda_local_var_23520_34_non_const_ptr, i32 0, i32 0))
  %21 = load i32* %__cuda_local_var_23522_10_non_const_idx, align 4
  %idxprom16 = zext i32 %21 to i64
  %arrayidx17 = getelementptr inbounds [1024 x i32]* @_ZZ14_Z5scan45uint45uint4E39__cuda_local_var_23520_34_non_const_ptr, i32 0, i64 %idxprom16
  store i32 %call15, i32* %arrayidx17, align 4
  call void @__syncthreads()
  %22 = load i32* %__cuda_local_var_23522_10_non_const_idx, align 4
  %shr18 = lshr i32 %22, 5
  %idxprom19 = zext i32 %shr18 to i64
  %arrayidx20 = getelementptr inbounds [1024 x i32]* @_ZZ14_Z5scan45uint45uint4E39__cuda_local_var_23520_34_non_const_ptr, i32 0, i64 %idxprom19
  %23 = load i32* %arrayidx20, align 4
  %24 = load i32* %__cuda_local_var_23530_10_non_const_val, align 4
  %add21 = add i32 %24, %23
  store i32 %add21, i32* %__cuda_local_var_23530_10_non_const_val, align 4
  %25 = load i32* %__cuda_local_var_23530_10_non_const_val, align 4
  %x22 = getelementptr inbounds %struct.uint4* %retval, i32 0, i32 0
  store i32 %25, i32* %x22, align 4
  %26 = load i32* %__cuda_local_var_23530_10_non_const_val, align 4
  %arrayidx23 = getelementptr inbounds [3 x i32]* %__cuda_local_var_23525_10_non_const_sum, i32 0, i64 0
  %27 = load i32* %arrayidx23, align 4
  %add24 = add i32 %26, %27
  %y25 = getelementptr inbounds %struct.uint4* %retval, i32 0, i32 1
  store i32 %add24, i32* %y25, align 4
  %28 = load i32* %__cuda_local_var_23530_10_non_const_val, align 4
  %arrayidx26 = getelementptr inbounds [3 x i32]* %__cuda_local_var_23525_10_non_const_sum, i32 0, i64 1
  %29 = load i32* %arrayidx26, align 4
  %add27 = add i32 %28, %29
  %z28 = getelementptr inbounds %struct.uint4* %retval, i32 0, i32 2
  store i32 %add27, i32* %z28, align 4
  %30 = load i32* %__cuda_local_var_23530_10_non_const_val, align 4
  %arrayidx29 = getelementptr inbounds [3 x i32]* %__cuda_local_var_23525_10_non_const_sum, i32 0, i64 2
  %31 = load i32* %arrayidx29, align 4
  %add30 = add i32 %30, %31
  %w31 = getelementptr inbounds %struct.uint4* %retval, i32 0, i32 3
  store i32 %add30, i32* %w31, align 4
  %32 = bitcast %struct.uint4* %retval to { i64, i64 }*
  %33 = load { i64, i64 }* %32, align 1
  ret { i64, i64 } %33
}

declare void @llvm.memcpy.p0i8.p0i8.i64(i8* nocapture, i8* nocapture, i64, i32, i1) nounwind

define i32 @_Z8scanwarpIjLi4EET_S0_PS0_(i32 %val, i32* %sData) uwtable section "__device__" {
entry:
  %val.addr = alloca i32, align 4
  %sData.addr = alloca i32*, align 8
  %__cuda_local_var_23493_9_non_const_idx = alloca i32, align 4
  %__cuda_local_var_23499_11_non_const_t = alloca i32, align 4
  store i32 %val, i32* %val.addr, align 4
  store i32* %sData, i32** %sData.addr, align 8
  %0 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @threadIdx to %struct.uint3*), i32 0, i32 0), align 4
  %mul = mul i32 2, %0
  %1 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @threadIdx to %struct.uint3*), i32 0, i32 0), align 4
  %and = and i32 %1, 31
  %sub = sub i32 %mul, %and
  store i32 %sub, i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %2 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %idxprom = sext i32 %2 to i64
  %3 = load i32** %sData.addr, align 8
  %arrayidx = getelementptr inbounds i32* %3, i64 %idxprom
  store i32 0, i32* %arrayidx, align 4
  %4 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %add = add i32 %4, 32
  store i32 %add, i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %5 = load i32* %val.addr, align 4
  %6 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %idxprom1 = sext i32 %6 to i64
  %7 = load i32** %sData.addr, align 8
  %arrayidx2 = getelementptr inbounds i32* %7, i64 %idxprom1
  store i32 %5, i32* %arrayidx2, align 4
  call void @__syncthreads()
  %8 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %sub3 = sub nsw i32 %8, 1
  %idxprom4 = sext i32 %sub3 to i64
  %9 = load i32** %sData.addr, align 8
  %arrayidx5 = getelementptr inbounds i32* %9, i64 %idxprom4
  %10 = load i32* %arrayidx5, align 4
  store i32 %10, i32* %__cuda_local_var_23499_11_non_const_t, align 4
  call void @__syncthreads()
  %11 = load i32* %__cuda_local_var_23499_11_non_const_t, align 4
  %12 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %idxprom6 = sext i32 %12 to i64
  %13 = load i32** %sData.addr, align 8
  %arrayidx7 = getelementptr inbounds i32* %13, i64 %idxprom6
  %14 = load i32* %arrayidx7, align 4
  %add8 = add i32 %14, %11
  store i32 %add8, i32* %arrayidx7, align 4
  call void @__syncthreads()
  %15 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %sub9 = sub nsw i32 %15, 2
  %idxprom10 = sext i32 %sub9 to i64
  %16 = load i32** %sData.addr, align 8
  %arrayidx11 = getelementptr inbounds i32* %16, i64 %idxprom10
  %17 = load i32* %arrayidx11, align 4
  store i32 %17, i32* %__cuda_local_var_23499_11_non_const_t, align 4
  call void @__syncthreads()
  %18 = load i32* %__cuda_local_var_23499_11_non_const_t, align 4
  %19 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %idxprom12 = sext i32 %19 to i64
  %20 = load i32** %sData.addr, align 8
  %arrayidx13 = getelementptr inbounds i32* %20, i64 %idxprom12
  %21 = load i32* %arrayidx13, align 4
  %add14 = add i32 %21, %18
  store i32 %add14, i32* %arrayidx13, align 4
  call void @__syncthreads()
  %22 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %sub15 = sub nsw i32 %22, 4
  %idxprom16 = sext i32 %sub15 to i64
  %23 = load i32** %sData.addr, align 8
  %arrayidx17 = getelementptr inbounds i32* %23, i64 %idxprom16
  %24 = load i32* %arrayidx17, align 4
  store i32 %24, i32* %__cuda_local_var_23499_11_non_const_t, align 4
  call void @__syncthreads()
  %25 = load i32* %__cuda_local_var_23499_11_non_const_t, align 4
  %26 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %idxprom18 = sext i32 %26 to i64
  %27 = load i32** %sData.addr, align 8
  %arrayidx19 = getelementptr inbounds i32* %27, i64 %idxprom18
  %28 = load i32* %arrayidx19, align 4
  %add20 = add i32 %28, %25
  store i32 %add20, i32* %arrayidx19, align 4
  call void @__syncthreads()
  %29 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %sub21 = sub nsw i32 %29, 8
  %idxprom22 = sext i32 %sub21 to i64
  %30 = load i32** %sData.addr, align 8
  %arrayidx23 = getelementptr inbounds i32* %30, i64 %idxprom22
  %31 = load i32* %arrayidx23, align 4
  store i32 %31, i32* %__cuda_local_var_23499_11_non_const_t, align 4
  call void @__syncthreads()
  %32 = load i32* %__cuda_local_var_23499_11_non_const_t, align 4
  %33 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %idxprom24 = sext i32 %33 to i64
  %34 = load i32** %sData.addr, align 8
  %arrayidx25 = getelementptr inbounds i32* %34, i64 %idxprom24
  %35 = load i32* %arrayidx25, align 4
  %add26 = add i32 %35, %32
  store i32 %add26, i32* %arrayidx25, align 4
  call void @__syncthreads()
  %36 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %sub27 = sub nsw i32 %36, 16
  %idxprom28 = sext i32 %sub27 to i64
  %37 = load i32** %sData.addr, align 8
  %arrayidx29 = getelementptr inbounds i32* %37, i64 %idxprom28
  %38 = load i32* %arrayidx29, align 4
  store i32 %38, i32* %__cuda_local_var_23499_11_non_const_t, align 4
  call void @__syncthreads()
  %39 = load i32* %__cuda_local_var_23499_11_non_const_t, align 4
  %40 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %idxprom30 = sext i32 %40 to i64
  %41 = load i32** %sData.addr, align 8
  %arrayidx31 = getelementptr inbounds i32* %41, i64 %idxprom30
  %42 = load i32* %arrayidx31, align 4
  %add32 = add i32 %42, %39
  store i32 %add32, i32* %arrayidx31, align 4
  call void @__syncthreads()
  %43 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %idxprom33 = sext i32 %43 to i64
  %44 = load i32** %sData.addr, align 8
  %arrayidx34 = getelementptr inbounds i32* %44, i64 %idxprom33
  %45 = load i32* %arrayidx34, align 4
  %46 = load i32* %val.addr, align 4
  %sub35 = sub i32 %45, %46
  ret i32 %sub35
}

declare void @__syncthreads() section "__device__"

define i32 @_Z8scanwarpIjLi2EET_S0_PS0_(i32 %val, i32* %sData) uwtable section "__device__" {
entry:
  %val.addr = alloca i32, align 4
  %sData.addr = alloca i32*, align 8
  %__cuda_local_var_23493_9_non_const_idx = alloca i32, align 4
  %__cuda_local_var_23499_11_non_const_t = alloca i32, align 4
  store i32 %val, i32* %val.addr, align 4
  store i32* %sData, i32** %sData.addr, align 8
  %0 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @threadIdx to %struct.uint3*), i32 0, i32 0), align 4
  %mul = mul i32 2, %0
  %1 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @threadIdx to %struct.uint3*), i32 0, i32 0), align 4
  %and = and i32 %1, 31
  %sub = sub i32 %mul, %and
  store i32 %sub, i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %2 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %idxprom = sext i32 %2 to i64
  %3 = load i32** %sData.addr, align 8
  %arrayidx = getelementptr inbounds i32* %3, i64 %idxprom
  store i32 0, i32* %arrayidx, align 4
  %4 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %add = add i32 %4, 32
  store i32 %add, i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %5 = load i32* %val.addr, align 4
  %6 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %idxprom1 = sext i32 %6 to i64
  %7 = load i32** %sData.addr, align 8
  %arrayidx2 = getelementptr inbounds i32* %7, i64 %idxprom1
  store i32 %5, i32* %arrayidx2, align 4
  call void @__syncthreads()
  %8 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %sub3 = sub nsw i32 %8, 1
  %idxprom4 = sext i32 %sub3 to i64
  %9 = load i32** %sData.addr, align 8
  %arrayidx5 = getelementptr inbounds i32* %9, i64 %idxprom4
  %10 = load i32* %arrayidx5, align 4
  store i32 %10, i32* %__cuda_local_var_23499_11_non_const_t, align 4
  call void @__syncthreads()
  %11 = load i32* %__cuda_local_var_23499_11_non_const_t, align 4
  %12 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %idxprom6 = sext i32 %12 to i64
  %13 = load i32** %sData.addr, align 8
  %arrayidx7 = getelementptr inbounds i32* %13, i64 %idxprom6
  %14 = load i32* %arrayidx7, align 4
  %add8 = add i32 %14, %11
  store i32 %add8, i32* %arrayidx7, align 4
  call void @__syncthreads()
  %15 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %sub9 = sub nsw i32 %15, 2
  %idxprom10 = sext i32 %sub9 to i64
  %16 = load i32** %sData.addr, align 8
  %arrayidx11 = getelementptr inbounds i32* %16, i64 %idxprom10
  %17 = load i32* %arrayidx11, align 4
  store i32 %17, i32* %__cuda_local_var_23499_11_non_const_t, align 4
  call void @__syncthreads()
  %18 = load i32* %__cuda_local_var_23499_11_non_const_t, align 4
  %19 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %idxprom12 = sext i32 %19 to i64
  %20 = load i32** %sData.addr, align 8
  %arrayidx13 = getelementptr inbounds i32* %20, i64 %idxprom12
  %21 = load i32* %arrayidx13, align 4
  %add14 = add i32 %21, %18
  store i32 %add14, i32* %arrayidx13, align 4
  call void @__syncthreads()
  %22 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %sub15 = sub nsw i32 %22, 4
  %idxprom16 = sext i32 %sub15 to i64
  %23 = load i32** %sData.addr, align 8
  %arrayidx17 = getelementptr inbounds i32* %23, i64 %idxprom16
  %24 = load i32* %arrayidx17, align 4
  store i32 %24, i32* %__cuda_local_var_23499_11_non_const_t, align 4
  call void @__syncthreads()
  %25 = load i32* %__cuda_local_var_23499_11_non_const_t, align 4
  %26 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %idxprom18 = sext i32 %26 to i64
  %27 = load i32** %sData.addr, align 8
  %arrayidx19 = getelementptr inbounds i32* %27, i64 %idxprom18
  %28 = load i32* %arrayidx19, align 4
  %add20 = add i32 %28, %25
  store i32 %add20, i32* %arrayidx19, align 4
  call void @__syncthreads()
  %29 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %sub21 = sub nsw i32 %29, 8
  %idxprom22 = sext i32 %sub21 to i64
  %30 = load i32** %sData.addr, align 8
  %arrayidx23 = getelementptr inbounds i32* %30, i64 %idxprom22
  %31 = load i32* %arrayidx23, align 4
  store i32 %31, i32* %__cuda_local_var_23499_11_non_const_t, align 4
  call void @__syncthreads()
  %32 = load i32* %__cuda_local_var_23499_11_non_const_t, align 4
  %33 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %idxprom24 = sext i32 %33 to i64
  %34 = load i32** %sData.addr, align 8
  %arrayidx25 = getelementptr inbounds i32* %34, i64 %idxprom24
  %35 = load i32* %arrayidx25, align 4
  %add26 = add i32 %35, %32
  store i32 %add26, i32* %arrayidx25, align 4
  call void @__syncthreads()
  %36 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %sub27 = sub nsw i32 %36, 16
  %idxprom28 = sext i32 %sub27 to i64
  %37 = load i32** %sData.addr, align 8
  %arrayidx29 = getelementptr inbounds i32* %37, i64 %idxprom28
  %38 = load i32* %arrayidx29, align 4
  store i32 %38, i32* %__cuda_local_var_23499_11_non_const_t, align 4
  call void @__syncthreads()
  %39 = load i32* %__cuda_local_var_23499_11_non_const_t, align 4
  %40 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %idxprom30 = sext i32 %40 to i64
  %41 = load i32** %sData.addr, align 8
  %arrayidx31 = getelementptr inbounds i32* %41, i64 %idxprom30
  %42 = load i32* %arrayidx31, align 4
  %add32 = add i32 %42, %39
  store i32 %add32, i32* %arrayidx31, align 4
  call void @__syncthreads()
  %43 = load i32* %__cuda_local_var_23493_9_non_const_idx, align 4
  %idxprom33 = sext i32 %43 to i64
  %44 = load i32** %sData.addr, align 8
  %arrayidx34 = getelementptr inbounds i32* %44, i64 %idxprom33
  %45 = load i32* %arrayidx34, align 4
  %46 = load i32* %val.addr, align 4
  %sub35 = sub i32 %45, %46
  ret i32 %sub35
}

define void @_Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4(%struct.uint4* %key) uwtable section "__device__" {
entry:
  %key.addr = alloca %struct.uint4*, align 8
  %shift = alloca i32, align 4
  %__cuda_local_var_23687_15_non_const_lsb = alloca %struct.uint4, align 16
  %__cuda_local_var_23693_15_non_const_r = alloca %struct.uint4, align 16
  %ref.tmp = alloca %struct.uint4, align 16
  %agg.tmp = alloca %struct.uint4, align 16
  store %struct.uint4* %key, %struct.uint4** %key.addr, align 8
  store i32 0, i32* %shift, align 4
  br label %for.cond

for.cond:                                         ; preds = %for.inc, %entry
  %0 = load i32* %shift, align 4
  %cmp = icmp ult i32 %0, 4
  br i1 %cmp, label %for.body, label %for.end

for.body:                                         ; preds = %for.cond
  %1 = load %struct.uint4** %key.addr, align 8
  %x = getelementptr inbounds %struct.uint4* %1, i32 0, i32 0
  %2 = load i32* %x, align 4
  %3 = load i32* %shift, align 4
  %shr = lshr i32 %2, %3
  %and = and i32 %shr, 1
  %tobool = icmp ne i32 %and, 0
  %lnot = xor i1 %tobool, true
  %conv = zext i1 %lnot to i32
  %x1 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23687_15_non_const_lsb, i32 0, i32 0
  store i32 %conv, i32* %x1, align 4
  %4 = load %struct.uint4** %key.addr, align 8
  %y = getelementptr inbounds %struct.uint4* %4, i32 0, i32 1
  %5 = load i32* %y, align 4
  %6 = load i32* %shift, align 4
  %shr2 = lshr i32 %5, %6
  %and3 = and i32 %shr2, 1
  %tobool4 = icmp ne i32 %and3, 0
  %lnot5 = xor i1 %tobool4, true
  %conv6 = zext i1 %lnot5 to i32
  %y7 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23687_15_non_const_lsb, i32 0, i32 1
  store i32 %conv6, i32* %y7, align 4
  %7 = load %struct.uint4** %key.addr, align 8
  %z = getelementptr inbounds %struct.uint4* %7, i32 0, i32 2
  %8 = load i32* %z, align 4
  %9 = load i32* %shift, align 4
  %shr8 = lshr i32 %8, %9
  %and9 = and i32 %shr8, 1
  %tobool10 = icmp ne i32 %and9, 0
  %lnot11 = xor i1 %tobool10, true
  %conv12 = zext i1 %lnot11 to i32
  %z13 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23687_15_non_const_lsb, i32 0, i32 2
  store i32 %conv12, i32* %z13, align 4
  %10 = load %struct.uint4** %key.addr, align 8
  %w = getelementptr inbounds %struct.uint4* %10, i32 0, i32 3
  %11 = load i32* %w, align 4
  %12 = load i32* %shift, align 4
  %shr14 = lshr i32 %11, %12
  %and15 = and i32 %shr14, 1
  %tobool16 = icmp ne i32 %and15, 0
  %lnot17 = xor i1 %tobool16, true
  %conv18 = zext i1 %lnot17 to i32
  %w19 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23687_15_non_const_lsb, i32 0, i32 3
  store i32 %conv18, i32* %w19, align 4
  %13 = bitcast %struct.uint4* %agg.tmp to i8*
  %14 = bitcast %struct.uint4* %__cuda_local_var_23687_15_non_const_lsb to i8*
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* %13, i8* %14, i64 16, i32 16, i1 false)
  %15 = bitcast %struct.uint4* %agg.tmp to { i64, i64 }*
  %16 = getelementptr { i64, i64 }* %15, i32 0, i32 0
  %17 = load i64* %16, align 1
  %18 = getelementptr { i64, i64 }* %15, i32 0, i32 1
  %19 = load i64* %18, align 1
  %call = call { i64, i64 } @_Z5rank4ILi256EE5uint4S0_(i64 %17, i64 %19)
  %20 = bitcast %struct.uint4* %ref.tmp to { i64, i64 }*
  %21 = getelementptr { i64, i64 }* %20, i32 0, i32 0
  %22 = extractvalue { i64, i64 } %call, 0
  store i64 %22, i64* %21, align 1
  %23 = getelementptr { i64, i64 }* %20, i32 0, i32 1
  %24 = extractvalue { i64, i64 } %call, 1
  store i64 %24, i64* %23, align 1
  %25 = bitcast %struct.uint4* %__cuda_local_var_23693_15_non_const_r to i8*
  %26 = bitcast %struct.uint4* %ref.tmp to i8*
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* %25, i8* %26, i64 16, i32 16, i1 false)
  %27 = load %struct.uint4** %key.addr, align 8
  %x20 = getelementptr inbounds %struct.uint4* %27, i32 0, i32 0
  %28 = load i32* %x20, align 4
  %x21 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23693_15_non_const_r, i32 0, i32 0
  %29 = load i32* %x21, align 4
  %and22 = and i32 %29, 3
  %mul = mul i32 %and22, 256
  %x23 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23693_15_non_const_r, i32 0, i32 0
  %30 = load i32* %x23, align 4
  %shr24 = lshr i32 %30, 2
  %add = add i32 %mul, %shr24
  %idxprom = zext i32 %add to i64
  %arrayidx = getelementptr inbounds [4096 x i32]* @_ZZ44_Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4P5uint4E41__cuda_local_var_23682_34_non_const_sMem1, i32 0, i64 %idxprom
  store i32 %28, i32* %arrayidx, align 4
  %31 = load %struct.uint4** %key.addr, align 8
  %y25 = getelementptr inbounds %struct.uint4* %31, i32 0, i32 1
  %32 = load i32* %y25, align 4
  %y26 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23693_15_non_const_r, i32 0, i32 1
  %33 = load i32* %y26, align 4
  %and27 = and i32 %33, 3
  %mul28 = mul i32 %and27, 256
  %y29 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23693_15_non_const_r, i32 0, i32 1
  %34 = load i32* %y29, align 4
  %shr30 = lshr i32 %34, 2
  %add31 = add i32 %mul28, %shr30
  %idxprom32 = zext i32 %add31 to i64
  %arrayidx33 = getelementptr inbounds [4096 x i32]* @_ZZ44_Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4P5uint4E41__cuda_local_var_23682_34_non_const_sMem1, i32 0, i64 %idxprom32
  store i32 %32, i32* %arrayidx33, align 4
  %35 = load %struct.uint4** %key.addr, align 8
  %z34 = getelementptr inbounds %struct.uint4* %35, i32 0, i32 2
  %36 = load i32* %z34, align 4
  %z35 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23693_15_non_const_r, i32 0, i32 2
  %37 = load i32* %z35, align 4
  %and36 = and i32 %37, 3
  %mul37 = mul i32 %and36, 256
  %z38 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23693_15_non_const_r, i32 0, i32 2
  %38 = load i32* %z38, align 4
  %shr39 = lshr i32 %38, 2
  %add40 = add i32 %mul37, %shr39
  %idxprom41 = zext i32 %add40 to i64
  %arrayidx42 = getelementptr inbounds [4096 x i32]* @_ZZ44_Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4P5uint4E41__cuda_local_var_23682_34_non_const_sMem1, i32 0, i64 %idxprom41
  store i32 %36, i32* %arrayidx42, align 4
  %39 = load %struct.uint4** %key.addr, align 8
  %w43 = getelementptr inbounds %struct.uint4* %39, i32 0, i32 3
  %40 = load i32* %w43, align 4
  %w44 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23693_15_non_const_r, i32 0, i32 3
  %41 = load i32* %w44, align 4
  %and45 = and i32 %41, 3
  %mul46 = mul i32 %and45, 256
  %w47 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23693_15_non_const_r, i32 0, i32 3
  %42 = load i32* %w47, align 4
  %shr48 = lshr i32 %42, 2
  %add49 = add i32 %mul46, %shr48
  %idxprom50 = zext i32 %add49 to i64
  %arrayidx51 = getelementptr inbounds [4096 x i32]* @_ZZ44_Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4P5uint4E41__cuda_local_var_23682_34_non_const_sMem1, i32 0, i64 %idxprom50
  store i32 %40, i32* %arrayidx51, align 4
  call void @__syncthreads()
  %43 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @threadIdx to %struct.uint3*), i32 0, i32 0), align 4
  %idxprom52 = zext i32 %43 to i64
  %arrayidx53 = getelementptr inbounds [4096 x i32]* @_ZZ44_Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4P5uint4E41__cuda_local_var_23682_34_non_const_sMem1, i32 0, i64 %idxprom52
  %44 = load i32* %arrayidx53, align 4
  %45 = load %struct.uint4** %key.addr, align 8
  %x54 = getelementptr inbounds %struct.uint4* %45, i32 0, i32 0
  store i32 %44, i32* %x54, align 4
  %46 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @threadIdx to %struct.uint3*), i32 0, i32 0), align 4
  %add55 = add i32 %46, 256
  %idxprom56 = zext i32 %add55 to i64
  %arrayidx57 = getelementptr inbounds [4096 x i32]* @_ZZ44_Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4P5uint4E41__cuda_local_var_23682_34_non_const_sMem1, i32 0, i64 %idxprom56
  %47 = load i32* %arrayidx57, align 4
  %48 = load %struct.uint4** %key.addr, align 8
  %y58 = getelementptr inbounds %struct.uint4* %48, i32 0, i32 1
  store i32 %47, i32* %y58, align 4
  %49 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @threadIdx to %struct.uint3*), i32 0, i32 0), align 4
  %add59 = add i32 %49, 512
  %idxprom60 = zext i32 %add59 to i64
  %arrayidx61 = getelementptr inbounds [4096 x i32]* @_ZZ44_Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4P5uint4E41__cuda_local_var_23682_34_non_const_sMem1, i32 0, i64 %idxprom60
  %50 = load i32* %arrayidx61, align 4
  %51 = load %struct.uint4** %key.addr, align 8
  %z62 = getelementptr inbounds %struct.uint4* %51, i32 0, i32 2
  store i32 %50, i32* %z62, align 4
  %52 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @threadIdx to %struct.uint3*), i32 0, i32 0), align 4
  %add63 = add i32 %52, 768
  %idxprom64 = zext i32 %add63 to i64
  %arrayidx65 = getelementptr inbounds [4096 x i32]* @_ZZ44_Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4P5uint4E41__cuda_local_var_23682_34_non_const_sMem1, i32 0, i64 %idxprom64
  %53 = load i32* %arrayidx65, align 4
  %54 = load %struct.uint4** %key.addr, align 8
  %w66 = getelementptr inbounds %struct.uint4* %54, i32 0, i32 3
  store i32 %53, i32* %w66, align 4
  call void @__syncthreads()
  br label %for.inc

for.inc:                                          ; preds = %for.body
  %55 = load i32* %shift, align 4
  %inc = add i32 %55, 1
  store i32 %inc, i32* %shift, align 4
  br label %for.cond

for.end:                                          ; preds = %for.cond
  ret void
}

define { i64, i64 } @_Z5rank4ILi256EE5uint4S0_(i64 %preds.coerce0, i64 %preds.coerce1) uwtable section "__device__" {
entry:
  %retval = alloca %struct.uint4, align 16
  %preds = alloca %struct.uint4, align 16
  %__cuda_local_var_23562_11_non_const_address = alloca %struct.uint4, align 16
  %__cuda_local_var_23572_10_non_const_idx = alloca i32, align 4
  %ref.tmp = alloca %struct.uint4, align 16
  %agg.tmp = alloca %struct.uint4, align 16
  %0 = bitcast %struct.uint4* %preds to { i64, i64 }*
  %1 = getelementptr { i64, i64 }* %0, i32 0, i32 0
  store i64 %preds.coerce0, i64* %1
  %2 = getelementptr { i64, i64 }* %0, i32 0, i32 1
  store i64 %preds.coerce1, i64* %2
  %3 = bitcast %struct.uint4* %agg.tmp to i8*
  %4 = bitcast %struct.uint4* %preds to i8*
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* %3, i8* %4, i64 16, i32 16, i1 false)
  %5 = bitcast %struct.uint4* %agg.tmp to { i64, i64 }*
  %6 = getelementptr { i64, i64 }* %5, i32 0, i32 0
  %7 = load i64* %6, align 1
  %8 = getelementptr { i64, i64 }* %5, i32 0, i32 1
  %9 = load i64* %8, align 1
  %call = call { i64, i64 } @_Z5scan45uint4(i64 %7, i64 %9)
  %10 = bitcast %struct.uint4* %ref.tmp to { i64, i64 }*
  %11 = getelementptr { i64, i64 }* %10, i32 0, i32 0
  %12 = extractvalue { i64, i64 } %call, 0
  store i64 %12, i64* %11, align 1
  %13 = getelementptr { i64, i64 }* %10, i32 0, i32 1
  %14 = extractvalue { i64, i64 } %call, 1
  store i64 %14, i64* %13, align 1
  %15 = bitcast %struct.uint4* %__cuda_local_var_23562_11_non_const_address to i8*
  %16 = bitcast %struct.uint4* %ref.tmp to i8*
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* %15, i8* %16, i64 16, i32 16, i1 false)
  %17 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @threadIdx to %struct.uint3*), i32 0, i32 0), align 4
  %cmp = icmp eq i32 %17, 255
  br i1 %cmp, label %if.then, label %if.end

if.then:                                          ; preds = %entry
  %w = getelementptr inbounds %struct.uint4* %__cuda_local_var_23562_11_non_const_address, i32 0, i32 3
  %18 = load i32* %w, align 4
  %w1 = getelementptr inbounds %struct.uint4* %preds, i32 0, i32 3
  %19 = load i32* %w1, align 4
  %add = add i32 %18, %19
  store i32 %add, i32* @_ZZ25_Z5rank4ILi256EE5uint4S0_5uint4E43__cuda_local_var_23564_34_non_const_numtrue, align 4
  br label %if.end

if.end:                                           ; preds = %if.then, %entry
  call void @__syncthreads()
  %20 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @threadIdx to %struct.uint3*), i32 0, i32 0), align 4
  %shl = shl i32 %20, 2
  store i32 %shl, i32* %__cuda_local_var_23572_10_non_const_idx, align 4
  %x = getelementptr inbounds %struct.uint4* %preds, i32 0, i32 0
  %21 = load i32* %x, align 4
  %tobool = icmp ne i32 %21, 0
  br i1 %tobool, label %cond.true, label %cond.false

cond.true:                                        ; preds = %if.end
  %x2 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23562_11_non_const_address, i32 0, i32 0
  %22 = load i32* %x2, align 4
  br label %cond.end

cond.false:                                       ; preds = %if.end
  %23 = load i32* @_ZZ25_Z5rank4ILi256EE5uint4S0_5uint4E43__cuda_local_var_23564_34_non_const_numtrue, align 4
  %24 = load i32* %__cuda_local_var_23572_10_non_const_idx, align 4
  %add3 = add i32 %23, %24
  %x4 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23562_11_non_const_address, i32 0, i32 0
  %25 = load i32* %x4, align 4
  %sub = sub i32 %add3, %25
  br label %cond.end

cond.end:                                         ; preds = %cond.false, %cond.true
  %cond = phi i32 [ %22, %cond.true ], [ %sub, %cond.false ]
  %x5 = getelementptr inbounds %struct.uint4* %retval, i32 0, i32 0
  store i32 %cond, i32* %x5, align 4
  %y = getelementptr inbounds %struct.uint4* %preds, i32 0, i32 1
  %26 = load i32* %y, align 4
  %tobool6 = icmp ne i32 %26, 0
  br i1 %tobool6, label %cond.true7, label %cond.false9

cond.true7:                                       ; preds = %cond.end
  %y8 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23562_11_non_const_address, i32 0, i32 1
  %27 = load i32* %y8, align 4
  br label %cond.end14

cond.false9:                                      ; preds = %cond.end
  %28 = load i32* @_ZZ25_Z5rank4ILi256EE5uint4S0_5uint4E43__cuda_local_var_23564_34_non_const_numtrue, align 4
  %29 = load i32* %__cuda_local_var_23572_10_non_const_idx, align 4
  %add10 = add i32 %28, %29
  %add11 = add i32 %add10, 1
  %y12 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23562_11_non_const_address, i32 0, i32 1
  %30 = load i32* %y12, align 4
  %sub13 = sub i32 %add11, %30
  br label %cond.end14

cond.end14:                                       ; preds = %cond.false9, %cond.true7
  %cond15 = phi i32 [ %27, %cond.true7 ], [ %sub13, %cond.false9 ]
  %y16 = getelementptr inbounds %struct.uint4* %retval, i32 0, i32 1
  store i32 %cond15, i32* %y16, align 4
  %z = getelementptr inbounds %struct.uint4* %preds, i32 0, i32 2
  %31 = load i32* %z, align 4
  %tobool17 = icmp ne i32 %31, 0
  br i1 %tobool17, label %cond.true18, label %cond.false20

cond.true18:                                      ; preds = %cond.end14
  %z19 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23562_11_non_const_address, i32 0, i32 2
  %32 = load i32* %z19, align 4
  br label %cond.end25

cond.false20:                                     ; preds = %cond.end14
  %33 = load i32* @_ZZ25_Z5rank4ILi256EE5uint4S0_5uint4E43__cuda_local_var_23564_34_non_const_numtrue, align 4
  %34 = load i32* %__cuda_local_var_23572_10_non_const_idx, align 4
  %add21 = add i32 %33, %34
  %add22 = add i32 %add21, 2
  %z23 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23562_11_non_const_address, i32 0, i32 2
  %35 = load i32* %z23, align 4
  %sub24 = sub i32 %add22, %35
  br label %cond.end25

cond.end25:                                       ; preds = %cond.false20, %cond.true18
  %cond26 = phi i32 [ %32, %cond.true18 ], [ %sub24, %cond.false20 ]
  %z27 = getelementptr inbounds %struct.uint4* %retval, i32 0, i32 2
  store i32 %cond26, i32* %z27, align 4
  %w28 = getelementptr inbounds %struct.uint4* %preds, i32 0, i32 3
  %36 = load i32* %w28, align 4
  %tobool29 = icmp ne i32 %36, 0
  br i1 %tobool29, label %cond.true30, label %cond.false32

cond.true30:                                      ; preds = %cond.end25
  %w31 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23562_11_non_const_address, i32 0, i32 3
  %37 = load i32* %w31, align 4
  br label %cond.end37

cond.false32:                                     ; preds = %cond.end25
  %38 = load i32* @_ZZ25_Z5rank4ILi256EE5uint4S0_5uint4E43__cuda_local_var_23564_34_non_const_numtrue, align 4
  %39 = load i32* %__cuda_local_var_23572_10_non_const_idx, align 4
  %add33 = add i32 %38, %39
  %add34 = add i32 %add33, 3
  %w35 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23562_11_non_const_address, i32 0, i32 3
  %40 = load i32* %w35, align 4
  %sub36 = sub i32 %add34, %40
  br label %cond.end37

cond.end37:                                       ; preds = %cond.false32, %cond.true30
  %cond38 = phi i32 [ %37, %cond.true30 ], [ %sub36, %cond.false32 ]
  %w39 = getelementptr inbounds %struct.uint4* %retval, i32 0, i32 3
  store i32 %cond38, i32* %w39, align 4
  %41 = bitcast %struct.uint4* %retval to { i64, i64 }*
  %42 = load { i64, i64 }* %41, align 1
  ret { i64, i64 } %42
}

define i32 @_Z9floatFlipILb0EEjj(i32 %f) nounwind uwtable section "__device__" {
entry:
  %f.addr = alloca i32, align 4
  store i32 %f, i32* %f.addr, align 4
  %0 = load i32* %f.addr, align 4
  ret i32 %0
}

define void @_Z10flipFloatsPjj(i32* %values, i32 %numValues) uwtable {
entry:
  %values.addr = alloca i32*, align 8
  %numValues.addr = alloca i32, align 4
  %__cuda_local_var_23458_10_non_const_index = alloca i32, align 4
  store i32* %values, i32** %values.addr, align 8
  store i32 %numValues, i32* %numValues.addr, align 4
  %0 = load i32* getelementptr inbounds (%struct.dim3* @blockDim, i32 0, i32 0), align 4
  %mul = mul i32 %0, 4
  %1 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @blockIdx to %struct.uint3*), i32 0, i32 0), align 4
  %call = call i32 @__umul24(i32 %mul, i32 %1)
  %2 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @threadIdx to %struct.uint3*), i32 0, i32 0), align 4
  %add = add i32 %call, %2
  store i32 %add, i32* %__cuda_local_var_23458_10_non_const_index, align 4
  %3 = load i32* %__cuda_local_var_23458_10_non_const_index, align 4
  %4 = load i32* %numValues.addr, align 4
  %cmp = icmp ult i32 %3, %4
  br i1 %cmp, label %if.then, label %if.end

if.then:                                          ; preds = %entry
  %5 = load i32* %__cuda_local_var_23458_10_non_const_index, align 4
  %idxprom = zext i32 %5 to i64
  %6 = load i32** %values.addr, align 8
  %arrayidx = getelementptr inbounds i32* %6, i64 %idxprom
  %7 = load i32* %arrayidx, align 4
  %call1 = call i32 @_Z9floatFlipILb1EEjj(i32 %7)
  %8 = load i32* %__cuda_local_var_23458_10_non_const_index, align 4
  %idxprom2 = zext i32 %8 to i64
  %9 = load i32** %values.addr, align 8
  %arrayidx3 = getelementptr inbounds i32* %9, i64 %idxprom2
  store i32 %call1, i32* %arrayidx3, align 4
  br label %if.end

if.end:                                           ; preds = %if.then, %entry
  %10 = load i32* getelementptr inbounds (%struct.dim3* @blockDim, i32 0, i32 0), align 4
  %11 = load i32* %__cuda_local_var_23458_10_non_const_index, align 4
  %add4 = add i32 %11, %10
  store i32 %add4, i32* %__cuda_local_var_23458_10_non_const_index, align 4
  %12 = load i32* %__cuda_local_var_23458_10_non_const_index, align 4
  %13 = load i32* %numValues.addr, align 4
  %cmp5 = icmp ult i32 %12, %13
  br i1 %cmp5, label %if.then6, label %if.end12

if.then6:                                         ; preds = %if.end
  %14 = load i32* %__cuda_local_var_23458_10_non_const_index, align 4
  %idxprom7 = zext i32 %14 to i64
  %15 = load i32** %values.addr, align 8
  %arrayidx8 = getelementptr inbounds i32* %15, i64 %idxprom7
  %16 = load i32* %arrayidx8, align 4
  %call9 = call i32 @_Z9floatFlipILb1EEjj(i32 %16)
  %17 = load i32* %__cuda_local_var_23458_10_non_const_index, align 4
  %idxprom10 = zext i32 %17 to i64
  %18 = load i32** %values.addr, align 8
  %arrayidx11 = getelementptr inbounds i32* %18, i64 %idxprom10
  store i32 %call9, i32* %arrayidx11, align 4
  br label %if.end12

if.end12:                                         ; preds = %if.then6, %if.end
  %19 = load i32* getelementptr inbounds (%struct.dim3* @blockDim, i32 0, i32 0), align 4
  %20 = load i32* %__cuda_local_var_23458_10_non_const_index, align 4
  %add13 = add i32 %20, %19
  store i32 %add13, i32* %__cuda_local_var_23458_10_non_const_index, align 4
  %21 = load i32* %__cuda_local_var_23458_10_non_const_index, align 4
  %22 = load i32* %numValues.addr, align 4
  %cmp14 = icmp ult i32 %21, %22
  br i1 %cmp14, label %if.then15, label %if.end21

if.then15:                                        ; preds = %if.end12
  %23 = load i32* %__cuda_local_var_23458_10_non_const_index, align 4
  %idxprom16 = zext i32 %23 to i64
  %24 = load i32** %values.addr, align 8
  %arrayidx17 = getelementptr inbounds i32* %24, i64 %idxprom16
  %25 = load i32* %arrayidx17, align 4
  %call18 = call i32 @_Z9floatFlipILb1EEjj(i32 %25)
  %26 = load i32* %__cuda_local_var_23458_10_non_const_index, align 4
  %idxprom19 = zext i32 %26 to i64
  %27 = load i32** %values.addr, align 8
  %arrayidx20 = getelementptr inbounds i32* %27, i64 %idxprom19
  store i32 %call18, i32* %arrayidx20, align 4
  br label %if.end21

if.end21:                                         ; preds = %if.then15, %if.end12
  %28 = load i32* getelementptr inbounds (%struct.dim3* @blockDim, i32 0, i32 0), align 4
  %29 = load i32* %__cuda_local_var_23458_10_non_const_index, align 4
  %add22 = add i32 %29, %28
  store i32 %add22, i32* %__cuda_local_var_23458_10_non_const_index, align 4
  %30 = load i32* %__cuda_local_var_23458_10_non_const_index, align 4
  %31 = load i32* %numValues.addr, align 4
  %cmp23 = icmp ult i32 %30, %31
  br i1 %cmp23, label %if.then24, label %if.end30

if.then24:                                        ; preds = %if.end21
  %32 = load i32* %__cuda_local_var_23458_10_non_const_index, align 4
  %idxprom25 = zext i32 %32 to i64
  %33 = load i32** %values.addr, align 8
  %arrayidx26 = getelementptr inbounds i32* %33, i64 %idxprom25
  %34 = load i32* %arrayidx26, align 4
  %call27 = call i32 @_Z9floatFlipILb1EEjj(i32 %34)
  %35 = load i32* %__cuda_local_var_23458_10_non_const_index, align 4
  %idxprom28 = zext i32 %35 to i64
  %36 = load i32** %values.addr, align 8
  %arrayidx29 = getelementptr inbounds i32* %36, i64 %idxprom28
  store i32 %call27, i32* %arrayidx29, align 4
  br label %if.end30

if.end30:                                         ; preds = %if.then24, %if.end21
  ret void
}

declare i32 @__umul24(i32, i32) section "__device__"

define void @_Z12unflipFloatsPjj(i32* %values, i32 %numValues) uwtable {
entry:
  %values.addr = alloca i32*, align 8
  %numValues.addr = alloca i32, align 4
  %__cuda_local_var_23474_10_non_const_index = alloca i32, align 4
  store i32* %values, i32** %values.addr, align 8
  store i32 %numValues, i32* %numValues.addr, align 4
  %0 = load i32* getelementptr inbounds (%struct.dim3* @blockDim, i32 0, i32 0), align 4
  %mul = mul i32 %0, 4
  %1 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @blockIdx to %struct.uint3*), i32 0, i32 0), align 4
  %call = call i32 @__umul24(i32 %mul, i32 %1)
  %2 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @threadIdx to %struct.uint3*), i32 0, i32 0), align 4
  %add = add i32 %call, %2
  store i32 %add, i32* %__cuda_local_var_23474_10_non_const_index, align 4
  %3 = load i32* %__cuda_local_var_23474_10_non_const_index, align 4
  %4 = load i32* %numValues.addr, align 4
  %cmp = icmp ult i32 %3, %4
  br i1 %cmp, label %if.then, label %if.end

if.then:                                          ; preds = %entry
  %5 = load i32* %__cuda_local_var_23474_10_non_const_index, align 4
  %idxprom = zext i32 %5 to i64
  %6 = load i32** %values.addr, align 8
  %arrayidx = getelementptr inbounds i32* %6, i64 %idxprom
  %7 = load i32* %arrayidx, align 4
  %call1 = call i32 @_Z11floatUnflipILb1EEjj(i32 %7)
  %8 = load i32* %__cuda_local_var_23474_10_non_const_index, align 4
  %idxprom2 = zext i32 %8 to i64
  %9 = load i32** %values.addr, align 8
  %arrayidx3 = getelementptr inbounds i32* %9, i64 %idxprom2
  store i32 %call1, i32* %arrayidx3, align 4
  br label %if.end

if.end:                                           ; preds = %if.then, %entry
  %10 = load i32* getelementptr inbounds (%struct.dim3* @blockDim, i32 0, i32 0), align 4
  %11 = load i32* %__cuda_local_var_23474_10_non_const_index, align 4
  %add4 = add i32 %11, %10
  store i32 %add4, i32* %__cuda_local_var_23474_10_non_const_index, align 4
  %12 = load i32* %__cuda_local_var_23474_10_non_const_index, align 4
  %13 = load i32* %numValues.addr, align 4
  %cmp5 = icmp ult i32 %12, %13
  br i1 %cmp5, label %if.then6, label %if.end12

if.then6:                                         ; preds = %if.end
  %14 = load i32* %__cuda_local_var_23474_10_non_const_index, align 4
  %idxprom7 = zext i32 %14 to i64
  %15 = load i32** %values.addr, align 8
  %arrayidx8 = getelementptr inbounds i32* %15, i64 %idxprom7
  %16 = load i32* %arrayidx8, align 4
  %call9 = call i32 @_Z11floatUnflipILb1EEjj(i32 %16)
  %17 = load i32* %__cuda_local_var_23474_10_non_const_index, align 4
  %idxprom10 = zext i32 %17 to i64
  %18 = load i32** %values.addr, align 8
  %arrayidx11 = getelementptr inbounds i32* %18, i64 %idxprom10
  store i32 %call9, i32* %arrayidx11, align 4
  br label %if.end12

if.end12:                                         ; preds = %if.then6, %if.end
  %19 = load i32* getelementptr inbounds (%struct.dim3* @blockDim, i32 0, i32 0), align 4
  %20 = load i32* %__cuda_local_var_23474_10_non_const_index, align 4
  %add13 = add i32 %20, %19
  store i32 %add13, i32* %__cuda_local_var_23474_10_non_const_index, align 4
  %21 = load i32* %__cuda_local_var_23474_10_non_const_index, align 4
  %22 = load i32* %numValues.addr, align 4
  %cmp14 = icmp ult i32 %21, %22
  br i1 %cmp14, label %if.then15, label %if.end21

if.then15:                                        ; preds = %if.end12
  %23 = load i32* %__cuda_local_var_23474_10_non_const_index, align 4
  %idxprom16 = zext i32 %23 to i64
  %24 = load i32** %values.addr, align 8
  %arrayidx17 = getelementptr inbounds i32* %24, i64 %idxprom16
  %25 = load i32* %arrayidx17, align 4
  %call18 = call i32 @_Z11floatUnflipILb1EEjj(i32 %25)
  %26 = load i32* %__cuda_local_var_23474_10_non_const_index, align 4
  %idxprom19 = zext i32 %26 to i64
  %27 = load i32** %values.addr, align 8
  %arrayidx20 = getelementptr inbounds i32* %27, i64 %idxprom19
  store i32 %call18, i32* %arrayidx20, align 4
  br label %if.end21

if.end21:                                         ; preds = %if.then15, %if.end12
  %28 = load i32* getelementptr inbounds (%struct.dim3* @blockDim, i32 0, i32 0), align 4
  %29 = load i32* %__cuda_local_var_23474_10_non_const_index, align 4
  %add22 = add i32 %29, %28
  store i32 %add22, i32* %__cuda_local_var_23474_10_non_const_index, align 4
  %30 = load i32* %__cuda_local_var_23474_10_non_const_index, align 4
  %31 = load i32* %numValues.addr, align 4
  %cmp23 = icmp ult i32 %30, %31
  br i1 %cmp23, label %if.then24, label %if.end30

if.then24:                                        ; preds = %if.end21
  %32 = load i32* %__cuda_local_var_23474_10_non_const_index, align 4
  %idxprom25 = zext i32 %32 to i64
  %33 = load i32** %values.addr, align 8
  %arrayidx26 = getelementptr inbounds i32* %33, i64 %idxprom25
  %34 = load i32* %arrayidx26, align 4
  %call27 = call i32 @_Z11floatUnflipILb1EEjj(i32 %34)
  %35 = load i32* %__cuda_local_var_23474_10_non_const_index, align 4
  %idxprom28 = zext i32 %35 to i64
  %36 = load i32** %values.addr, align 8
  %arrayidx29 = getelementptr inbounds i32* %36, i64 %idxprom28
  store i32 %call27, i32* %arrayidx29, align 4
  br label %if.end30

if.end30:                                         ; preds = %if.then24, %if.end21
  ret void
}

define void @_Z23radixSortBlocksKeysOnlyILj4ELj0ELb1ELb1ELb1EEvP5uint4S1_jj(%struct.uint4* %keysOut, %struct.uint4* %keysIn, i32 %numElements, i32 %totalBlocks) uwtable {
entry:
  %keysOut.addr = alloca %struct.uint4*, align 8
  %keysIn.addr = alloca %struct.uint4*, align 8
  %numElements.addr = alloca i32, align 4
  %totalBlocks.addr = alloca i32, align 4
  %__cuda_local_var_23728_11_non_const_key = alloca %struct.uint4, align 16
  %__cuda_local_var_23730_10_non_const_blockId = alloca i32, align 4
  %__T216 = alloca %struct.uint4, align 16
  %__cuda_local_var_23734_14_non_const_i = alloca i32, align 4
  %__cuda_local_var_23735_14_non_const_idx = alloca i32, align 4
  store %struct.uint4* %keysOut, %struct.uint4** %keysOut.addr, align 8
  store %struct.uint4* %keysIn, %struct.uint4** %keysIn.addr, align 8
  store i32 %numElements, i32* %numElements.addr, align 4
  store i32 %totalBlocks, i32* %totalBlocks.addr, align 4
  %0 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @blockIdx to %struct.uint3*), i32 0, i32 0), align 4
  store i32 %0, i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  br label %while.cond

while.cond:                                       ; preds = %while.body, %entry
  %1 = load i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  %2 = load i32* %totalBlocks.addr, align 4
  %cmp = icmp ult i32 %1, %2
  br i1 %cmp, label %while.body, label %while.end

while.body:                                       ; preds = %while.cond
  %3 = load i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  %4 = load i32* getelementptr inbounds (%struct.dim3* @blockDim, i32 0, i32 0), align 4
  %mul = mul i32 %3, %4
  %5 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @threadIdx to %struct.uint3*), i32 0, i32 0), align 4
  %add = add i32 %mul, %5
  store i32 %add, i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %6 = load i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %shl = shl i32 %6, 2
  store i32 %shl, i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %7 = load i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %idxprom = zext i32 %7 to i64
  %8 = load %struct.uint4** %keysIn.addr, align 8
  %arrayidx = getelementptr inbounds %struct.uint4* %8, i64 %idxprom
  %9 = bitcast %struct.uint4* %__cuda_local_var_23728_11_non_const_key to i8*
  %10 = bitcast %struct.uint4* %arrayidx to i8*
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* %9, i8* %10, i64 16, i32 16, i1 false)
  %x = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 0
  %11 = load i32* %x, align 4
  %call = call i32 @_Z9floatFlipILb1EEjj(i32 %11)
  %x1 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 0
  store i32 %call, i32* %x1, align 4
  %y = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 1
  %12 = load i32* %y, align 4
  %call2 = call i32 @_Z9floatFlipILb1EEjj(i32 %12)
  %y3 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 1
  store i32 %call2, i32* %y3, align 4
  %z = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 2
  %13 = load i32* %z, align 4
  %call4 = call i32 @_Z9floatFlipILb1EEjj(i32 %13)
  %z5 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 2
  store i32 %call4, i32* %z5, align 4
  %w = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 3
  %14 = load i32* %w, align 4
  %call6 = call i32 @_Z9floatFlipILb1EEjj(i32 %14)
  %w7 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 3
  store i32 %call6, i32* %w7, align 4
  call void @__syncthreads()
  call void @_Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4(%struct.uint4* %__cuda_local_var_23728_11_non_const_key)
  %15 = load i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %idxprom8 = zext i32 %15 to i64
  %16 = load %struct.uint4** %keysOut.addr, align 8
  %arrayidx9 = getelementptr inbounds %struct.uint4* %16, i64 %idxprom8
  %17 = bitcast %struct.uint4* %arrayidx9 to i8*
  %18 = bitcast %struct.uint4* %__cuda_local_var_23728_11_non_const_key to i8*
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* %17, i8* %18, i64 16, i32 16, i1 false)
  %19 = load i32* getelementptr inbounds (%struct.dim3* @gridDim, i32 0, i32 0), align 4
  %20 = load i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  %add10 = add i32 %20, %19
  store i32 %add10, i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  br label %while.cond

while.end:                                        ; preds = %while.cond
  br label %__T217

__T217:                                           ; preds = %while.end
  ret void
}

define void @_Z23radixSortBlocksKeysOnlyILj4ELj0ELb1ELb1ELb0EEvP5uint4S1_jj(%struct.uint4* %keysOut, %struct.uint4* %keysIn, i32 %numElements, i32 %totalBlocks) uwtable {
entry:
  %keysOut.addr = alloca %struct.uint4*, align 8
  %keysIn.addr = alloca %struct.uint4*, align 8
  %numElements.addr = alloca i32, align 4
  %totalBlocks.addr = alloca i32, align 4
  %__cuda_local_var_23728_11_non_const_key = alloca %struct.uint4, align 16
  %__cuda_local_var_23730_10_non_const_blockId = alloca i32, align 4
  %__T218 = alloca %struct.uint4, align 16
  %__cuda_local_var_23734_14_non_const_i = alloca i32, align 4
  %__cuda_local_var_23735_14_non_const_idx = alloca i32, align 4
  store %struct.uint4* %keysOut, %struct.uint4** %keysOut.addr, align 8
  store %struct.uint4* %keysIn, %struct.uint4** %keysIn.addr, align 8
  store i32 %numElements, i32* %numElements.addr, align 4
  store i32 %totalBlocks, i32* %totalBlocks.addr, align 4
  %0 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @blockIdx to %struct.uint3*), i32 0, i32 0), align 4
  store i32 %0, i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  br label %while.body

while.body:                                       ; preds = %entry
  %1 = load i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  %2 = load i32* getelementptr inbounds (%struct.dim3* @blockDim, i32 0, i32 0), align 4
  %mul = mul i32 %1, %2
  %3 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @threadIdx to %struct.uint3*), i32 0, i32 0), align 4
  %add = add i32 %mul, %3
  store i32 %add, i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %4 = load i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %shl = shl i32 %4, 2
  store i32 %shl, i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %5 = load i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %idxprom = zext i32 %5 to i64
  %6 = load %struct.uint4** %keysIn.addr, align 8
  %arrayidx = getelementptr inbounds %struct.uint4* %6, i64 %idxprom
  %7 = bitcast %struct.uint4* %__cuda_local_var_23728_11_non_const_key to i8*
  %8 = bitcast %struct.uint4* %arrayidx to i8*
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* %7, i8* %8, i64 16, i32 16, i1 false)
  %x = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 0
  %9 = load i32* %x, align 4
  %call = call i32 @_Z9floatFlipILb1EEjj(i32 %9)
  %x1 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 0
  store i32 %call, i32* %x1, align 4
  %y = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 1
  %10 = load i32* %y, align 4
  %call2 = call i32 @_Z9floatFlipILb1EEjj(i32 %10)
  %y3 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 1
  store i32 %call2, i32* %y3, align 4
  %z = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 2
  %11 = load i32* %z, align 4
  %call4 = call i32 @_Z9floatFlipILb1EEjj(i32 %11)
  %z5 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 2
  store i32 %call4, i32* %z5, align 4
  %w = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 3
  %12 = load i32* %w, align 4
  %call6 = call i32 @_Z9floatFlipILb1EEjj(i32 %12)
  %w7 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 3
  store i32 %call6, i32* %w7, align 4
  call void @__syncthreads()
  call void @_Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4(%struct.uint4* %__cuda_local_var_23728_11_non_const_key)
  %13 = load i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %idxprom8 = zext i32 %13 to i64
  %14 = load %struct.uint4** %keysOut.addr, align 8
  %arrayidx9 = getelementptr inbounds %struct.uint4* %14, i64 %idxprom8
  %15 = bitcast %struct.uint4* %arrayidx9 to i8*
  %16 = bitcast %struct.uint4* %__cuda_local_var_23728_11_non_const_key to i8*
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* %15, i8* %16, i64 16, i32 16, i1 false)
  br label %__T219

__T219:                                           ; preds = %while.body
  ret void
}

define void @_Z23radixSortBlocksKeysOnlyILj4ELj0ELb0ELb1ELb1EEvP5uint4S1_jj(%struct.uint4* %keysOut, %struct.uint4* %keysIn, i32 %numElements, i32 %totalBlocks) uwtable {
entry:
  %keysOut.addr = alloca %struct.uint4*, align 8
  %keysIn.addr = alloca %struct.uint4*, align 8
  %numElements.addr = alloca i32, align 4
  %totalBlocks.addr = alloca i32, align 4
  %__cuda_local_var_23728_11_non_const_key = alloca %struct.uint4, align 16
  %__cuda_local_var_23730_10_non_const_blockId = alloca i32, align 4
  %__T220 = alloca %struct.uint4, align 16
  %__cuda_local_var_23734_14_non_const_i = alloca i32, align 4
  %__cuda_local_var_23735_14_non_const_idx = alloca i32, align 4
  %__cuda_local_var_23747_23_non_const_keys1 = alloca i32*, align 8
  %__cuda_local_var_23776_23_non_const_keys1 = alloca i32*, align 8
  store %struct.uint4* %keysOut, %struct.uint4** %keysOut.addr, align 8
  store %struct.uint4* %keysIn, %struct.uint4** %keysIn.addr, align 8
  store i32 %numElements, i32* %numElements.addr, align 4
  store i32 %totalBlocks, i32* %totalBlocks.addr, align 4
  %0 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @blockIdx to %struct.uint3*), i32 0, i32 0), align 4
  store i32 %0, i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  br label %while.cond

while.cond:                                       ; preds = %if.end74, %entry
  %1 = load i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  %2 = load i32* %totalBlocks.addr, align 4
  %cmp = icmp ult i32 %1, %2
  br i1 %cmp, label %while.body, label %while.end

while.body:                                       ; preds = %while.cond
  %3 = load i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  %4 = load i32* getelementptr inbounds (%struct.dim3* @blockDim, i32 0, i32 0), align 4
  %mul = mul i32 %3, %4
  %5 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @threadIdx to %struct.uint3*), i32 0, i32 0), align 4
  %add = add i32 %mul, %5
  store i32 %add, i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %6 = load i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %shl = shl i32 %6, 2
  store i32 %shl, i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %7 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add1 = add i32 %7, 3
  %8 = load i32* %numElements.addr, align 4
  %cmp2 = icmp uge i32 %add1, %8
  br i1 %cmp2, label %if.then, label %if.else30

if.then:                                          ; preds = %while.body
  %9 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %10 = load i32* %numElements.addr, align 4
  %cmp3 = icmp uge i32 %9, %10
  br i1 %cmp3, label %if.then4, label %if.else

if.then4:                                         ; preds = %if.then
  %x = getelementptr inbounds %struct.uint4* %__T220, i32 0, i32 0
  store i32 -1, i32* %x, align 4
  %y = getelementptr inbounds %struct.uint4* %__T220, i32 0, i32 1
  store i32 -1, i32* %y, align 4
  %z = getelementptr inbounds %struct.uint4* %__T220, i32 0, i32 2
  store i32 -1, i32* %z, align 4
  %w = getelementptr inbounds %struct.uint4* %__T220, i32 0, i32 3
  store i32 -1, i32* %w, align 4
  %11 = bitcast %struct.uint4* %__cuda_local_var_23728_11_non_const_key to i8*
  %12 = bitcast %struct.uint4* %__T220 to i8*
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* %11, i8* %12, i64 16, i32 16, i1 false)
  br label %if.end

if.else:                                          ; preds = %if.then
  %13 = load %struct.uint4** %keysIn.addr, align 8
  %14 = bitcast %struct.uint4* %13 to i32*
  store i32* %14, i32** %__cuda_local_var_23747_23_non_const_keys1, align 8
  %15 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %16 = load i32* %numElements.addr, align 4
  %cmp5 = icmp ult i32 %15, %16
  br i1 %cmp5, label %cond.true, label %cond.false

cond.true:                                        ; preds = %if.else
  %17 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %idxprom = zext i32 %17 to i64
  %18 = load i32** %__cuda_local_var_23747_23_non_const_keys1, align 8
  %arrayidx = getelementptr inbounds i32* %18, i64 %idxprom
  %19 = load i32* %arrayidx, align 4
  %call = call i32 @_Z9floatFlipILb1EEjj(i32 %19)
  br label %cond.end

cond.false:                                       ; preds = %if.else
  br label %cond.end

cond.end:                                         ; preds = %cond.false, %cond.true
  %cond = phi i32 [ %call, %cond.true ], [ -1, %cond.false ]
  %x6 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 0
  store i32 %cond, i32* %x6, align 4
  %20 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add7 = add i32 %20, 1
  %21 = load i32* %numElements.addr, align 4
  %cmp8 = icmp ult i32 %add7, %21
  br i1 %cmp8, label %cond.true9, label %cond.false14

cond.true9:                                       ; preds = %cond.end
  %22 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add10 = add i32 %22, 1
  %idxprom11 = zext i32 %add10 to i64
  %23 = load i32** %__cuda_local_var_23747_23_non_const_keys1, align 8
  %arrayidx12 = getelementptr inbounds i32* %23, i64 %idxprom11
  %24 = load i32* %arrayidx12, align 4
  %call13 = call i32 @_Z9floatFlipILb1EEjj(i32 %24)
  br label %cond.end15

cond.false14:                                     ; preds = %cond.end
  br label %cond.end15

cond.end15:                                       ; preds = %cond.false14, %cond.true9
  %cond16 = phi i32 [ %call13, %cond.true9 ], [ -1, %cond.false14 ]
  %y17 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 1
  store i32 %cond16, i32* %y17, align 4
  %25 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add18 = add i32 %25, 2
  %26 = load i32* %numElements.addr, align 4
  %cmp19 = icmp ult i32 %add18, %26
  br i1 %cmp19, label %cond.true20, label %cond.false25

cond.true20:                                      ; preds = %cond.end15
  %27 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add21 = add i32 %27, 2
  %idxprom22 = zext i32 %add21 to i64
  %28 = load i32** %__cuda_local_var_23747_23_non_const_keys1, align 8
  %arrayidx23 = getelementptr inbounds i32* %28, i64 %idxprom22
  %29 = load i32* %arrayidx23, align 4
  %call24 = call i32 @_Z9floatFlipILb1EEjj(i32 %29)
  br label %cond.end26

cond.false25:                                     ; preds = %cond.end15
  br label %cond.end26

cond.end26:                                       ; preds = %cond.false25, %cond.true20
  %cond27 = phi i32 [ %call24, %cond.true20 ], [ -1, %cond.false25 ]
  %z28 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 2
  store i32 %cond27, i32* %z28, align 4
  %w29 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 3
  store i32 -1, i32* %w29, align 4
  br label %if.end

if.end:                                           ; preds = %cond.end26, %if.then4
  br label %if.end45

if.else30:                                        ; preds = %while.body
  %30 = load i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %idxprom31 = zext i32 %30 to i64
  %31 = load %struct.uint4** %keysIn.addr, align 8
  %arrayidx32 = getelementptr inbounds %struct.uint4* %31, i64 %idxprom31
  %32 = bitcast %struct.uint4* %__cuda_local_var_23728_11_non_const_key to i8*
  %33 = bitcast %struct.uint4* %arrayidx32 to i8*
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* %32, i8* %33, i64 16, i32 16, i1 false)
  %x33 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 0
  %34 = load i32* %x33, align 4
  %call34 = call i32 @_Z9floatFlipILb1EEjj(i32 %34)
  %x35 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 0
  store i32 %call34, i32* %x35, align 4
  %y36 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 1
  %35 = load i32* %y36, align 4
  %call37 = call i32 @_Z9floatFlipILb1EEjj(i32 %35)
  %y38 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 1
  store i32 %call37, i32* %y38, align 4
  %z39 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 2
  %36 = load i32* %z39, align 4
  %call40 = call i32 @_Z9floatFlipILb1EEjj(i32 %36)
  %z41 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 2
  store i32 %call40, i32* %z41, align 4
  %w42 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 3
  %37 = load i32* %w42, align 4
  %call43 = call i32 @_Z9floatFlipILb1EEjj(i32 %37)
  %w44 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 3
  store i32 %call43, i32* %w44, align 4
  br label %if.end45

if.end45:                                         ; preds = %if.else30, %if.end
  call void @__syncthreads()
  call void @_Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4(%struct.uint4* %__cuda_local_var_23728_11_non_const_key)
  %38 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add46 = add i32 %38, 3
  %39 = load i32* %numElements.addr, align 4
  %cmp47 = icmp uge i32 %add46, %39
  br i1 %cmp47, label %if.then48, label %if.else71

if.then48:                                        ; preds = %if.end45
  %40 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %41 = load i32* %numElements.addr, align 4
  %cmp49 = icmp ult i32 %40, %41
  br i1 %cmp49, label %if.then50, label %if.end70

if.then50:                                        ; preds = %if.then48
  %42 = load %struct.uint4** %keysOut.addr, align 8
  %43 = bitcast %struct.uint4* %42 to i32*
  store i32* %43, i32** %__cuda_local_var_23776_23_non_const_keys1, align 8
  %x51 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 0
  %44 = load i32* %x51, align 4
  %45 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %idxprom52 = zext i32 %45 to i64
  %46 = load i32** %__cuda_local_var_23776_23_non_const_keys1, align 8
  %arrayidx53 = getelementptr inbounds i32* %46, i64 %idxprom52
  store i32 %44, i32* %arrayidx53, align 4
  %47 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add54 = add i32 %47, 1
  %48 = load i32* %numElements.addr, align 4
  %cmp55 = icmp ult i32 %add54, %48
  br i1 %cmp55, label %if.then56, label %if.end69

if.then56:                                        ; preds = %if.then50
  %y57 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 1
  %49 = load i32* %y57, align 4
  %50 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add58 = add i32 %50, 1
  %idxprom59 = zext i32 %add58 to i64
  %51 = load i32** %__cuda_local_var_23776_23_non_const_keys1, align 8
  %arrayidx60 = getelementptr inbounds i32* %51, i64 %idxprom59
  store i32 %49, i32* %arrayidx60, align 4
  %52 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add61 = add i32 %52, 2
  %53 = load i32* %numElements.addr, align 4
  %cmp62 = icmp ult i32 %add61, %53
  br i1 %cmp62, label %if.then63, label %if.end68

if.then63:                                        ; preds = %if.then56
  %z64 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 2
  %54 = load i32* %z64, align 4
  %55 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add65 = add i32 %55, 2
  %idxprom66 = zext i32 %add65 to i64
  %56 = load i32** %__cuda_local_var_23776_23_non_const_keys1, align 8
  %arrayidx67 = getelementptr inbounds i32* %56, i64 %idxprom66
  store i32 %54, i32* %arrayidx67, align 4
  br label %if.end68

if.end68:                                         ; preds = %if.then63, %if.then56
  br label %if.end69

if.end69:                                         ; preds = %if.end68, %if.then50
  br label %if.end70

if.end70:                                         ; preds = %if.end69, %if.then48
  br label %if.end74

if.else71:                                        ; preds = %if.end45
  %57 = load i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %idxprom72 = zext i32 %57 to i64
  %58 = load %struct.uint4** %keysOut.addr, align 8
  %arrayidx73 = getelementptr inbounds %struct.uint4* %58, i64 %idxprom72
  %59 = bitcast %struct.uint4* %arrayidx73 to i8*
  %60 = bitcast %struct.uint4* %__cuda_local_var_23728_11_non_const_key to i8*
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* %59, i8* %60, i64 16, i32 16, i1 false)
  br label %if.end74

if.end74:                                         ; preds = %if.else71, %if.end70
  %61 = load i32* getelementptr inbounds (%struct.dim3* @gridDim, i32 0, i32 0), align 4
  %62 = load i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  %add75 = add i32 %62, %61
  store i32 %add75, i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  br label %while.cond

while.end:                                        ; preds = %while.cond
  br label %__T221

__T221:                                           ; preds = %while.end
  ret void
}

define void @_Z23radixSortBlocksKeysOnlyILj4ELj0ELb0ELb1ELb0EEvP5uint4S1_jj(%struct.uint4* %keysOut, %struct.uint4* %keysIn, i32 %numElements, i32 %totalBlocks) uwtable {
entry:
  %keysOut.addr = alloca %struct.uint4*, align 8
  %keysIn.addr = alloca %struct.uint4*, align 8
  %numElements.addr = alloca i32, align 4
  %totalBlocks.addr = alloca i32, align 4
  %__cuda_local_var_23728_11_non_const_key = alloca %struct.uint4, align 16
  %__cuda_local_var_23730_10_non_const_blockId = alloca i32, align 4
  %__T222 = alloca %struct.uint4, align 16
  %__cuda_local_var_23734_14_non_const_i = alloca i32, align 4
  %__cuda_local_var_23735_14_non_const_idx = alloca i32, align 4
  %__cuda_local_var_23747_23_non_const_keys1 = alloca i32*, align 8
  %__cuda_local_var_23776_23_non_const_keys1 = alloca i32*, align 8
  store %struct.uint4* %keysOut, %struct.uint4** %keysOut.addr, align 8
  store %struct.uint4* %keysIn, %struct.uint4** %keysIn.addr, align 8
  store i32 %numElements, i32* %numElements.addr, align 4
  store i32 %totalBlocks, i32* %totalBlocks.addr, align 4
  %0 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @blockIdx to %struct.uint3*), i32 0, i32 0), align 4
  store i32 %0, i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  br label %while.body

while.body:                                       ; preds = %entry
  %1 = load i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  %2 = load i32* getelementptr inbounds (%struct.dim3* @blockDim, i32 0, i32 0), align 4
  %mul = mul i32 %1, %2
  %3 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @threadIdx to %struct.uint3*), i32 0, i32 0), align 4
  %add = add i32 %mul, %3
  store i32 %add, i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %4 = load i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %shl = shl i32 %4, 2
  store i32 %shl, i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %5 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add1 = add i32 %5, 3
  %6 = load i32* %numElements.addr, align 4
  %cmp = icmp uge i32 %add1, %6
  br i1 %cmp, label %if.then, label %if.else29

if.then:                                          ; preds = %while.body
  %7 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %8 = load i32* %numElements.addr, align 4
  %cmp2 = icmp uge i32 %7, %8
  br i1 %cmp2, label %if.then3, label %if.else

if.then3:                                         ; preds = %if.then
  %x = getelementptr inbounds %struct.uint4* %__T222, i32 0, i32 0
  store i32 -1, i32* %x, align 4
  %y = getelementptr inbounds %struct.uint4* %__T222, i32 0, i32 1
  store i32 -1, i32* %y, align 4
  %z = getelementptr inbounds %struct.uint4* %__T222, i32 0, i32 2
  store i32 -1, i32* %z, align 4
  %w = getelementptr inbounds %struct.uint4* %__T222, i32 0, i32 3
  store i32 -1, i32* %w, align 4
  %9 = bitcast %struct.uint4* %__cuda_local_var_23728_11_non_const_key to i8*
  %10 = bitcast %struct.uint4* %__T222 to i8*
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* %9, i8* %10, i64 16, i32 16, i1 false)
  br label %if.end

if.else:                                          ; preds = %if.then
  %11 = load %struct.uint4** %keysIn.addr, align 8
  %12 = bitcast %struct.uint4* %11 to i32*
  store i32* %12, i32** %__cuda_local_var_23747_23_non_const_keys1, align 8
  %13 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %14 = load i32* %numElements.addr, align 4
  %cmp4 = icmp ult i32 %13, %14
  br i1 %cmp4, label %cond.true, label %cond.false

cond.true:                                        ; preds = %if.else
  %15 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %idxprom = zext i32 %15 to i64
  %16 = load i32** %__cuda_local_var_23747_23_non_const_keys1, align 8
  %arrayidx = getelementptr inbounds i32* %16, i64 %idxprom
  %17 = load i32* %arrayidx, align 4
  %call = call i32 @_Z9floatFlipILb1EEjj(i32 %17)
  br label %cond.end

cond.false:                                       ; preds = %if.else
  br label %cond.end

cond.end:                                         ; preds = %cond.false, %cond.true
  %cond = phi i32 [ %call, %cond.true ], [ -1, %cond.false ]
  %x5 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 0
  store i32 %cond, i32* %x5, align 4
  %18 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add6 = add i32 %18, 1
  %19 = load i32* %numElements.addr, align 4
  %cmp7 = icmp ult i32 %add6, %19
  br i1 %cmp7, label %cond.true8, label %cond.false13

cond.true8:                                       ; preds = %cond.end
  %20 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add9 = add i32 %20, 1
  %idxprom10 = zext i32 %add9 to i64
  %21 = load i32** %__cuda_local_var_23747_23_non_const_keys1, align 8
  %arrayidx11 = getelementptr inbounds i32* %21, i64 %idxprom10
  %22 = load i32* %arrayidx11, align 4
  %call12 = call i32 @_Z9floatFlipILb1EEjj(i32 %22)
  br label %cond.end14

cond.false13:                                     ; preds = %cond.end
  br label %cond.end14

cond.end14:                                       ; preds = %cond.false13, %cond.true8
  %cond15 = phi i32 [ %call12, %cond.true8 ], [ -1, %cond.false13 ]
  %y16 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 1
  store i32 %cond15, i32* %y16, align 4
  %23 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add17 = add i32 %23, 2
  %24 = load i32* %numElements.addr, align 4
  %cmp18 = icmp ult i32 %add17, %24
  br i1 %cmp18, label %cond.true19, label %cond.false24

cond.true19:                                      ; preds = %cond.end14
  %25 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add20 = add i32 %25, 2
  %idxprom21 = zext i32 %add20 to i64
  %26 = load i32** %__cuda_local_var_23747_23_non_const_keys1, align 8
  %arrayidx22 = getelementptr inbounds i32* %26, i64 %idxprom21
  %27 = load i32* %arrayidx22, align 4
  %call23 = call i32 @_Z9floatFlipILb1EEjj(i32 %27)
  br label %cond.end25

cond.false24:                                     ; preds = %cond.end14
  br label %cond.end25

cond.end25:                                       ; preds = %cond.false24, %cond.true19
  %cond26 = phi i32 [ %call23, %cond.true19 ], [ -1, %cond.false24 ]
  %z27 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 2
  store i32 %cond26, i32* %z27, align 4
  %w28 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 3
  store i32 -1, i32* %w28, align 4
  br label %if.end

if.end:                                           ; preds = %cond.end25, %if.then3
  br label %if.end44

if.else29:                                        ; preds = %while.body
  %28 = load i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %idxprom30 = zext i32 %28 to i64
  %29 = load %struct.uint4** %keysIn.addr, align 8
  %arrayidx31 = getelementptr inbounds %struct.uint4* %29, i64 %idxprom30
  %30 = bitcast %struct.uint4* %__cuda_local_var_23728_11_non_const_key to i8*
  %31 = bitcast %struct.uint4* %arrayidx31 to i8*
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* %30, i8* %31, i64 16, i32 16, i1 false)
  %x32 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 0
  %32 = load i32* %x32, align 4
  %call33 = call i32 @_Z9floatFlipILb1EEjj(i32 %32)
  %x34 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 0
  store i32 %call33, i32* %x34, align 4
  %y35 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 1
  %33 = load i32* %y35, align 4
  %call36 = call i32 @_Z9floatFlipILb1EEjj(i32 %33)
  %y37 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 1
  store i32 %call36, i32* %y37, align 4
  %z38 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 2
  %34 = load i32* %z38, align 4
  %call39 = call i32 @_Z9floatFlipILb1EEjj(i32 %34)
  %z40 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 2
  store i32 %call39, i32* %z40, align 4
  %w41 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 3
  %35 = load i32* %w41, align 4
  %call42 = call i32 @_Z9floatFlipILb1EEjj(i32 %35)
  %w43 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 3
  store i32 %call42, i32* %w43, align 4
  br label %if.end44

if.end44:                                         ; preds = %if.else29, %if.end
  call void @__syncthreads()
  call void @_Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4(%struct.uint4* %__cuda_local_var_23728_11_non_const_key)
  %36 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add45 = add i32 %36, 3
  %37 = load i32* %numElements.addr, align 4
  %cmp46 = icmp uge i32 %add45, %37
  br i1 %cmp46, label %if.then47, label %if.else70

if.then47:                                        ; preds = %if.end44
  %38 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %39 = load i32* %numElements.addr, align 4
  %cmp48 = icmp ult i32 %38, %39
  br i1 %cmp48, label %if.then49, label %if.end69

if.then49:                                        ; preds = %if.then47
  %40 = load %struct.uint4** %keysOut.addr, align 8
  %41 = bitcast %struct.uint4* %40 to i32*
  store i32* %41, i32** %__cuda_local_var_23776_23_non_const_keys1, align 8
  %x50 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 0
  %42 = load i32* %x50, align 4
  %43 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %idxprom51 = zext i32 %43 to i64
  %44 = load i32** %__cuda_local_var_23776_23_non_const_keys1, align 8
  %arrayidx52 = getelementptr inbounds i32* %44, i64 %idxprom51
  store i32 %42, i32* %arrayidx52, align 4
  %45 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add53 = add i32 %45, 1
  %46 = load i32* %numElements.addr, align 4
  %cmp54 = icmp ult i32 %add53, %46
  br i1 %cmp54, label %if.then55, label %if.end68

if.then55:                                        ; preds = %if.then49
  %y56 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 1
  %47 = load i32* %y56, align 4
  %48 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add57 = add i32 %48, 1
  %idxprom58 = zext i32 %add57 to i64
  %49 = load i32** %__cuda_local_var_23776_23_non_const_keys1, align 8
  %arrayidx59 = getelementptr inbounds i32* %49, i64 %idxprom58
  store i32 %47, i32* %arrayidx59, align 4
  %50 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add60 = add i32 %50, 2
  %51 = load i32* %numElements.addr, align 4
  %cmp61 = icmp ult i32 %add60, %51
  br i1 %cmp61, label %if.then62, label %if.end67

if.then62:                                        ; preds = %if.then55
  %z63 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 2
  %52 = load i32* %z63, align 4
  %53 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add64 = add i32 %53, 2
  %idxprom65 = zext i32 %add64 to i64
  %54 = load i32** %__cuda_local_var_23776_23_non_const_keys1, align 8
  %arrayidx66 = getelementptr inbounds i32* %54, i64 %idxprom65
  store i32 %52, i32* %arrayidx66, align 4
  br label %if.end67

if.end67:                                         ; preds = %if.then62, %if.then55
  br label %if.end68

if.end68:                                         ; preds = %if.end67, %if.then49
  br label %if.end69

if.end69:                                         ; preds = %if.end68, %if.then47
  br label %if.end73

if.else70:                                        ; preds = %if.end44
  %55 = load i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %idxprom71 = zext i32 %55 to i64
  %56 = load %struct.uint4** %keysOut.addr, align 8
  %arrayidx72 = getelementptr inbounds %struct.uint4* %56, i64 %idxprom71
  %57 = bitcast %struct.uint4* %arrayidx72 to i8*
  %58 = bitcast %struct.uint4* %__cuda_local_var_23728_11_non_const_key to i8*
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* %57, i8* %58, i64 16, i32 16, i1 false)
  br label %if.end73

if.end73:                                         ; preds = %if.else70, %if.end69
  br label %__T223

__T223:                                           ; preds = %if.end73
  ret void
}

define void @_Z23radixSortBlocksKeysOnlyILj4ELj0ELb1ELb0ELb1EEvP5uint4S1_jj(%struct.uint4* %keysOut, %struct.uint4* %keysIn, i32 %numElements, i32 %totalBlocks) uwtable {
entry:
  %keysOut.addr = alloca %struct.uint4*, align 8
  %keysIn.addr = alloca %struct.uint4*, align 8
  %numElements.addr = alloca i32, align 4
  %totalBlocks.addr = alloca i32, align 4
  %__cuda_local_var_23728_11_non_const_key = alloca %struct.uint4, align 16
  %__cuda_local_var_23730_10_non_const_blockId = alloca i32, align 4
  %__T224 = alloca %struct.uint4, align 16
  %__cuda_local_var_23734_14_non_const_i = alloca i32, align 4
  %__cuda_local_var_23735_14_non_const_idx = alloca i32, align 4
  store %struct.uint4* %keysOut, %struct.uint4** %keysOut.addr, align 8
  store %struct.uint4* %keysIn, %struct.uint4** %keysIn.addr, align 8
  store i32 %numElements, i32* %numElements.addr, align 4
  store i32 %totalBlocks, i32* %totalBlocks.addr, align 4
  %0 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @blockIdx to %struct.uint3*), i32 0, i32 0), align 4
  store i32 %0, i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  br label %while.cond

while.cond:                                       ; preds = %while.body, %entry
  %1 = load i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  %2 = load i32* %totalBlocks.addr, align 4
  %cmp = icmp ult i32 %1, %2
  br i1 %cmp, label %while.body, label %while.end

while.body:                                       ; preds = %while.cond
  %3 = load i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  %4 = load i32* getelementptr inbounds (%struct.dim3* @blockDim, i32 0, i32 0), align 4
  %mul = mul i32 %3, %4
  %5 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @threadIdx to %struct.uint3*), i32 0, i32 0), align 4
  %add = add i32 %mul, %5
  store i32 %add, i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %6 = load i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %shl = shl i32 %6, 2
  store i32 %shl, i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %7 = load i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %idxprom = zext i32 %7 to i64
  %8 = load %struct.uint4** %keysIn.addr, align 8
  %arrayidx = getelementptr inbounds %struct.uint4* %8, i64 %idxprom
  %9 = bitcast %struct.uint4* %__cuda_local_var_23728_11_non_const_key to i8*
  %10 = bitcast %struct.uint4* %arrayidx to i8*
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* %9, i8* %10, i64 16, i32 16, i1 false)
  call void @__syncthreads()
  call void @_Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4(%struct.uint4* %__cuda_local_var_23728_11_non_const_key)
  %11 = load i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %idxprom1 = zext i32 %11 to i64
  %12 = load %struct.uint4** %keysOut.addr, align 8
  %arrayidx2 = getelementptr inbounds %struct.uint4* %12, i64 %idxprom1
  %13 = bitcast %struct.uint4* %arrayidx2 to i8*
  %14 = bitcast %struct.uint4* %__cuda_local_var_23728_11_non_const_key to i8*
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* %13, i8* %14, i64 16, i32 16, i1 false)
  %15 = load i32* getelementptr inbounds (%struct.dim3* @gridDim, i32 0, i32 0), align 4
  %16 = load i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  %add3 = add i32 %16, %15
  store i32 %add3, i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  br label %while.cond

while.end:                                        ; preds = %while.cond
  br label %__T225

__T225:                                           ; preds = %while.end
  ret void
}

define void @_Z23radixSortBlocksKeysOnlyILj4ELj0ELb1ELb0ELb0EEvP5uint4S1_jj(%struct.uint4* %keysOut, %struct.uint4* %keysIn, i32 %numElements, i32 %totalBlocks) uwtable {
entry:
  %keysOut.addr = alloca %struct.uint4*, align 8
  %keysIn.addr = alloca %struct.uint4*, align 8
  %numElements.addr = alloca i32, align 4
  %totalBlocks.addr = alloca i32, align 4
  %__cuda_local_var_23728_11_non_const_key = alloca %struct.uint4, align 16
  %__cuda_local_var_23730_10_non_const_blockId = alloca i32, align 4
  %__T226 = alloca %struct.uint4, align 16
  %__cuda_local_var_23734_14_non_const_i = alloca i32, align 4
  %__cuda_local_var_23735_14_non_const_idx = alloca i32, align 4
  store %struct.uint4* %keysOut, %struct.uint4** %keysOut.addr, align 8
  store %struct.uint4* %keysIn, %struct.uint4** %keysIn.addr, align 8
  store i32 %numElements, i32* %numElements.addr, align 4
  store i32 %totalBlocks, i32* %totalBlocks.addr, align 4
  %0 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @blockIdx to %struct.uint3*), i32 0, i32 0), align 4
  store i32 %0, i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  br label %while.body

while.body:                                       ; preds = %entry
  %1 = load i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  %2 = load i32* getelementptr inbounds (%struct.dim3* @blockDim, i32 0, i32 0), align 4
  %mul = mul i32 %1, %2
  %3 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @threadIdx to %struct.uint3*), i32 0, i32 0), align 4
  %add = add i32 %mul, %3
  store i32 %add, i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %4 = load i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %shl = shl i32 %4, 2
  store i32 %shl, i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %5 = load i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %idxprom = zext i32 %5 to i64
  %6 = load %struct.uint4** %keysIn.addr, align 8
  %arrayidx = getelementptr inbounds %struct.uint4* %6, i64 %idxprom
  %7 = bitcast %struct.uint4* %__cuda_local_var_23728_11_non_const_key to i8*
  %8 = bitcast %struct.uint4* %arrayidx to i8*
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* %7, i8* %8, i64 16, i32 16, i1 false)
  call void @__syncthreads()
  call void @_Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4(%struct.uint4* %__cuda_local_var_23728_11_non_const_key)
  %9 = load i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %idxprom1 = zext i32 %9 to i64
  %10 = load %struct.uint4** %keysOut.addr, align 8
  %arrayidx2 = getelementptr inbounds %struct.uint4* %10, i64 %idxprom1
  %11 = bitcast %struct.uint4* %arrayidx2 to i8*
  %12 = bitcast %struct.uint4* %__cuda_local_var_23728_11_non_const_key to i8*
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* %11, i8* %12, i64 16, i32 16, i1 false)
  br label %__T227

__T227:                                           ; preds = %while.body
  ret void
}

define void @_Z23radixSortBlocksKeysOnlyILj4ELj0ELb0ELb0ELb1EEvP5uint4S1_jj(%struct.uint4* %keysOut, %struct.uint4* %keysIn, i32 %numElements, i32 %totalBlocks) uwtable {
entry:
  %keysOut.addr = alloca %struct.uint4*, align 8
  %keysIn.addr = alloca %struct.uint4*, align 8
  %numElements.addr = alloca i32, align 4
  %totalBlocks.addr = alloca i32, align 4
  %__cuda_local_var_23728_11_non_const_key = alloca %struct.uint4, align 16
  %__cuda_local_var_23730_10_non_const_blockId = alloca i32, align 4
  %__T228 = alloca %struct.uint4, align 16
  %__cuda_local_var_23734_14_non_const_i = alloca i32, align 4
  %__cuda_local_var_23735_14_non_const_idx = alloca i32, align 4
  %__cuda_local_var_23747_23_non_const_keys1 = alloca i32*, align 8
  %__cuda_local_var_23776_23_non_const_keys1 = alloca i32*, align 8
  store %struct.uint4* %keysOut, %struct.uint4** %keysOut.addr, align 8
  store %struct.uint4* %keysIn, %struct.uint4** %keysIn.addr, align 8
  store i32 %numElements, i32* %numElements.addr, align 4
  store i32 %totalBlocks, i32* %totalBlocks.addr, align 4
  %0 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @blockIdx to %struct.uint3*), i32 0, i32 0), align 4
  store i32 %0, i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  br label %while.cond

while.cond:                                       ; preds = %if.end62, %entry
  %1 = load i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  %2 = load i32* %totalBlocks.addr, align 4
  %cmp = icmp ult i32 %1, %2
  br i1 %cmp, label %while.body, label %while.end

while.body:                                       ; preds = %while.cond
  %3 = load i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  %4 = load i32* getelementptr inbounds (%struct.dim3* @blockDim, i32 0, i32 0), align 4
  %mul = mul i32 %3, %4
  %5 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @threadIdx to %struct.uint3*), i32 0, i32 0), align 4
  %add = add i32 %mul, %5
  store i32 %add, i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %6 = load i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %shl = shl i32 %6, 2
  store i32 %shl, i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %7 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add1 = add i32 %7, 3
  %8 = load i32* %numElements.addr, align 4
  %cmp2 = icmp uge i32 %add1, %8
  br i1 %cmp2, label %if.then, label %if.else30

if.then:                                          ; preds = %while.body
  %9 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %10 = load i32* %numElements.addr, align 4
  %cmp3 = icmp uge i32 %9, %10
  br i1 %cmp3, label %if.then4, label %if.else

if.then4:                                         ; preds = %if.then
  %x = getelementptr inbounds %struct.uint4* %__T228, i32 0, i32 0
  store i32 -1, i32* %x, align 4
  %y = getelementptr inbounds %struct.uint4* %__T228, i32 0, i32 1
  store i32 -1, i32* %y, align 4
  %z = getelementptr inbounds %struct.uint4* %__T228, i32 0, i32 2
  store i32 -1, i32* %z, align 4
  %w = getelementptr inbounds %struct.uint4* %__T228, i32 0, i32 3
  store i32 -1, i32* %w, align 4
  %11 = bitcast %struct.uint4* %__cuda_local_var_23728_11_non_const_key to i8*
  %12 = bitcast %struct.uint4* %__T228 to i8*
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* %11, i8* %12, i64 16, i32 16, i1 false)
  br label %if.end

if.else:                                          ; preds = %if.then
  %13 = load %struct.uint4** %keysIn.addr, align 8
  %14 = bitcast %struct.uint4* %13 to i32*
  store i32* %14, i32** %__cuda_local_var_23747_23_non_const_keys1, align 8
  %15 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %16 = load i32* %numElements.addr, align 4
  %cmp5 = icmp ult i32 %15, %16
  br i1 %cmp5, label %cond.true, label %cond.false

cond.true:                                        ; preds = %if.else
  %17 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %idxprom = zext i32 %17 to i64
  %18 = load i32** %__cuda_local_var_23747_23_non_const_keys1, align 8
  %arrayidx = getelementptr inbounds i32* %18, i64 %idxprom
  %19 = load i32* %arrayidx, align 4
  %call = call i32 @_Z9floatFlipILb0EEjj(i32 %19)
  br label %cond.end

cond.false:                                       ; preds = %if.else
  br label %cond.end

cond.end:                                         ; preds = %cond.false, %cond.true
  %cond = phi i32 [ %call, %cond.true ], [ -1, %cond.false ]
  %x6 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 0
  store i32 %cond, i32* %x6, align 4
  %20 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add7 = add i32 %20, 1
  %21 = load i32* %numElements.addr, align 4
  %cmp8 = icmp ult i32 %add7, %21
  br i1 %cmp8, label %cond.true9, label %cond.false14

cond.true9:                                       ; preds = %cond.end
  %22 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add10 = add i32 %22, 1
  %idxprom11 = zext i32 %add10 to i64
  %23 = load i32** %__cuda_local_var_23747_23_non_const_keys1, align 8
  %arrayidx12 = getelementptr inbounds i32* %23, i64 %idxprom11
  %24 = load i32* %arrayidx12, align 4
  %call13 = call i32 @_Z9floatFlipILb0EEjj(i32 %24)
  br label %cond.end15

cond.false14:                                     ; preds = %cond.end
  br label %cond.end15

cond.end15:                                       ; preds = %cond.false14, %cond.true9
  %cond16 = phi i32 [ %call13, %cond.true9 ], [ -1, %cond.false14 ]
  %y17 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 1
  store i32 %cond16, i32* %y17, align 4
  %25 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add18 = add i32 %25, 2
  %26 = load i32* %numElements.addr, align 4
  %cmp19 = icmp ult i32 %add18, %26
  br i1 %cmp19, label %cond.true20, label %cond.false25

cond.true20:                                      ; preds = %cond.end15
  %27 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add21 = add i32 %27, 2
  %idxprom22 = zext i32 %add21 to i64
  %28 = load i32** %__cuda_local_var_23747_23_non_const_keys1, align 8
  %arrayidx23 = getelementptr inbounds i32* %28, i64 %idxprom22
  %29 = load i32* %arrayidx23, align 4
  %call24 = call i32 @_Z9floatFlipILb0EEjj(i32 %29)
  br label %cond.end26

cond.false25:                                     ; preds = %cond.end15
  br label %cond.end26

cond.end26:                                       ; preds = %cond.false25, %cond.true20
  %cond27 = phi i32 [ %call24, %cond.true20 ], [ -1, %cond.false25 ]
  %z28 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 2
  store i32 %cond27, i32* %z28, align 4
  %w29 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 3
  store i32 -1, i32* %w29, align 4
  br label %if.end

if.end:                                           ; preds = %cond.end26, %if.then4
  br label %if.end33

if.else30:                                        ; preds = %while.body
  %30 = load i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %idxprom31 = zext i32 %30 to i64
  %31 = load %struct.uint4** %keysIn.addr, align 8
  %arrayidx32 = getelementptr inbounds %struct.uint4* %31, i64 %idxprom31
  %32 = bitcast %struct.uint4* %__cuda_local_var_23728_11_non_const_key to i8*
  %33 = bitcast %struct.uint4* %arrayidx32 to i8*
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* %32, i8* %33, i64 16, i32 16, i1 false)
  br label %if.end33

if.end33:                                         ; preds = %if.else30, %if.end
  call void @__syncthreads()
  call void @_Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4(%struct.uint4* %__cuda_local_var_23728_11_non_const_key)
  %34 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add34 = add i32 %34, 3
  %35 = load i32* %numElements.addr, align 4
  %cmp35 = icmp uge i32 %add34, %35
  br i1 %cmp35, label %if.then36, label %if.else59

if.then36:                                        ; preds = %if.end33
  %36 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %37 = load i32* %numElements.addr, align 4
  %cmp37 = icmp ult i32 %36, %37
  br i1 %cmp37, label %if.then38, label %if.end58

if.then38:                                        ; preds = %if.then36
  %38 = load %struct.uint4** %keysOut.addr, align 8
  %39 = bitcast %struct.uint4* %38 to i32*
  store i32* %39, i32** %__cuda_local_var_23776_23_non_const_keys1, align 8
  %x39 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 0
  %40 = load i32* %x39, align 4
  %41 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %idxprom40 = zext i32 %41 to i64
  %42 = load i32** %__cuda_local_var_23776_23_non_const_keys1, align 8
  %arrayidx41 = getelementptr inbounds i32* %42, i64 %idxprom40
  store i32 %40, i32* %arrayidx41, align 4
  %43 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add42 = add i32 %43, 1
  %44 = load i32* %numElements.addr, align 4
  %cmp43 = icmp ult i32 %add42, %44
  br i1 %cmp43, label %if.then44, label %if.end57

if.then44:                                        ; preds = %if.then38
  %y45 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 1
  %45 = load i32* %y45, align 4
  %46 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add46 = add i32 %46, 1
  %idxprom47 = zext i32 %add46 to i64
  %47 = load i32** %__cuda_local_var_23776_23_non_const_keys1, align 8
  %arrayidx48 = getelementptr inbounds i32* %47, i64 %idxprom47
  store i32 %45, i32* %arrayidx48, align 4
  %48 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add49 = add i32 %48, 2
  %49 = load i32* %numElements.addr, align 4
  %cmp50 = icmp ult i32 %add49, %49
  br i1 %cmp50, label %if.then51, label %if.end56

if.then51:                                        ; preds = %if.then44
  %z52 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 2
  %50 = load i32* %z52, align 4
  %51 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add53 = add i32 %51, 2
  %idxprom54 = zext i32 %add53 to i64
  %52 = load i32** %__cuda_local_var_23776_23_non_const_keys1, align 8
  %arrayidx55 = getelementptr inbounds i32* %52, i64 %idxprom54
  store i32 %50, i32* %arrayidx55, align 4
  br label %if.end56

if.end56:                                         ; preds = %if.then51, %if.then44
  br label %if.end57

if.end57:                                         ; preds = %if.end56, %if.then38
  br label %if.end58

if.end58:                                         ; preds = %if.end57, %if.then36
  br label %if.end62

if.else59:                                        ; preds = %if.end33
  %53 = load i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %idxprom60 = zext i32 %53 to i64
  %54 = load %struct.uint4** %keysOut.addr, align 8
  %arrayidx61 = getelementptr inbounds %struct.uint4* %54, i64 %idxprom60
  %55 = bitcast %struct.uint4* %arrayidx61 to i8*
  %56 = bitcast %struct.uint4* %__cuda_local_var_23728_11_non_const_key to i8*
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* %55, i8* %56, i64 16, i32 16, i1 false)
  br label %if.end62

if.end62:                                         ; preds = %if.else59, %if.end58
  %57 = load i32* getelementptr inbounds (%struct.dim3* @gridDim, i32 0, i32 0), align 4
  %58 = load i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  %add63 = add i32 %58, %57
  store i32 %add63, i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  br label %while.cond

while.end:                                        ; preds = %while.cond
  br label %__T229

__T229:                                           ; preds = %while.end
  ret void
}

define void @_Z23radixSortBlocksKeysOnlyILj4ELj0ELb0ELb0ELb0EEvP5uint4S1_jj(%struct.uint4* %keysOut, %struct.uint4* %keysIn, i32 %numElements, i32 %totalBlocks) uwtable {
entry:
  %keysOut.addr = alloca %struct.uint4*, align 8
  %keysIn.addr = alloca %struct.uint4*, align 8
  %numElements.addr = alloca i32, align 4
  %totalBlocks.addr = alloca i32, align 4
  %__cuda_local_var_23728_11_non_const_key = alloca %struct.uint4, align 16
  %__cuda_local_var_23730_10_non_const_blockId = alloca i32, align 4
  %__T230 = alloca %struct.uint4, align 16
  %__cuda_local_var_23734_14_non_const_i = alloca i32, align 4
  %__cuda_local_var_23735_14_non_const_idx = alloca i32, align 4
  %__cuda_local_var_23747_23_non_const_keys1 = alloca i32*, align 8
  %__cuda_local_var_23776_23_non_const_keys1 = alloca i32*, align 8
  store %struct.uint4* %keysOut, %struct.uint4** %keysOut.addr, align 8
  store %struct.uint4* %keysIn, %struct.uint4** %keysIn.addr, align 8
  store i32 %numElements, i32* %numElements.addr, align 4
  store i32 %totalBlocks, i32* %totalBlocks.addr, align 4
  %0 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @blockIdx to %struct.uint3*), i32 0, i32 0), align 4
  store i32 %0, i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  br label %while.body

while.body:                                       ; preds = %entry
  %1 = load i32* %__cuda_local_var_23730_10_non_const_blockId, align 4
  %2 = load i32* getelementptr inbounds (%struct.dim3* @blockDim, i32 0, i32 0), align 4
  %mul = mul i32 %1, %2
  %3 = load i32* getelementptr inbounds (%struct.uint3* bitcast (%struct.dim3* @threadIdx to %struct.uint3*), i32 0, i32 0), align 4
  %add = add i32 %mul, %3
  store i32 %add, i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %4 = load i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %shl = shl i32 %4, 2
  store i32 %shl, i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %5 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add1 = add i32 %5, 3
  %6 = load i32* %numElements.addr, align 4
  %cmp = icmp uge i32 %add1, %6
  br i1 %cmp, label %if.then, label %if.else29

if.then:                                          ; preds = %while.body
  %7 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %8 = load i32* %numElements.addr, align 4
  %cmp2 = icmp uge i32 %7, %8
  br i1 %cmp2, label %if.then3, label %if.else

if.then3:                                         ; preds = %if.then
  %x = getelementptr inbounds %struct.uint4* %__T230, i32 0, i32 0
  store i32 -1, i32* %x, align 4
  %y = getelementptr inbounds %struct.uint4* %__T230, i32 0, i32 1
  store i32 -1, i32* %y, align 4
  %z = getelementptr inbounds %struct.uint4* %__T230, i32 0, i32 2
  store i32 -1, i32* %z, align 4
  %w = getelementptr inbounds %struct.uint4* %__T230, i32 0, i32 3
  store i32 -1, i32* %w, align 4
  %9 = bitcast %struct.uint4* %__cuda_local_var_23728_11_non_const_key to i8*
  %10 = bitcast %struct.uint4* %__T230 to i8*
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* %9, i8* %10, i64 16, i32 16, i1 false)
  br label %if.end

if.else:                                          ; preds = %if.then
  %11 = load %struct.uint4** %keysIn.addr, align 8
  %12 = bitcast %struct.uint4* %11 to i32*
  store i32* %12, i32** %__cuda_local_var_23747_23_non_const_keys1, align 8
  %13 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %14 = load i32* %numElements.addr, align 4
  %cmp4 = icmp ult i32 %13, %14
  br i1 %cmp4, label %cond.true, label %cond.false

cond.true:                                        ; preds = %if.else
  %15 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %idxprom = zext i32 %15 to i64
  %16 = load i32** %__cuda_local_var_23747_23_non_const_keys1, align 8
  %arrayidx = getelementptr inbounds i32* %16, i64 %idxprom
  %17 = load i32* %arrayidx, align 4
  %call = call i32 @_Z9floatFlipILb0EEjj(i32 %17)
  br label %cond.end

cond.false:                                       ; preds = %if.else
  br label %cond.end

cond.end:                                         ; preds = %cond.false, %cond.true
  %cond = phi i32 [ %call, %cond.true ], [ -1, %cond.false ]
  %x5 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 0
  store i32 %cond, i32* %x5, align 4
  %18 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add6 = add i32 %18, 1
  %19 = load i32* %numElements.addr, align 4
  %cmp7 = icmp ult i32 %add6, %19
  br i1 %cmp7, label %cond.true8, label %cond.false13

cond.true8:                                       ; preds = %cond.end
  %20 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add9 = add i32 %20, 1
  %idxprom10 = zext i32 %add9 to i64
  %21 = load i32** %__cuda_local_var_23747_23_non_const_keys1, align 8
  %arrayidx11 = getelementptr inbounds i32* %21, i64 %idxprom10
  %22 = load i32* %arrayidx11, align 4
  %call12 = call i32 @_Z9floatFlipILb0EEjj(i32 %22)
  br label %cond.end14

cond.false13:                                     ; preds = %cond.end
  br label %cond.end14

cond.end14:                                       ; preds = %cond.false13, %cond.true8
  %cond15 = phi i32 [ %call12, %cond.true8 ], [ -1, %cond.false13 ]
  %y16 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 1
  store i32 %cond15, i32* %y16, align 4
  %23 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add17 = add i32 %23, 2
  %24 = load i32* %numElements.addr, align 4
  %cmp18 = icmp ult i32 %add17, %24
  br i1 %cmp18, label %cond.true19, label %cond.false24

cond.true19:                                      ; preds = %cond.end14
  %25 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add20 = add i32 %25, 2
  %idxprom21 = zext i32 %add20 to i64
  %26 = load i32** %__cuda_local_var_23747_23_non_const_keys1, align 8
  %arrayidx22 = getelementptr inbounds i32* %26, i64 %idxprom21
  %27 = load i32* %arrayidx22, align 4
  %call23 = call i32 @_Z9floatFlipILb0EEjj(i32 %27)
  br label %cond.end25

cond.false24:                                     ; preds = %cond.end14
  br label %cond.end25

cond.end25:                                       ; preds = %cond.false24, %cond.true19
  %cond26 = phi i32 [ %call23, %cond.true19 ], [ -1, %cond.false24 ]
  %z27 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 2
  store i32 %cond26, i32* %z27, align 4
  %w28 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 3
  store i32 -1, i32* %w28, align 4
  br label %if.end

if.end:                                           ; preds = %cond.end25, %if.then3
  br label %if.end32

if.else29:                                        ; preds = %while.body
  %28 = load i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %idxprom30 = zext i32 %28 to i64
  %29 = load %struct.uint4** %keysIn.addr, align 8
  %arrayidx31 = getelementptr inbounds %struct.uint4* %29, i64 %idxprom30
  %30 = bitcast %struct.uint4* %__cuda_local_var_23728_11_non_const_key to i8*
  %31 = bitcast %struct.uint4* %arrayidx31 to i8*
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* %30, i8* %31, i64 16, i32 16, i1 false)
  br label %if.end32

if.end32:                                         ; preds = %if.else29, %if.end
  call void @__syncthreads()
  call void @_Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4(%struct.uint4* %__cuda_local_var_23728_11_non_const_key)
  %32 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add33 = add i32 %32, 3
  %33 = load i32* %numElements.addr, align 4
  %cmp34 = icmp uge i32 %add33, %33
  br i1 %cmp34, label %if.then35, label %if.else58

if.then35:                                        ; preds = %if.end32
  %34 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %35 = load i32* %numElements.addr, align 4
  %cmp36 = icmp ult i32 %34, %35
  br i1 %cmp36, label %if.then37, label %if.end57

if.then37:                                        ; preds = %if.then35
  %36 = load %struct.uint4** %keysOut.addr, align 8
  %37 = bitcast %struct.uint4* %36 to i32*
  store i32* %37, i32** %__cuda_local_var_23776_23_non_const_keys1, align 8
  %x38 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 0
  %38 = load i32* %x38, align 4
  %39 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %idxprom39 = zext i32 %39 to i64
  %40 = load i32** %__cuda_local_var_23776_23_non_const_keys1, align 8
  %arrayidx40 = getelementptr inbounds i32* %40, i64 %idxprom39
  store i32 %38, i32* %arrayidx40, align 4
  %41 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add41 = add i32 %41, 1
  %42 = load i32* %numElements.addr, align 4
  %cmp42 = icmp ult i32 %add41, %42
  br i1 %cmp42, label %if.then43, label %if.end56

if.then43:                                        ; preds = %if.then37
  %y44 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 1
  %43 = load i32* %y44, align 4
  %44 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add45 = add i32 %44, 1
  %idxprom46 = zext i32 %add45 to i64
  %45 = load i32** %__cuda_local_var_23776_23_non_const_keys1, align 8
  %arrayidx47 = getelementptr inbounds i32* %45, i64 %idxprom46
  store i32 %43, i32* %arrayidx47, align 4
  %46 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add48 = add i32 %46, 2
  %47 = load i32* %numElements.addr, align 4
  %cmp49 = icmp ult i32 %add48, %47
  br i1 %cmp49, label %if.then50, label %if.end55

if.then50:                                        ; preds = %if.then43
  %z51 = getelementptr inbounds %struct.uint4* %__cuda_local_var_23728_11_non_const_key, i32 0, i32 2
  %48 = load i32* %z51, align 4
  %49 = load i32* %__cuda_local_var_23735_14_non_const_idx, align 4
  %add52 = add i32 %49, 2
  %idxprom53 = zext i32 %add52 to i64
  %50 = load i32** %__cuda_local_var_23776_23_non_const_keys1, align 8
  %arrayidx54 = getelementptr inbounds i32* %50, i64 %idxprom53
  store i32 %48, i32* %arrayidx54, align 4
  br label %if.end55

if.end55:                                         ; preds = %if.then50, %if.then43
  br label %if.end56

if.end56:                                         ; preds = %if.end55, %if.then37
  br label %if.end57

if.end57:                                         ; preds = %if.end56, %if.then35
  br label %if.end61

if.else58:                                        ; preds = %if.end32
  %51 = load i32* %__cuda_local_var_23734_14_non_const_i, align 4
  %idxprom59 = zext i32 %51 to i64
  %52 = load %struct.uint4** %keysOut.addr, align 8
  %arrayidx60 = getelementptr inbounds %struct.uint4* %52, i64 %idxprom59
  %53 = bitcast %struct.uint4* %arrayidx60 to i8*
  %54 = bitcast %struct.uint4* %__cuda_local_var_23728_11_non_const_key to i8*
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* %53, i8* %54, i64 16, i32 16, i1 false)
  br label %if.end61

if.end61:                                         ; preds = %if.else58, %if.end57
  br label %__T231

__T231:                                           ; preds = %if.end61
  ret void
}

define internal void @__cxx_global_var_init() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @gridDim, i32 1, i32 1, i32 1), !dbg !165
  ret void, !dbg !165
}

define linkonce_odr void @_ZN4dim3C1Ejjj(%struct.dim3* %this, i32 %vx, i32 %vy, i32 %vz) unnamed_addr uwtable section "__device__" align 2 {
entry:
  %this.addr = alloca %struct.dim3*, align 8
  %vx.addr = alloca i32, align 4
  %vy.addr = alloca i32, align 4
  %vz.addr = alloca i32, align 4
  store %struct.dim3* %this, %struct.dim3** %this.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !166), !dbg !168
  store i32 %vx, i32* %vx.addr, align 4
  call void @llvm.dbg.declare(metadata !8, metadata !169), !dbg !170
  store i32 %vy, i32* %vy.addr, align 4
  call void @llvm.dbg.declare(metadata !8, metadata !171), !dbg !172
  store i32 %vz, i32* %vz.addr, align 4
  call void @llvm.dbg.declare(metadata !8, metadata !173), !dbg !174
  %this1 = load %struct.dim3** %this.addr
  %0 = load i32* %vx.addr, align 4, !dbg !175
  %1 = load i32* %vy.addr, align 4, !dbg !175
  %2 = load i32* %vz.addr, align 4, !dbg !175
  call void @_ZN4dim3C2Ejjj(%struct.dim3* %this1, i32 %0, i32 %1, i32 %2), !dbg !175
  ret void, !dbg !175
}

define internal void @__cxx_global_var_init1() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @blockIdx, i32 1, i32 1, i32 1), !dbg !176
  ret void, !dbg !176
}

define internal void @__cxx_global_var_init2() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @blockDim, i32 1, i32 1, i32 1), !dbg !177
  ret void, !dbg !177
}

define internal void @__cxx_global_var_init3() section ".text.startup" {
entry:
  call void @_ZN4dim3C1Ejjj(%struct.dim3* @threadIdx, i32 1, i32 1, i32 1), !dbg !178
  ret void, !dbg !178
}

define void @initDeviceParameters() nounwind uwtable {
entry:
  ret void, !dbg !179
}

define void @checkCudaError(i8* %msg) nounwind uwtable {
entry:
  %msg.addr = alloca i8*, align 8
  store i8* %msg, i8** %msg.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !181), !dbg !182
  ret void, !dbg !183
}

declare void @llvm.dbg.declare(metadata, metadata) nounwind readnone

declare i32 @cudaSetupArgument(i8*, i64, i64)

declare i32 @cudaLaunch(i8*)

define void @radixSortKeysOnly(i32* %keys, i32* %tempKeys, i32* %counters, i32* %countersSum, i32* %blockOffsets, i32 %numElements, i32 %keyBits, i1 zeroext %flipBits) uwtable {
entry:
  %keys.addr = alloca i32*, align 8
  %tempKeys.addr = alloca i32*, align 8
  %counters.addr = alloca i32*, align 8
  %countersSum.addr = alloca i32*, align 8
  %blockOffsets.addr = alloca i32*, align 8
  %scanPlan = alloca %struct.CUDPPHandle, align 1
  %numElements.addr = alloca i32, align 4
  %keyBits.addr = alloca i32, align 4
  %flipBits.addr = alloca i8, align 1
  %agg.tmp = alloca %struct.CUDPPHandle, align 1
  %agg.tmp1 = alloca %struct.CUDPPHandle, align 1
  store i32* %keys, i32** %keys.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !185), !dbg !186
  store i32* %tempKeys, i32** %tempKeys.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !187), !dbg !188
  store i32* %counters, i32** %counters.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !189), !dbg !190
  store i32* %countersSum, i32** %countersSum.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !191), !dbg !192
  store i32* %blockOffsets, i32** %blockOffsets.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !193), !dbg !194
  call void @llvm.dbg.declare(metadata !8, metadata !195), !dbg !196
  store i32 %numElements, i32* %numElements.addr, align 4
  call void @llvm.dbg.declare(metadata !8, metadata !197), !dbg !198
  store i32 %keyBits, i32* %keyBits.addr, align 4
  call void @llvm.dbg.declare(metadata !8, metadata !199), !dbg !200
  %frombool = zext i1 %flipBits to i8
  store i8 %frombool, i8* %flipBits.addr, align 1
  call void @llvm.dbg.declare(metadata !8, metadata !201), !dbg !202
  %0 = load i8* %flipBits.addr, align 1, !dbg !203
  %tobool = trunc i8 %0 to i1, !dbg !203
  br i1 %tobool, label %if.then, label %if.else, !dbg !203

if.then:                                          ; preds = %entry
  %1 = load i32** %keys.addr, align 8, !dbg !205
  %2 = load i32** %tempKeys.addr, align 8, !dbg !205
  %3 = load i32** %counters.addr, align 8, !dbg !205
  %4 = load i32** %countersSum.addr, align 8, !dbg !205
  %5 = load i32** %blockOffsets.addr, align 8, !dbg !205
  %6 = load i32* %numElements.addr, align 4, !dbg !205
  call void @_Z21radixSortStepKeysOnlyILj4ELj0ELb1ELb0EEvPjS0_S0_S0_S0_11CUDPPHandlej(i32* %1, i32* %2, i32* %3, i32* %4, i32* %5, i32 %6), !dbg !205
  br label %if.end, !dbg !207

if.else:                                          ; preds = %entry
  %7 = load i32** %keys.addr, align 8, !dbg !208
  %8 = load i32** %tempKeys.addr, align 8, !dbg !208
  %9 = load i32** %counters.addr, align 8, !dbg !208
  %10 = load i32** %countersSum.addr, align 8, !dbg !208
  %11 = load i32** %blockOffsets.addr, align 8, !dbg !208
  %12 = load i32* %numElements.addr, align 4, !dbg !208
  call void @_Z21radixSortStepKeysOnlyILj4ELj0ELb0ELb0EEvPjS0_S0_S0_S0_11CUDPPHandlej(i32* %7, i32* %8, i32* %9, i32* %10, i32* %11, i32 %12), !dbg !208
  br label %if.end

if.end:                                           ; preds = %if.else, %if.then
  ret void, !dbg !210
}

define linkonce_odr void @_Z21radixSortStepKeysOnlyILj4ELj0ELb1ELb0EEvPjS0_S0_S0_S0_11CUDPPHandlej(i32* %keys, i32* %tempKeys, i32* %counters, i32* %countersSum, i32* %blockOffsets, i32 %numElements) uwtable {
entry:
  %keys.addr = alloca i32*, align 8
  %tempKeys.addr = alloca i32*, align 8
  %counters.addr = alloca i32*, align 8
  %countersSum.addr = alloca i32*, align 8
  %blockOffsets.addr = alloca i32*, align 8
  %scanPlan = alloca %struct.CUDPPHandle, align 1
  %numElements.addr = alloca i32, align 4
  %eltsPerBlock = alloca i32, align 4
  %eltsPerBlock2 = alloca i32, align 4
  %fullBlocks = alloca i8, align 1
  %numBlocks = alloca i32, align 4
  %numBlocks2 = alloca i32, align 4
  %loop = alloca i8, align 1
  %loop2 = alloca i8, align 1
  %blocks = alloca i32, align 4
  %blocksFind = alloca i32, align 4
  %blocksReorder = alloca i32, align 4
  %agg.tmp = alloca %struct.dim3, align 4
  %agg.tmp33 = alloca %struct.dim3, align 4
  %agg.tmp35 = alloca %struct.dim3, align 4
  %agg.tmp36 = alloca %struct.dim3, align 4
  %agg.tmp44 = alloca %struct.dim3, align 4
  %agg.tmp45 = alloca %struct.dim3, align 4
  %agg.tmp51 = alloca %struct.dim3, align 4
  %agg.tmp52 = alloca %struct.dim3, align 4
  store i32* %keys, i32** %keys.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !211), !dbg !212
  store i32* %tempKeys, i32** %tempKeys.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !213), !dbg !214
  store i32* %counters, i32** %counters.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !215), !dbg !216
  store i32* %countersSum, i32** %countersSum.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !217), !dbg !218
  store i32* %blockOffsets, i32** %blockOffsets.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !219), !dbg !220
  call void @llvm.dbg.declare(metadata !8, metadata !221), !dbg !222
  store i32 %numElements, i32* %numElements.addr, align 4
  call void @llvm.dbg.declare(metadata !8, metadata !223), !dbg !224
  call void @llvm.dbg.declare(metadata !8, metadata !225), !dbg !227
  store i32 1024, i32* %eltsPerBlock, align 4, !dbg !228
  call void @llvm.dbg.declare(metadata !8, metadata !229), !dbg !230
  store i32 512, i32* %eltsPerBlock2, align 4, !dbg !231
  call void @llvm.dbg.declare(metadata !8, metadata !232), !dbg !233
  %0 = load i32* %numElements.addr, align 4, !dbg !234
  %rem = urem i32 %0, 1024, !dbg !234
  %cmp = icmp eq i32 %rem, 0, !dbg !234
  %frombool = zext i1 %cmp to i8, !dbg !234
  store i8 %frombool, i8* %fullBlocks, align 1, !dbg !234
  call void @llvm.dbg.declare(metadata !8, metadata !235), !dbg !236
  %1 = load i8* %fullBlocks, align 1, !dbg !237
  %tobool = trunc i8 %1 to i1, !dbg !237
  br i1 %tobool, label %cond.true, label %cond.false, !dbg !237

cond.true:                                        ; preds = %entry
  %2 = load i32* %numElements.addr, align 4, !dbg !237
  %div = udiv i32 %2, 1024, !dbg !237
  br label %cond.end, !dbg !237

cond.false:                                       ; preds = %entry
  %3 = load i32* %numElements.addr, align 4, !dbg !237
  %div1 = udiv i32 %3, 1024, !dbg !237
  %add = add i32 %div1, 1, !dbg !237
  br label %cond.end, !dbg !237

cond.end:                                         ; preds = %cond.false, %cond.true
  %cond = phi i32 [ %div, %cond.true ], [ %add, %cond.false ], !dbg !237
  store i32 %cond, i32* %numBlocks, align 4, !dbg !237
  call void @llvm.dbg.declare(metadata !8, metadata !238), !dbg !239
  %4 = load i32* %numElements.addr, align 4, !dbg !240
  %rem2 = urem i32 %4, 512, !dbg !240
  %cmp3 = icmp eq i32 %rem2, 0, !dbg !240
  br i1 %cmp3, label %cond.true4, label %cond.false6, !dbg !240

cond.true4:                                       ; preds = %cond.end
  %5 = load i32* %numElements.addr, align 4, !dbg !240
  %div5 = udiv i32 %5, 512, !dbg !240
  br label %cond.end9, !dbg !240

cond.false6:                                      ; preds = %cond.end
  %6 = load i32* %numElements.addr, align 4, !dbg !240
  %div7 = udiv i32 %6, 512, !dbg !240
  %add8 = add i32 %div7, 1, !dbg !240
  br label %cond.end9, !dbg !240

cond.end9:                                        ; preds = %cond.false6, %cond.true4
  %cond10 = phi i32 [ %div5, %cond.true4 ], [ %add8, %cond.false6 ], !dbg !240
  store i32 %cond10, i32* %numBlocks2, align 4, !dbg !240
  call void @llvm.dbg.declare(metadata !8, metadata !241), !dbg !242
  %7 = load i32* %numBlocks, align 4, !dbg !243
  %cmp11 = icmp ugt i32 %7, 65535, !dbg !243
  %frombool12 = zext i1 %cmp11 to i8, !dbg !243
  store i8 %frombool12, i8* %loop, align 1, !dbg !243
  call void @llvm.dbg.declare(metadata !8, metadata !244), !dbg !245
  %8 = load i32* %numBlocks2, align 4, !dbg !246
  %cmp13 = icmp ugt i32 %8, 65535, !dbg !246
  %frombool14 = zext i1 %cmp13 to i8, !dbg !246
  store i8 %frombool14, i8* %loop2, align 1, !dbg !246
  call void @llvm.dbg.declare(metadata !8, metadata !247), !dbg !248
  %9 = load i8* %loop, align 1, !dbg !249
  %tobool15 = trunc i8 %9 to i1, !dbg !249
  br i1 %tobool15, label %cond.true16, label %cond.false17, !dbg !249

cond.true16:                                      ; preds = %cond.end9
  br label %cond.end18, !dbg !249

cond.false17:                                     ; preds = %cond.end9
  %10 = load i32* %numBlocks, align 4, !dbg !249
  br label %cond.end18, !dbg !249

cond.end18:                                       ; preds = %cond.false17, %cond.true16
  %cond19 = phi i32 [ 65535, %cond.true16 ], [ %10, %cond.false17 ], !dbg !249
  store i32 %cond19, i32* %blocks, align 4, !dbg !249
  call void @llvm.dbg.declare(metadata !8, metadata !250), !dbg !251
  %11 = load i8* %loop2, align 1, !dbg !252
  %tobool20 = trunc i8 %11 to i1, !dbg !252
  br i1 %tobool20, label %cond.true21, label %cond.false22, !dbg !252

cond.true21:                                      ; preds = %cond.end18
  br label %cond.end23, !dbg !252

cond.false22:                                     ; preds = %cond.end18
  %12 = load i32* %numBlocks2, align 4, !dbg !252
  br label %cond.end23, !dbg !252

cond.end23:                                       ; preds = %cond.false22, %cond.true21
  %cond24 = phi i32 [ 65535, %cond.true21 ], [ %12, %cond.false22 ], !dbg !252
  store i32 %cond24, i32* %blocksFind, align 4, !dbg !252
  call void @llvm.dbg.declare(metadata !8, metadata !253), !dbg !254
  %13 = load i8* %loop2, align 1, !dbg !255
  %tobool25 = trunc i8 %13 to i1, !dbg !255
  br i1 %tobool25, label %cond.true26, label %cond.false27, !dbg !255

cond.true26:                                      ; preds = %cond.end23
  br label %cond.end28, !dbg !255

cond.false27:                                     ; preds = %cond.end23
  %14 = load i32* %numBlocks2, align 4, !dbg !255
  br label %cond.end28, !dbg !255

cond.end28:                                       ; preds = %cond.false27, %cond.true26
  %cond29 = phi i32 [ 65535, %cond.true26 ], [ %14, %cond.false27 ], !dbg !255
  store i32 %cond29, i32* %blocksReorder, align 4, !dbg !255
  %15 = load i8* %fullBlocks, align 1, !dbg !256
  %tobool30 = trunc i8 %15 to i1, !dbg !256
  br i1 %tobool30, label %if.then, label %if.else41, !dbg !256

if.then:                                          ; preds = %cond.end28
  %16 = load i8* %loop, align 1, !dbg !257
  %tobool31 = trunc i8 %16 to i1, !dbg !257
  br i1 %tobool31, label %if.then32, label %if.else, !dbg !257

if.then32:                                        ; preds = %if.then
  %17 = load i32* %blocks, align 4, !dbg !259
  call void @_ZN4dim3C1Ejjj(%struct.dim3* %agg.tmp, i32 %17, i32 1, i32 1), !dbg !259
  %18 = load i32* %numElements.addr, align 4, !dbg !259
  call void @_ZN4dim3C1Ejjj(%struct.dim3* %agg.tmp33, i32 %18, i32 1, i32 1), !dbg !259
  %19 = bitcast %struct.dim3* %agg.tmp to { i64, i32 }*, !dbg !259
  %20 = getelementptr { i64, i32 }* %19, i32 0, i32 0, !dbg !259
  %21 = load i64* %20, align 1, !dbg !259
  %22 = getelementptr { i64, i32 }* %19, i32 0, i32 1, !dbg !259
  %23 = load i32* %22, align 1, !dbg !259
  %24 = bitcast %struct.dim3* %agg.tmp33 to { i64, i32 }*, !dbg !259
  %25 = getelementptr { i64, i32 }* %24, i32 0, i32 0, !dbg !259
  %26 = load i64* %25, align 1, !dbg !259
  %27 = getelementptr { i64, i32 }* %24, i32 0, i32 1, !dbg !259
  %28 = load i32* %27, align 1, !dbg !259
  %call = call i32 @cudaConfigureCall(i64 %21, i32 %23, i64 %26, i32 %28, i64 0, %struct.CUstream_st* null), !dbg !259
  %tobool34 = icmp ne i32 %call, 0, !dbg !259
  br i1 %tobool34, label %kcall.end, label %kcall.configok, !dbg !259

kcall.configok:                                   ; preds = %if.then32
  %29 = load i32** %tempKeys.addr, align 8, !dbg !259
  %30 = bitcast i32* %29 to %struct.uint4*, !dbg !259
  %31 = load i32** %keys.addr, align 8, !dbg !259
  %32 = bitcast i32* %31 to %struct.uint4*, !dbg !259
  %33 = load i32* %numElements.addr, align 4, !dbg !259
  %34 = load i32* %numBlocks, align 4, !dbg !259
  call void @_Z23radixSortBlocksKeysOnlyILj4ELj0ELb1ELb1ELb1EEvP5uint4S1_jj(%struct.uint4* %30, %struct.uint4* %32, i32 %33, i32 %34), !dbg !259
  br label %kcall.end, !dbg !259

kcall.end:                                        ; preds = %kcall.configok, %if.then32
  br label %if.end, !dbg !259

if.else:                                          ; preds = %if.then
  %35 = load i32* %blocks, align 4, !dbg !260
  call void @_ZN4dim3C1Ejjj(%struct.dim3* %agg.tmp35, i32 %35, i32 1, i32 1), !dbg !260
  %36 = load i32* %numElements.addr, align 4, !dbg !260
  call void @_ZN4dim3C1Ejjj(%struct.dim3* %agg.tmp36, i32 %36, i32 1, i32 1), !dbg !260
  %37 = bitcast %struct.dim3* %agg.tmp35 to { i64, i32 }*, !dbg !260
  %38 = getelementptr { i64, i32 }* %37, i32 0, i32 0, !dbg !260
  %39 = load i64* %38, align 1, !dbg !260
  %40 = getelementptr { i64, i32 }* %37, i32 0, i32 1, !dbg !260
  %41 = load i32* %40, align 1, !dbg !260
  %42 = bitcast %struct.dim3* %agg.tmp36 to { i64, i32 }*, !dbg !260
  %43 = getelementptr { i64, i32 }* %42, i32 0, i32 0, !dbg !260
  %44 = load i64* %43, align 1, !dbg !260
  %45 = getelementptr { i64, i32 }* %42, i32 0, i32 1, !dbg !260
  %46 = load i32* %45, align 1, !dbg !260
  %call37 = call i32 @cudaConfigureCall(i64 %39, i32 %41, i64 %44, i32 %46, i64 0, %struct.CUstream_st* null), !dbg !260
  %tobool38 = icmp ne i32 %call37, 0, !dbg !260
  br i1 %tobool38, label %kcall.end40, label %kcall.configok39, !dbg !260

kcall.configok39:                                 ; preds = %if.else
  %47 = load i32** %tempKeys.addr, align 8, !dbg !260
  %48 = bitcast i32* %47 to %struct.uint4*, !dbg !260
  %49 = load i32** %keys.addr, align 8, !dbg !260
  %50 = bitcast i32* %49 to %struct.uint4*, !dbg !260
  %51 = load i32* %numElements.addr, align 4, !dbg !260
  %52 = load i32* %numBlocks, align 4, !dbg !260
  call void @_Z23radixSortBlocksKeysOnlyILj4ELj0ELb1ELb1ELb0EEvP5uint4S1_jj(%struct.uint4* %48, %struct.uint4* %50, i32 %51, i32 %52), !dbg !260
  br label %kcall.end40, !dbg !260

kcall.end40:                                      ; preds = %kcall.configok39, %if.else
  br label %if.end

if.end:                                           ; preds = %kcall.end40, %kcall.end
  br label %if.end58, !dbg !261

if.else41:                                        ; preds = %cond.end28
  %53 = load i8* %loop, align 1, !dbg !262
  %tobool42 = trunc i8 %53 to i1, !dbg !262
  br i1 %tobool42, label %if.then43, label %if.else50, !dbg !262

if.then43:                                        ; preds = %if.else41
  %54 = load i32* %blocks, align 4, !dbg !264
  call void @_ZN4dim3C1Ejjj(%struct.dim3* %agg.tmp44, i32 %54, i32 1, i32 1), !dbg !264
  %55 = load i32* %numElements.addr, align 4, !dbg !264
  call void @_ZN4dim3C1Ejjj(%struct.dim3* %agg.tmp45, i32 %55, i32 1, i32 1), !dbg !264
  %56 = bitcast %struct.dim3* %agg.tmp44 to { i64, i32 }*, !dbg !264
  %57 = getelementptr { i64, i32 }* %56, i32 0, i32 0, !dbg !264
  %58 = load i64* %57, align 1, !dbg !264
  %59 = getelementptr { i64, i32 }* %56, i32 0, i32 1, !dbg !264
  %60 = load i32* %59, align 1, !dbg !264
  %61 = bitcast %struct.dim3* %agg.tmp45 to { i64, i32 }*, !dbg !264
  %62 = getelementptr { i64, i32 }* %61, i32 0, i32 0, !dbg !264
  %63 = load i64* %62, align 1, !dbg !264
  %64 = getelementptr { i64, i32 }* %61, i32 0, i32 1, !dbg !264
  %65 = load i32* %64, align 1, !dbg !264
  %call46 = call i32 @cudaConfigureCall(i64 %58, i32 %60, i64 %63, i32 %65, i64 0, %struct.CUstream_st* null), !dbg !264
  %tobool47 = icmp ne i32 %call46, 0, !dbg !264
  br i1 %tobool47, label %kcall.end49, label %kcall.configok48, !dbg !264

kcall.configok48:                                 ; preds = %if.then43
  %66 = load i32** %tempKeys.addr, align 8, !dbg !264
  %67 = bitcast i32* %66 to %struct.uint4*, !dbg !264
  %68 = load i32** %keys.addr, align 8, !dbg !264
  %69 = bitcast i32* %68 to %struct.uint4*, !dbg !264
  %70 = load i32* %numElements.addr, align 4, !dbg !264
  %71 = load i32* %numBlocks, align 4, !dbg !264
  call void @_Z23radixSortBlocksKeysOnlyILj4ELj0ELb0ELb1ELb1EEvP5uint4S1_jj(%struct.uint4* %67, %struct.uint4* %69, i32 %70, i32 %71), !dbg !264
  br label %kcall.end49, !dbg !264

kcall.end49:                                      ; preds = %kcall.configok48, %if.then43
  br label %if.end57, !dbg !264

if.else50:                                        ; preds = %if.else41
  %72 = load i32* %blocks, align 4, !dbg !265
  call void @_ZN4dim3C1Ejjj(%struct.dim3* %agg.tmp51, i32 %72, i32 1, i32 1), !dbg !265
  %73 = load i32* %numElements.addr, align 4, !dbg !265
  call void @_ZN4dim3C1Ejjj(%struct.dim3* %agg.tmp52, i32 %73, i32 1, i32 1), !dbg !265
  %74 = bitcast %struct.dim3* %agg.tmp51 to { i64, i32 }*, !dbg !265
  %75 = getelementptr { i64, i32 }* %74, i32 0, i32 0, !dbg !265
  %76 = load i64* %75, align 1, !dbg !265
  %77 = getelementptr { i64, i32 }* %74, i32 0, i32 1, !dbg !265
  %78 = load i32* %77, align 1, !dbg !265
  %79 = bitcast %struct.dim3* %agg.tmp52 to { i64, i32 }*, !dbg !265
  %80 = getelementptr { i64, i32 }* %79, i32 0, i32 0, !dbg !265
  %81 = load i64* %80, align 1, !dbg !265
  %82 = getelementptr { i64, i32 }* %79, i32 0, i32 1, !dbg !265
  %83 = load i32* %82, align 1, !dbg !265
  %call53 = call i32 @cudaConfigureCall(i64 %76, i32 %78, i64 %81, i32 %83, i64 0, %struct.CUstream_st* null), !dbg !265
  %tobool54 = icmp ne i32 %call53, 0, !dbg !265
  br i1 %tobool54, label %kcall.end56, label %kcall.configok55, !dbg !265

kcall.configok55:                                 ; preds = %if.else50
  %84 = load i32** %tempKeys.addr, align 8, !dbg !265
  %85 = bitcast i32* %84 to %struct.uint4*, !dbg !265
  %86 = load i32** %keys.addr, align 8, !dbg !265
  %87 = bitcast i32* %86 to %struct.uint4*, !dbg !265
  %88 = load i32* %numElements.addr, align 4, !dbg !265
  %89 = load i32* %numBlocks, align 4, !dbg !265
  call void @_Z23radixSortBlocksKeysOnlyILj4ELj0ELb0ELb1ELb0EEvP5uint4S1_jj(%struct.uint4* %85, %struct.uint4* %87, i32 %88, i32 %89), !dbg !265
  br label %kcall.end56, !dbg !265

kcall.end56:                                      ; preds = %kcall.configok55, %if.else50
  br label %if.end57

if.end57:                                         ; preds = %kcall.end56, %kcall.end49
  br label %if.end58

if.end58:                                         ; preds = %if.end57, %if.end
  ret void, !dbg !266
}

define linkonce_odr void @_Z21radixSortStepKeysOnlyILj4ELj0ELb0ELb0EEvPjS0_S0_S0_S0_11CUDPPHandlej(i32* %keys, i32* %tempKeys, i32* %counters, i32* %countersSum, i32* %blockOffsets, i32 %numElements) uwtable {
entry:
  %keys.addr = alloca i32*, align 8
  %tempKeys.addr = alloca i32*, align 8
  %counters.addr = alloca i32*, align 8
  %countersSum.addr = alloca i32*, align 8
  %blockOffsets.addr = alloca i32*, align 8
  %scanPlan = alloca %struct.CUDPPHandle, align 1
  %numElements.addr = alloca i32, align 4
  %eltsPerBlock = alloca i32, align 4
  %eltsPerBlock2 = alloca i32, align 4
  %fullBlocks = alloca i8, align 1
  %numBlocks = alloca i32, align 4
  %numBlocks2 = alloca i32, align 4
  %loop = alloca i8, align 1
  %loop2 = alloca i8, align 1
  %blocks = alloca i32, align 4
  %blocksFind = alloca i32, align 4
  %blocksReorder = alloca i32, align 4
  %agg.tmp = alloca %struct.dim3, align 4
  %agg.tmp33 = alloca %struct.dim3, align 4
  %agg.tmp35 = alloca %struct.dim3, align 4
  %agg.tmp36 = alloca %struct.dim3, align 4
  %agg.tmp44 = alloca %struct.dim3, align 4
  %agg.tmp45 = alloca %struct.dim3, align 4
  %agg.tmp51 = alloca %struct.dim3, align 4
  %agg.tmp52 = alloca %struct.dim3, align 4
  store i32* %keys, i32** %keys.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !267), !dbg !268
  store i32* %tempKeys, i32** %tempKeys.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !269), !dbg !270
  store i32* %counters, i32** %counters.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !271), !dbg !272
  store i32* %countersSum, i32** %countersSum.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !273), !dbg !274
  store i32* %blockOffsets, i32** %blockOffsets.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !275), !dbg !276
  call void @llvm.dbg.declare(metadata !8, metadata !277), !dbg !278
  store i32 %numElements, i32* %numElements.addr, align 4
  call void @llvm.dbg.declare(metadata !8, metadata !279), !dbg !280
  call void @llvm.dbg.declare(metadata !8, metadata !281), !dbg !283
  store i32 1024, i32* %eltsPerBlock, align 4, !dbg !284
  call void @llvm.dbg.declare(metadata !8, metadata !285), !dbg !286
  store i32 512, i32* %eltsPerBlock2, align 4, !dbg !287
  call void @llvm.dbg.declare(metadata !8, metadata !288), !dbg !289
  %0 = load i32* %numElements.addr, align 4, !dbg !290
  %rem = urem i32 %0, 1024, !dbg !290
  %cmp = icmp eq i32 %rem, 0, !dbg !290
  %frombool = zext i1 %cmp to i8, !dbg !290
  store i8 %frombool, i8* %fullBlocks, align 1, !dbg !290
  call void @llvm.dbg.declare(metadata !8, metadata !291), !dbg !292
  %1 = load i8* %fullBlocks, align 1, !dbg !293
  %tobool = trunc i8 %1 to i1, !dbg !293
  br i1 %tobool, label %cond.true, label %cond.false, !dbg !293

cond.true:                                        ; preds = %entry
  %2 = load i32* %numElements.addr, align 4, !dbg !293
  %div = udiv i32 %2, 1024, !dbg !293
  br label %cond.end, !dbg !293

cond.false:                                       ; preds = %entry
  %3 = load i32* %numElements.addr, align 4, !dbg !293
  %div1 = udiv i32 %3, 1024, !dbg !293
  %add = add i32 %div1, 1, !dbg !293
  br label %cond.end, !dbg !293

cond.end:                                         ; preds = %cond.false, %cond.true
  %cond = phi i32 [ %div, %cond.true ], [ %add, %cond.false ], !dbg !293
  store i32 %cond, i32* %numBlocks, align 4, !dbg !293
  call void @llvm.dbg.declare(metadata !8, metadata !294), !dbg !295
  %4 = load i32* %numElements.addr, align 4, !dbg !296
  %rem2 = urem i32 %4, 512, !dbg !296
  %cmp3 = icmp eq i32 %rem2, 0, !dbg !296
  br i1 %cmp3, label %cond.true4, label %cond.false6, !dbg !296

cond.true4:                                       ; preds = %cond.end
  %5 = load i32* %numElements.addr, align 4, !dbg !296
  %div5 = udiv i32 %5, 512, !dbg !296
  br label %cond.end9, !dbg !296

cond.false6:                                      ; preds = %cond.end
  %6 = load i32* %numElements.addr, align 4, !dbg !296
  %div7 = udiv i32 %6, 512, !dbg !296
  %add8 = add i32 %div7, 1, !dbg !296
  br label %cond.end9, !dbg !296

cond.end9:                                        ; preds = %cond.false6, %cond.true4
  %cond10 = phi i32 [ %div5, %cond.true4 ], [ %add8, %cond.false6 ], !dbg !296
  store i32 %cond10, i32* %numBlocks2, align 4, !dbg !296
  call void @llvm.dbg.declare(metadata !8, metadata !297), !dbg !298
  %7 = load i32* %numBlocks, align 4, !dbg !299
  %cmp11 = icmp ugt i32 %7, 65535, !dbg !299
  %frombool12 = zext i1 %cmp11 to i8, !dbg !299
  store i8 %frombool12, i8* %loop, align 1, !dbg !299
  call void @llvm.dbg.declare(metadata !8, metadata !300), !dbg !301
  %8 = load i32* %numBlocks2, align 4, !dbg !302
  %cmp13 = icmp ugt i32 %8, 65535, !dbg !302
  %frombool14 = zext i1 %cmp13 to i8, !dbg !302
  store i8 %frombool14, i8* %loop2, align 1, !dbg !302
  call void @llvm.dbg.declare(metadata !8, metadata !303), !dbg !304
  %9 = load i8* %loop, align 1, !dbg !305
  %tobool15 = trunc i8 %9 to i1, !dbg !305
  br i1 %tobool15, label %cond.true16, label %cond.false17, !dbg !305

cond.true16:                                      ; preds = %cond.end9
  br label %cond.end18, !dbg !305

cond.false17:                                     ; preds = %cond.end9
  %10 = load i32* %numBlocks, align 4, !dbg !305
  br label %cond.end18, !dbg !305

cond.end18:                                       ; preds = %cond.false17, %cond.true16
  %cond19 = phi i32 [ 65535, %cond.true16 ], [ %10, %cond.false17 ], !dbg !305
  store i32 %cond19, i32* %blocks, align 4, !dbg !305
  call void @llvm.dbg.declare(metadata !8, metadata !306), !dbg !307
  %11 = load i8* %loop2, align 1, !dbg !308
  %tobool20 = trunc i8 %11 to i1, !dbg !308
  br i1 %tobool20, label %cond.true21, label %cond.false22, !dbg !308

cond.true21:                                      ; preds = %cond.end18
  br label %cond.end23, !dbg !308

cond.false22:                                     ; preds = %cond.end18
  %12 = load i32* %numBlocks2, align 4, !dbg !308
  br label %cond.end23, !dbg !308

cond.end23:                                       ; preds = %cond.false22, %cond.true21
  %cond24 = phi i32 [ 65535, %cond.true21 ], [ %12, %cond.false22 ], !dbg !308
  store i32 %cond24, i32* %blocksFind, align 4, !dbg !308
  call void @llvm.dbg.declare(metadata !8, metadata !309), !dbg !310
  %13 = load i8* %loop2, align 1, !dbg !311
  %tobool25 = trunc i8 %13 to i1, !dbg !311
  br i1 %tobool25, label %cond.true26, label %cond.false27, !dbg !311

cond.true26:                                      ; preds = %cond.end23
  br label %cond.end28, !dbg !311

cond.false27:                                     ; preds = %cond.end23
  %14 = load i32* %numBlocks2, align 4, !dbg !311
  br label %cond.end28, !dbg !311

cond.end28:                                       ; preds = %cond.false27, %cond.true26
  %cond29 = phi i32 [ 65535, %cond.true26 ], [ %14, %cond.false27 ], !dbg !311
  store i32 %cond29, i32* %blocksReorder, align 4, !dbg !311
  %15 = load i8* %fullBlocks, align 1, !dbg !312
  %tobool30 = trunc i8 %15 to i1, !dbg !312
  br i1 %tobool30, label %if.then, label %if.else41, !dbg !312

if.then:                                          ; preds = %cond.end28
  %16 = load i8* %loop, align 1, !dbg !313
  %tobool31 = trunc i8 %16 to i1, !dbg !313
  br i1 %tobool31, label %if.then32, label %if.else, !dbg !313

if.then32:                                        ; preds = %if.then
  %17 = load i32* %blocks, align 4, !dbg !315
  call void @_ZN4dim3C1Ejjj(%struct.dim3* %agg.tmp, i32 %17, i32 1, i32 1), !dbg !315
  %18 = load i32* %numElements.addr, align 4, !dbg !315
  call void @_ZN4dim3C1Ejjj(%struct.dim3* %agg.tmp33, i32 %18, i32 1, i32 1), !dbg !315
  %19 = bitcast %struct.dim3* %agg.tmp to { i64, i32 }*, !dbg !315
  %20 = getelementptr { i64, i32 }* %19, i32 0, i32 0, !dbg !315
  %21 = load i64* %20, align 1, !dbg !315
  %22 = getelementptr { i64, i32 }* %19, i32 0, i32 1, !dbg !315
  %23 = load i32* %22, align 1, !dbg !315
  %24 = bitcast %struct.dim3* %agg.tmp33 to { i64, i32 }*, !dbg !315
  %25 = getelementptr { i64, i32 }* %24, i32 0, i32 0, !dbg !315
  %26 = load i64* %25, align 1, !dbg !315
  %27 = getelementptr { i64, i32 }* %24, i32 0, i32 1, !dbg !315
  %28 = load i32* %27, align 1, !dbg !315
  %call = call i32 @cudaConfigureCall(i64 %21, i32 %23, i64 %26, i32 %28, i64 0, %struct.CUstream_st* null), !dbg !315
  %tobool34 = icmp ne i32 %call, 0, !dbg !315
  br i1 %tobool34, label %kcall.end, label %kcall.configok, !dbg !315

kcall.configok:                                   ; preds = %if.then32
  %29 = load i32** %tempKeys.addr, align 8, !dbg !315
  %30 = bitcast i32* %29 to %struct.uint4*, !dbg !315
  %31 = load i32** %keys.addr, align 8, !dbg !315
  %32 = bitcast i32* %31 to %struct.uint4*, !dbg !315
  %33 = load i32* %numElements.addr, align 4, !dbg !315
  %34 = load i32* %numBlocks, align 4, !dbg !315
  call void @_Z23radixSortBlocksKeysOnlyILj4ELj0ELb1ELb0ELb1EEvP5uint4S1_jj(%struct.uint4* %30, %struct.uint4* %32, i32 %33, i32 %34), !dbg !315
  br label %kcall.end, !dbg !315

kcall.end:                                        ; preds = %kcall.configok, %if.then32
  br label %if.end, !dbg !315

if.else:                                          ; preds = %if.then
  %35 = load i32* %blocks, align 4, !dbg !316
  call void @_ZN4dim3C1Ejjj(%struct.dim3* %agg.tmp35, i32 %35, i32 1, i32 1), !dbg !316
  %36 = load i32* %numElements.addr, align 4, !dbg !316
  call void @_ZN4dim3C1Ejjj(%struct.dim3* %agg.tmp36, i32 %36, i32 1, i32 1), !dbg !316
  %37 = bitcast %struct.dim3* %agg.tmp35 to { i64, i32 }*, !dbg !316
  %38 = getelementptr { i64, i32 }* %37, i32 0, i32 0, !dbg !316
  %39 = load i64* %38, align 1, !dbg !316
  %40 = getelementptr { i64, i32 }* %37, i32 0, i32 1, !dbg !316
  %41 = load i32* %40, align 1, !dbg !316
  %42 = bitcast %struct.dim3* %agg.tmp36 to { i64, i32 }*, !dbg !316
  %43 = getelementptr { i64, i32 }* %42, i32 0, i32 0, !dbg !316
  %44 = load i64* %43, align 1, !dbg !316
  %45 = getelementptr { i64, i32 }* %42, i32 0, i32 1, !dbg !316
  %46 = load i32* %45, align 1, !dbg !316
  %call37 = call i32 @cudaConfigureCall(i64 %39, i32 %41, i64 %44, i32 %46, i64 0, %struct.CUstream_st* null), !dbg !316
  %tobool38 = icmp ne i32 %call37, 0, !dbg !316
  br i1 %tobool38, label %kcall.end40, label %kcall.configok39, !dbg !316

kcall.configok39:                                 ; preds = %if.else
  %47 = load i32** %tempKeys.addr, align 8, !dbg !316
  %48 = bitcast i32* %47 to %struct.uint4*, !dbg !316
  %49 = load i32** %keys.addr, align 8, !dbg !316
  %50 = bitcast i32* %49 to %struct.uint4*, !dbg !316
  %51 = load i32* %numElements.addr, align 4, !dbg !316
  %52 = load i32* %numBlocks, align 4, !dbg !316
  call void @_Z23radixSortBlocksKeysOnlyILj4ELj0ELb1ELb0ELb0EEvP5uint4S1_jj(%struct.uint4* %48, %struct.uint4* %50, i32 %51, i32 %52), !dbg !316
  br label %kcall.end40, !dbg !316

kcall.end40:                                      ; preds = %kcall.configok39, %if.else
  br label %if.end

if.end:                                           ; preds = %kcall.end40, %kcall.end
  br label %if.end58, !dbg !317

if.else41:                                        ; preds = %cond.end28
  %53 = load i8* %loop, align 1, !dbg !318
  %tobool42 = trunc i8 %53 to i1, !dbg !318
  br i1 %tobool42, label %if.then43, label %if.else50, !dbg !318

if.then43:                                        ; preds = %if.else41
  %54 = load i32* %blocks, align 4, !dbg !320
  call void @_ZN4dim3C1Ejjj(%struct.dim3* %agg.tmp44, i32 %54, i32 1, i32 1), !dbg !320
  %55 = load i32* %numElements.addr, align 4, !dbg !320
  call void @_ZN4dim3C1Ejjj(%struct.dim3* %agg.tmp45, i32 %55, i32 1, i32 1), !dbg !320
  %56 = bitcast %struct.dim3* %agg.tmp44 to { i64, i32 }*, !dbg !320
  %57 = getelementptr { i64, i32 }* %56, i32 0, i32 0, !dbg !320
  %58 = load i64* %57, align 1, !dbg !320
  %59 = getelementptr { i64, i32 }* %56, i32 0, i32 1, !dbg !320
  %60 = load i32* %59, align 1, !dbg !320
  %61 = bitcast %struct.dim3* %agg.tmp45 to { i64, i32 }*, !dbg !320
  %62 = getelementptr { i64, i32 }* %61, i32 0, i32 0, !dbg !320
  %63 = load i64* %62, align 1, !dbg !320
  %64 = getelementptr { i64, i32 }* %61, i32 0, i32 1, !dbg !320
  %65 = load i32* %64, align 1, !dbg !320
  %call46 = call i32 @cudaConfigureCall(i64 %58, i32 %60, i64 %63, i32 %65, i64 0, %struct.CUstream_st* null), !dbg !320
  %tobool47 = icmp ne i32 %call46, 0, !dbg !320
  br i1 %tobool47, label %kcall.end49, label %kcall.configok48, !dbg !320

kcall.configok48:                                 ; preds = %if.then43
  %66 = load i32** %tempKeys.addr, align 8, !dbg !320
  %67 = bitcast i32* %66 to %struct.uint4*, !dbg !320
  %68 = load i32** %keys.addr, align 8, !dbg !320
  %69 = bitcast i32* %68 to %struct.uint4*, !dbg !320
  %70 = load i32* %numElements.addr, align 4, !dbg !320
  %71 = load i32* %numBlocks, align 4, !dbg !320
  call void @_Z23radixSortBlocksKeysOnlyILj4ELj0ELb0ELb0ELb1EEvP5uint4S1_jj(%struct.uint4* %67, %struct.uint4* %69, i32 %70, i32 %71), !dbg !320
  br label %kcall.end49, !dbg !320

kcall.end49:                                      ; preds = %kcall.configok48, %if.then43
  br label %if.end57, !dbg !320

if.else50:                                        ; preds = %if.else41
  %72 = load i32* %blocks, align 4, !dbg !321
  call void @_ZN4dim3C1Ejjj(%struct.dim3* %agg.tmp51, i32 %72, i32 1, i32 1), !dbg !321
  %73 = load i32* %numElements.addr, align 4, !dbg !321
  call void @_ZN4dim3C1Ejjj(%struct.dim3* %agg.tmp52, i32 %73, i32 1, i32 1), !dbg !321
  %74 = bitcast %struct.dim3* %agg.tmp51 to { i64, i32 }*, !dbg !321
  %75 = getelementptr { i64, i32 }* %74, i32 0, i32 0, !dbg !321
  %76 = load i64* %75, align 1, !dbg !321
  %77 = getelementptr { i64, i32 }* %74, i32 0, i32 1, !dbg !321
  %78 = load i32* %77, align 1, !dbg !321
  %79 = bitcast %struct.dim3* %agg.tmp52 to { i64, i32 }*, !dbg !321
  %80 = getelementptr { i64, i32 }* %79, i32 0, i32 0, !dbg !321
  %81 = load i64* %80, align 1, !dbg !321
  %82 = getelementptr { i64, i32 }* %79, i32 0, i32 1, !dbg !321
  %83 = load i32* %82, align 1, !dbg !321
  %call53 = call i32 @cudaConfigureCall(i64 %76, i32 %78, i64 %81, i32 %83, i64 0, %struct.CUstream_st* null), !dbg !321
  %tobool54 = icmp ne i32 %call53, 0, !dbg !321
  br i1 %tobool54, label %kcall.end56, label %kcall.configok55, !dbg !321

kcall.configok55:                                 ; preds = %if.else50
  %84 = load i32** %tempKeys.addr, align 8, !dbg !321
  %85 = bitcast i32* %84 to %struct.uint4*, !dbg !321
  %86 = load i32** %keys.addr, align 8, !dbg !321
  %87 = bitcast i32* %86 to %struct.uint4*, !dbg !321
  %88 = load i32* %numElements.addr, align 4, !dbg !321
  %89 = load i32* %numBlocks, align 4, !dbg !321
  call void @_Z23radixSortBlocksKeysOnlyILj4ELj0ELb0ELb0ELb0EEvP5uint4S1_jj(%struct.uint4* %85, %struct.uint4* %87, i32 %88, i32 %89), !dbg !321
  br label %kcall.end56, !dbg !321

kcall.end56:                                      ; preds = %kcall.configok55, %if.else50
  br label %if.end57

if.end57:                                         ; preds = %kcall.end56, %kcall.end49
  br label %if.end58

if.end58:                                         ; preds = %if.end57, %if.end
  ret void, !dbg !322
}

define i32 @main() uwtable {
entry:
  %retval = alloca i32, align 4
  %maxElements = alloca i32, align 4
  %numElements = alloca i32, align 4
  %keyBits = alloca i32, align 4
  %keys = alloca [16 x i32], align 16
  %RS = alloca %class.RadixSort, align 8
  %i = alloca i32, align 4
  store i32 0, i32* %retval
  call void @llvm.dbg.declare(metadata !8, metadata !323), !dbg !325
  store i32 32, i32* %maxElements, align 4, !dbg !326
  call void @llvm.dbg.declare(metadata !8, metadata !327), !dbg !328
  store i32 16, i32* %numElements, align 4, !dbg !329
  call void @llvm.dbg.declare(metadata !8, metadata !330), !dbg !331
  store i32 16, i32* %keyBits, align 4, !dbg !332
  call void @llvm.dbg.declare(metadata !8, metadata !333), !dbg !337
  call void @llvm.dbg.declare(metadata !8, metadata !338), !dbg !339
  call void @_ZN9RadixSortC1Ejb(%class.RadixSort* %RS, i32 32, i1 zeroext true), !dbg !340
  %arraydecay = getelementptr inbounds [16 x i32]* %keys, i32 0, i32 0, !dbg !341
  %0 = load i32* %keyBits, align 4, !dbg !341
  call void @_ZN9RadixSort4sortEPjS0_jj(%class.RadixSort* %RS, i32* %arraydecay, i32* null, i32 16, i32 %0), !dbg !341
  call void @llvm.dbg.declare(metadata !8, metadata !342), !dbg !344
  store i32 1, i32* %i, align 4, !dbg !345
  br label %for.cond, !dbg !345

for.cond:                                         ; preds = %for.inc, %entry
  %1 = load i32* %i, align 4, !dbg !345
  %cmp = icmp ult i32 %1, 16, !dbg !345
  br i1 %cmp, label %for.body, label %for.end, !dbg !345

for.body:                                         ; preds = %for.cond
  %2 = load i32* %i, align 4, !dbg !346
  %idxprom = sext i32 %2 to i64, !dbg !346
  %arrayidx = getelementptr inbounds [16 x i32]* %keys, i32 0, i64 %idxprom, !dbg !346
  %3 = load i32* %arrayidx, align 4, !dbg !346
  %4 = load i32* %i, align 4, !dbg !346
  %sub = sub nsw i32 %4, 1, !dbg !346
  %idxprom1 = sext i32 %sub to i64, !dbg !346
  %arrayidx2 = getelementptr inbounds [16 x i32]* %keys, i32 0, i64 %idxprom1, !dbg !346
  %5 = load i32* %arrayidx2, align 4, !dbg !346
  %cmp3 = icmp ult i32 %3, %5, !dbg !346
  br i1 %cmp3, label %if.then, label %if.end, !dbg !346

if.then:                                          ; preds = %for.body
  %6 = load i32* %i, align 4, !dbg !348
  %7 = load i32* %i, align 4, !dbg !348
  %sub4 = sub nsw i32 %7, 1, !dbg !348
  %call = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([62 x i8]* @.str, i32 0, i32 0), i32 %6, i32 %sub4), !dbg !348
  store i32 1, i32* %retval, !dbg !350
  br label %for.end, !dbg !350

if.end:                                           ; preds = %for.body
  br label %for.inc, !dbg !351

for.inc:                                          ; preds = %if.end
  %8 = load i32* %i, align 4, !dbg !352
  %inc = add nsw i32 %8, 1, !dbg !352
  store i32 %inc, i32* %i, align 4, !dbg !352
  br label %for.cond, !dbg !352

for.end:                                          ; preds = %if.then, %for.cond
  %9 = load i32* %retval, !dbg !353
  ret i32 %9, !dbg !353
}

define linkonce_odr void @_ZN9RadixSortC1Ejb(%class.RadixSort* %this, i32 %maxElements, i1 zeroext %keysOnly) unnamed_addr uwtable align 2 {
entry:
  %this.addr = alloca %class.RadixSort*, align 8
  %maxElements.addr = alloca i32, align 4
  %keysOnly.addr = alloca i8, align 1
  store %class.RadixSort* %this, %class.RadixSort** %this.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !354), !dbg !356
  store i32 %maxElements, i32* %maxElements.addr, align 4
  call void @llvm.dbg.declare(metadata !8, metadata !357), !dbg !358
  %frombool = zext i1 %keysOnly to i8
  store i8 %frombool, i8* %keysOnly.addr, align 1
  call void @llvm.dbg.declare(metadata !8, metadata !359), !dbg !360
  %this1 = load %class.RadixSort** %this.addr
  %0 = load i32* %maxElements.addr, align 4, !dbg !361
  %1 = load i8* %keysOnly.addr, align 1, !dbg !361
  %tobool = trunc i8 %1 to i1, !dbg !361
  call void @_ZN9RadixSortC2Ejb(%class.RadixSort* %this1, i32 %0, i1 zeroext %tobool), !dbg !361
  ret void, !dbg !361
}

define linkonce_odr void @_ZN9RadixSort4sortEPjS0_jj(%class.RadixSort* %this, i32* %keys, i32* %values, i32 %numElements, i32 %keyBits) uwtable align 2 {
entry:
  %this.addr = alloca %class.RadixSort*, align 8
  %keys.addr = alloca i32*, align 8
  %values.addr = alloca i32*, align 8
  %numElements.addr = alloca i32, align 4
  %keyBits.addr = alloca i32, align 4
  %agg.tmp = alloca %struct.CUDPPHandle, align 1
  store %class.RadixSort* %this, %class.RadixSort** %this.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !362), !dbg !363
  store i32* %keys, i32** %keys.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !364), !dbg !365
  store i32* %values, i32** %values.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !366), !dbg !367
  store i32 %numElements, i32* %numElements.addr, align 4
  call void @llvm.dbg.declare(metadata !8, metadata !368), !dbg !369
  store i32 %keyBits, i32* %keyBits.addr, align 4
  call void @llvm.dbg.declare(metadata !8, metadata !370), !dbg !371
  %this1 = load %class.RadixSort** %this.addr
  %0 = load i32** %values.addr, align 8, !dbg !372
  %cmp = icmp eq i32* %0, null, !dbg !372
  br i1 %cmp, label %if.then, label %if.end, !dbg !372

if.then:                                          ; preds = %entry
  %1 = load i32** %keys.addr, align 8, !dbg !374
  %mTempKeys = getelementptr inbounds %class.RadixSort* %this1, i32 0, i32 2, !dbg !374
  %2 = load i32** %mTempKeys, align 8, !dbg !374
  %mCounters = getelementptr inbounds %class.RadixSort* %this1, i32 0, i32 4, !dbg !374
  %3 = load i32** %mCounters, align 8, !dbg !374
  %mCountersSum = getelementptr inbounds %class.RadixSort* %this1, i32 0, i32 5, !dbg !374
  %4 = load i32** %mCountersSum, align 8, !dbg !374
  %mBlockOffsets = getelementptr inbounds %class.RadixSort* %this1, i32 0, i32 6, !dbg !374
  %5 = load i32** %mBlockOffsets, align 8, !dbg !374
  %mScanPlan = getelementptr inbounds %class.RadixSort* %this1, i32 0, i32 0, !dbg !374
  %6 = load i32* %numElements.addr, align 4, !dbg !374
  %7 = load i32* %keyBits.addr, align 4, !dbg !374
  call void @radixSortKeysOnly(i32* %1, i32* %2, i32* %3, i32* %4, i32* %5, i32 %6, i32 %7, i1 zeroext false), !dbg !374
  br label %if.end, !dbg !376

if.end:                                           ; preds = %if.then, %entry
  ret void, !dbg !377
}

declare i32 @printf(i8*, ...)

declare i32 @cudaConfigureCall(i64, i32, i64, i32, i64, %struct.CUstream_st*)

define linkonce_odr void @_ZN9RadixSortC2Ejb(%class.RadixSort* %this, i32 %maxElements, i1 zeroext %keysOnly) unnamed_addr uwtable align 2 {
entry:
  %this.addr = alloca %class.RadixSort*, align 8
  %maxElements.addr = alloca i32, align 4
  %keysOnly.addr = alloca i8, align 1
  store %class.RadixSort* %this, %class.RadixSort** %this.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !378), !dbg !379
  store i32 %maxElements, i32* %maxElements.addr, align 4
  call void @llvm.dbg.declare(metadata !8, metadata !380), !dbg !381
  %frombool = zext i1 %keysOnly to i8
  store i8 %frombool, i8* %keysOnly.addr, align 1
  call void @llvm.dbg.declare(metadata !8, metadata !382), !dbg !383
  %this1 = load %class.RadixSort** %this.addr
  %mScanPlan = getelementptr inbounds %class.RadixSort* %this1, i32 0, i32 0, !dbg !384
  call void @_ZN11CUDPPHandleC1EPv(%struct.CUDPPHandle* %mScanPlan, i8* null), !dbg !384
  %mNumElements = getelementptr inbounds %class.RadixSort* %this1, i32 0, i32 1, !dbg !384
  store i32 0, i32* %mNumElements, align 4, !dbg !384
  %mTempKeys = getelementptr inbounds %class.RadixSort* %this1, i32 0, i32 2, !dbg !384
  store i32* null, i32** %mTempKeys, align 8, !dbg !384
  %mTempValues = getelementptr inbounds %class.RadixSort* %this1, i32 0, i32 3, !dbg !384
  store i32* null, i32** %mTempValues, align 8, !dbg !384
  %mCounters = getelementptr inbounds %class.RadixSort* %this1, i32 0, i32 4, !dbg !384
  store i32* null, i32** %mCounters, align 8, !dbg !384
  %mCountersSum = getelementptr inbounds %class.RadixSort* %this1, i32 0, i32 5, !dbg !384
  store i32* null, i32** %mCountersSum, align 8, !dbg !384
  %mBlockOffsets = getelementptr inbounds %class.RadixSort* %this1, i32 0, i32 6, !dbg !384
  store i32* null, i32** %mBlockOffsets, align 8, !dbg !384
  %0 = load i32* %maxElements.addr, align 4, !dbg !385
  %1 = load i8* %keysOnly.addr, align 1, !dbg !385
  %tobool = trunc i8 %1 to i1, !dbg !385
  call void @_ZN9RadixSort10initializeEjb(%class.RadixSort* %this1, i32 %0, i1 zeroext %tobool), !dbg !385
  ret void, !dbg !387
}

define linkonce_odr void @_ZN11CUDPPHandleC1EPv(%struct.CUDPPHandle* %this, i8* %c) unnamed_addr uwtable align 2 {
entry:
  %this.addr = alloca %struct.CUDPPHandle*, align 8
  %c.addr = alloca i8*, align 8
  store %struct.CUDPPHandle* %this, %struct.CUDPPHandle** %this.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !388), !dbg !390
  store i8* %c, i8** %c.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !391), !dbg !392
  %this1 = load %struct.CUDPPHandle** %this.addr
  %0 = load i8** %c.addr, align 8, !dbg !393
  call void @_ZN11CUDPPHandleC2EPv(%struct.CUDPPHandle* %this1, i8* %0), !dbg !393
  ret void, !dbg !393
}

define linkonce_odr void @_ZN9RadixSort10initializeEjb(%class.RadixSort* %this, i32 %numElements, i1 zeroext %keysOnly) uwtable align 2 {
entry:
  %this.addr = alloca %class.RadixSort*, align 8
  %numElements.addr = alloca i32, align 4
  %keysOnly.addr = alloca i8, align 1
  %numBlocks = alloca i32, align 4
  %numBlocks2 = alloca i32, align 4
  store %class.RadixSort* %this, %class.RadixSort** %this.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !394), !dbg !395
  store i32 %numElements, i32* %numElements.addr, align 4
  call void @llvm.dbg.declare(metadata !8, metadata !396), !dbg !397
  %frombool = zext i1 %keysOnly to i8
  store i8 %frombool, i8* %keysOnly.addr, align 1
  call void @llvm.dbg.declare(metadata !8, metadata !398), !dbg !399
  %this1 = load %class.RadixSort** %this.addr
  %0 = load i32* %numElements.addr, align 4, !dbg !400
  %mNumElements = getelementptr inbounds %class.RadixSort* %this1, i32 0, i32 1, !dbg !400
  store i32 %0, i32* %mNumElements, align 4, !dbg !400
  call void @llvm.dbg.declare(metadata !8, metadata !402), !dbg !403
  %1 = load i32* %numElements.addr, align 4, !dbg !404
  %rem = urem i32 %1, 1024, !dbg !404
  %cmp = icmp eq i32 %rem, 0, !dbg !404
  br i1 %cmp, label %cond.true, label %cond.false, !dbg !404

cond.true:                                        ; preds = %entry
  %2 = load i32* %numElements.addr, align 4, !dbg !404
  %div = udiv i32 %2, 1024, !dbg !404
  br label %cond.end, !dbg !404

cond.false:                                       ; preds = %entry
  %3 = load i32* %numElements.addr, align 4, !dbg !404
  %div2 = udiv i32 %3, 1024, !dbg !404
  %add = add i32 %div2, 1, !dbg !404
  br label %cond.end, !dbg !404

cond.end:                                         ; preds = %cond.false, %cond.true
  %cond = phi i32 [ %div, %cond.true ], [ %add, %cond.false ], !dbg !404
  store i32 %cond, i32* %numBlocks, align 4, !dbg !404
  call void @llvm.dbg.declare(metadata !8, metadata !405), !dbg !406
  %4 = load i32* %numElements.addr, align 4, !dbg !407
  %rem3 = urem i32 %4, 512, !dbg !407
  %cmp4 = icmp eq i32 %rem3, 0, !dbg !407
  br i1 %cmp4, label %cond.true5, label %cond.false7, !dbg !407

cond.true5:                                       ; preds = %cond.end
  %5 = load i32* %numElements.addr, align 4, !dbg !407
  %div6 = udiv i32 %5, 512, !dbg !407
  br label %cond.end10, !dbg !407

cond.false7:                                      ; preds = %cond.end
  %6 = load i32* %numElements.addr, align 4, !dbg !407
  %div8 = udiv i32 %6, 512, !dbg !407
  %add9 = add i32 %div8, 1, !dbg !407
  br label %cond.end10, !dbg !407

cond.end10:                                       ; preds = %cond.false7, %cond.true5
  %cond11 = phi i32 [ %div6, %cond.true5 ], [ %add9, %cond.false7 ], !dbg !407
  store i32 %cond11, i32* %numBlocks2, align 4, !dbg !407
  %mTempKeys = getelementptr inbounds %class.RadixSort* %this1, i32 0, i32 2, !dbg !408
  %7 = bitcast i32** %mTempKeys to i8**, !dbg !408
  %8 = load i32* %numElements.addr, align 4, !dbg !408
  %conv = zext i32 %8 to i64, !dbg !408
  %mul = mul i64 %conv, 4, !dbg !408
  %call = call i32 @cudaMalloc(i8** %7, i64 %mul), !dbg !408
  %9 = load i8* %keysOnly.addr, align 1, !dbg !409
  %tobool = trunc i8 %9 to i1, !dbg !409
  br i1 %tobool, label %if.end, label %if.then, !dbg !409

if.then:                                          ; preds = %cond.end10
  %mTempValues = getelementptr inbounds %class.RadixSort* %this1, i32 0, i32 3, !dbg !410
  %10 = bitcast i32** %mTempValues to i8**, !dbg !410
  %11 = load i32* %numElements.addr, align 4, !dbg !410
  %conv12 = zext i32 %11 to i64, !dbg !410
  %mul13 = mul i64 %conv12, 4, !dbg !410
  %call14 = call i32 @cudaMalloc(i8** %10, i64 %mul13), !dbg !410
  br label %if.end, !dbg !410

if.end:                                           ; preds = %if.then, %cond.end10
  %mCounters = getelementptr inbounds %class.RadixSort* %this1, i32 0, i32 4, !dbg !411
  %12 = bitcast i32** %mCounters to i8**, !dbg !411
  %13 = load i32* %numBlocks, align 4, !dbg !411
  %mul15 = mul i32 32, %13, !dbg !411
  %conv16 = zext i32 %mul15 to i64, !dbg !411
  %mul17 = mul i64 %conv16, 4, !dbg !411
  %call18 = call i32 @cudaMalloc(i8** %12, i64 %mul17), !dbg !411
  %mCountersSum = getelementptr inbounds %class.RadixSort* %this1, i32 0, i32 5, !dbg !412
  %14 = bitcast i32** %mCountersSum to i8**, !dbg !412
  %15 = load i32* %numBlocks, align 4, !dbg !412
  %mul19 = mul i32 32, %15, !dbg !412
  %conv20 = zext i32 %mul19 to i64, !dbg !412
  %mul21 = mul i64 %conv20, 4, !dbg !412
  %call22 = call i32 @cudaMalloc(i8** %14, i64 %mul21), !dbg !412
  %mBlockOffsets = getelementptr inbounds %class.RadixSort* %this1, i32 0, i32 6, !dbg !413
  %16 = bitcast i32** %mBlockOffsets to i8**, !dbg !413
  %17 = load i32* %numBlocks, align 4, !dbg !413
  %mul23 = mul i32 32, %17, !dbg !413
  %conv24 = zext i32 %mul23 to i64, !dbg !413
  %mul25 = mul i64 %conv24, 4, !dbg !413
  %call26 = call i32 @cudaMalloc(i8** %16, i64 %mul25), !dbg !413
  call void @checkCudaError(i8* getelementptr inbounds ([24 x i8]* @.str4, i32 0, i32 0)), !dbg !414
  ret void, !dbg !415
}

declare i32 @cudaMalloc(i8**, i64)

define linkonce_odr void @_ZN11CUDPPHandleC2EPv(%struct.CUDPPHandle* %this, i8* %c) unnamed_addr nounwind uwtable align 2 {
entry:
  %this.addr = alloca %struct.CUDPPHandle*, align 8
  %c.addr = alloca i8*, align 8
  store %struct.CUDPPHandle* %this, %struct.CUDPPHandle** %this.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !416), !dbg !417
  store i8* %c, i8** %c.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !418), !dbg !419
  %this1 = load %struct.CUDPPHandle** %this.addr
  ret void, !dbg !420
}

define linkonce_odr void @_ZN4dim3C2Ejjj(%struct.dim3* %this, i32 %vx, i32 %vy, i32 %vz) unnamed_addr nounwind uwtable section "__device__" align 2 {
entry:
  %this.addr = alloca %struct.dim3*, align 8
  %vx.addr = alloca i32, align 4
  %vy.addr = alloca i32, align 4
  %vz.addr = alloca i32, align 4
  store %struct.dim3* %this, %struct.dim3** %this.addr, align 8
  call void @llvm.dbg.declare(metadata !8, metadata !422), !dbg !423
  store i32 %vx, i32* %vx.addr, align 4
  call void @llvm.dbg.declare(metadata !8, metadata !424), !dbg !425
  store i32 %vy, i32* %vy.addr, align 4
  call void @llvm.dbg.declare(metadata !8, metadata !426), !dbg !427
  store i32 %vz, i32* %vz.addr, align 4
  call void @llvm.dbg.declare(metadata !8, metadata !428), !dbg !429
  %this1 = load %struct.dim3** %this.addr
  %x = getelementptr inbounds %struct.dim3* %this1, i32 0, i32 0, !dbg !430
  %0 = load i32* %vx.addr, align 4, !dbg !430
  store i32 %0, i32* %x, align 4, !dbg !430
  %y = getelementptr inbounds %struct.dim3* %this1, i32 0, i32 1, !dbg !430
  %1 = load i32* %vy.addr, align 4, !dbg !430
  store i32 %1, i32* %y, align 4, !dbg !430
  %z = getelementptr inbounds %struct.dim3* %this1, i32 0, i32 2, !dbg !430
  %2 = load i32* %vz.addr, align 4, !dbg !430
  store i32 %2, i32* %z, align 4, !dbg !430
  ret void, !dbg !431
}

define internal void @_GLOBAL__I_a() section ".text.startup" {
entry:
  call void @__cxx_global_var_init()
  call void @__cxx_global_var_init1()
  call void @__cxx_global_var_init2()
  call void @__cxx_global_var_init3()
  ret void
}

!llvm.dbg.cu = !{!0}

!0 = metadata !{i32 786449, i32 0, i32 4, metadata !"radixsort.cu", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Race/RaceSort", metadata !"clang version 3.2 (trunk 164283)", i1 true, i1 false, metadata !"", i32 0, metadata !1, metadata !1, metadata !3, metadata !137} ; [ DW_TAG_compile_unit ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Race/RaceSort/radixsort.cu] [DW_LANG_C_plus_plus]
!1 = metadata !{metadata !2}
!2 = metadata !{i32 0}
!3 = metadata !{metadata !4}
!4 = metadata !{metadata !5, metadata !9, metadata !10, metadata !11, metadata !12, metadata !14, metadata !20, metadata !26, metadata !27, metadata !41, metadata !45, metadata !53, metadata !68, metadata !71, metadata !74, metadata !76, metadata !79, metadata !81, metadata !83, metadata !85, metadata !87, metadata !109, metadata !110, metadata !111, metadata !112, metadata !113, metadata !114, metadata !136}
!5 = metadata !{i32 786478, i32 0, metadata !6, metadata !"__cxx_global_var_init", metadata !"__cxx_global_var_init", metadata !"", metadata !6, i32 26, metadata !7, i1 true, i1 true, i32 0, i32 0, null, i32 256, i1 false, void ()* @__cxx_global_var_init, null, null, metadata !1, i32 26} ; [ DW_TAG_subprogram ] [line 26] [local] [def] [__cxx_global_var_init]
!6 = metadata !{i32 786473, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/include/klee/gklee.h", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Race/RaceSort", null} ; [ DW_TAG_file_type ]
!7 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !8, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!8 = metadata !{null}
!9 = metadata !{i32 786478, i32 0, metadata !6, metadata !"__cxx_global_var_init1", metadata !"__cxx_global_var_init1", metadata !"", metadata !6, i32 27, metadata !7, i1 true, i1 true, i32 0, i32 0, null, i32 256, i1 false, void ()* @__cxx_global_var_init1, null, null, metadata !1, i32 27} ; [ DW_TAG_subprogram ] [line 27] [local] [def] [__cxx_global_var_init1]
!10 = metadata !{i32 786478, i32 0, metadata !6, metadata !"__cxx_global_var_init2", metadata !"__cxx_global_var_init2", metadata !"", metadata !6, i32 28, metadata !7, i1 true, i1 true, i32 0, i32 0, null, i32 256, i1 false, void ()* @__cxx_global_var_init2, null, null, metadata !1, i32 28} ; [ DW_TAG_subprogram ] [line 28] [local] [def] [__cxx_global_var_init2]
!11 = metadata !{i32 786478, i32 0, metadata !6, metadata !"__cxx_global_var_init3", metadata !"__cxx_global_var_init3", metadata !"", metadata !6, i32 29, metadata !7, i1 true, i1 true, i32 0, i32 0, null, i32 256, i1 false, void ()* @__cxx_global_var_init3, null, null, metadata !1, i32 29} ; [ DW_TAG_subprogram ] [line 29] [local] [def] [__cxx_global_var_init3]
!12 = metadata !{i32 786478, i32 0, metadata !13, metadata !"initDeviceParameters", metadata !"initDeviceParameters", metadata !"", metadata !13, i32 41, metadata !7, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void ()* @initDeviceParameters, null, null, metadata !1, i32 42} ; [ DW_TAG_subprogram ] [line 41] [def] [scope 42] [initDeviceParameters]
!13 = metadata !{i32 786473, metadata !"radixsort.cu", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Race/RaceSort", null} ; [ DW_TAG_file_type ]
!14 = metadata !{i32 786478, i32 0, metadata !13, metadata !"checkCudaError", metadata !"checkCudaError", metadata !"", metadata !13, i32 109, metadata !15, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (i8*)* @checkCudaError, null, null, metadata !1, i32 110} ; [ DW_TAG_subprogram ] [line 109] [def] [scope 110] [checkCudaError]
!15 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !16, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!16 = metadata !{null, metadata !17}
!17 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !18} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!18 = metadata !{i32 786470, null, metadata !"", null, i32 0, i64 0, i64 0, i64 0, i32 0, metadata !19} ; [ DW_TAG_const_type ] [line 0, size 0, align 0, offset 0] [from char]
!19 = metadata !{i32 786468, null, metadata !"char", null, i32 0, i64 8, i64 8, i64 0, i32 0, i32 6} ; [ DW_TAG_base_type ] [char] [line 0, size 8, align 8, offset 0, enc DW_ATE_signed_char]
!20 = metadata !{i32 786478, i32 0, metadata !13, metadata !"flipFloats", metadata !"flipFloats", metadata !"_Z10flipFloatsPjj", metadata !13, i32 199, metadata !21, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (i32*, i32)* @_Z10flipFloatsPjj, null, null, metadata !1, i32 200} ; [ DW_TAG_subprogram ] [line 199] [def] [scope 200] [flipFloats]
!21 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !22, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!22 = metadata !{null, metadata !23, metadata !24}
!23 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !24} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from uint]
!24 = metadata !{i32 786454, null, metadata !"uint", metadata !13, i32 106, i64 0, i64 0, i64 0, i32 0, metadata !25} ; [ DW_TAG_typedef ] [uint] [line 106, size 0, align 0, offset 0] [from unsigned int]
!25 = metadata !{i32 786468, null, metadata !"unsigned int", null, i32 0, i64 32, i64 32, i64 0, i32 0, i32 7} ; [ DW_TAG_base_type ] [unsigned int] [line 0, size 32, align 32, offset 0, enc DW_ATE_unsigned]
!26 = metadata !{i32 786478, i32 0, metadata !13, metadata !"unflipFloats", metadata !"unflipFloats", metadata !"_Z12unflipFloatsPjj", metadata !13, i32 215, metadata !21, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (i32*, i32)* @_Z12unflipFloatsPjj, null, null, metadata !1, i32 216} ; [ DW_TAG_subprogram ] [line 215] [def] [scope 216] [unflipFloats]
!27 = metadata !{i32 786478, i32 0, metadata !13, metadata !"radixSortKeysOnly", metadata !"radixSortKeysOnly", metadata !"", metadata !13, i32 1017, metadata !28, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (i32*, i32*, i32*, i32*, i32*, i32, i32, i1)* @radixSortKeysOnly, null, null, metadata !1, i32 1026} ; [ DW_TAG_subprogram ] [line 1017] [def] [scope 1026] [radixSortKeysOnly]
!28 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !29, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!29 = metadata !{null, metadata !23, metadata !23, metadata !23, metadata !23, metadata !23, metadata !30, metadata !24, metadata !24, metadata !40}
!30 = metadata !{i32 786434, null, metadata !"CUDPPHandle", metadata !31, i32 25, i64 8, i64 8, i32 0, i32 0, null, metadata !32, i32 0, null, null} ; [ DW_TAG_class_type ] [CUDPPHandle] [line 25, size 8, align 8, offset 0] [from ]
!31 = metadata !{i32 786473, metadata !"./radixsort.h", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Race/RaceSort", null} ; [ DW_TAG_file_type ]
!32 = metadata !{metadata !33}
!33 = metadata !{i32 786478, i32 0, metadata !30, metadata !"CUDPPHandle", metadata !"CUDPPHandle", metadata !"", metadata !31, i32 26, metadata !34, i1 false, i1 false, i32 0, i32 0, null, i32 256, i1 false, null, null, i32 0, metadata !38, i32 26} ; [ DW_TAG_subprogram ] [line 26] [CUDPPHandle]
!34 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !35, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!35 = metadata !{null, metadata !36, metadata !37}
!36 = metadata !{i32 786447, i32 0, metadata !"", i32 0, i32 0, i64 64, i64 64, i64 0, i32 1088, metadata !30} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from CUDPPHandle]
!37 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, null} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from ]
!38 = metadata !{metadata !39}
!39 = metadata !{i32 786468}                      ; [ DW_TAG_base_type ] [line 0, size 0, align 0, offset 0]
!40 = metadata !{i32 786468, null, metadata !"bool", null, i32 0, i64 8, i64 8, i64 0, i32 0, i32 2} ; [ DW_TAG_base_type ] [bool] [line 0, size 8, align 8, offset 0, enc DW_ATE_boolean]
!41 = metadata !{i32 786478, i32 0, metadata !13, metadata !"main", metadata !"main", metadata !"", metadata !13, i32 1119, metadata !42, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, i32 ()* @main, null, null, metadata !1, i32 1119} ; [ DW_TAG_subprogram ] [line 1119] [def] [main]
!42 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !43, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!43 = metadata !{metadata !44}
!44 = metadata !{i32 786468, null, metadata !"int", null, i32 0, i64 32, i64 32, i64 0, i32 0, i32 5} ; [ DW_TAG_base_type ] [int] [line 0, size 32, align 32, offset 0, enc DW_ATE_signed]
!45 = metadata !{i32 786478, i32 0, metadata !13, metadata !"radixSortStepKeysOnly<4, 0, false, false>", metadata !"radixSortStepKeysOnly<4, 0, false, false>", metadata !"_Z21radixSortStepKeysOnlyILj4ELj0ELb0ELb0EEvPjS0_S0_S0_S0_11CUDPPHandlej", metadata !13, i32 765, metadata !46, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (i32*, i32*, i32*, i32*, i32*, i32)* @_Z21radixSortStepKeysOnlyILj4ELj0ELb0ELb0EEvPjS0_S0_S0_S0_11CUDPPHandlej, metadata !48, null, metadata !1, i32 772} ; [ DW_TAG_subprogram ] [line 765] [def] [scope 772] [radixSortStepKeysOnly<4, 0, false, false>]
!46 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !47, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!47 = metadata !{null, metadata !23, metadata !23, metadata !23, metadata !23, metadata !23, metadata !30, metadata !24}
!48 = metadata !{metadata !49, metadata !50, metadata !51, metadata !52}
!49 = metadata !{i32 786480, null, metadata !"nbits", metadata !25, i64 4, null, i32 0, i32 0} ; [ DW_TAG_template_value_parameter ]
!50 = metadata !{i32 786480, null, metadata !"startbit", metadata !25, i64 0, null, i32 0, i32 0} ; [ DW_TAG_template_value_parameter ]
!51 = metadata !{i32 786480, null, metadata !"flip", metadata !40, i64 0, null, i32 0, i32 0} ; [ DW_TAG_template_value_parameter ]
!52 = metadata !{i32 786480, null, metadata !"unflip", metadata !40, i64 0, null, i32 0, i32 0} ; [ DW_TAG_template_value_parameter ]
!53 = metadata !{i32 786478, i32 0, metadata !13, metadata !"radixSortBlocksKeysOnly<4, 0, false, false, false>", metadata !"radixSortBlocksKeysOnly<4, 0, false, false, false>", metadata !"_Z23radixSortBlocksKeysOnlyILj4ELj0ELb0ELb0ELb0EEvP5uint4S1_jj", metadata !13, i32 541, metadata !54, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (%struct.uint4*, %struct.uint4*, i32, i32)* @_Z23radixSortBlocksKeysOnlyILj4ELj0ELb0ELb0ELb0EEvP5uint4S1_jj, metadata !65, null, metadata !1, i32 542} ; [ DW_TAG_subprogram ] [line 541] [def] [scope 542] [radixSortBlocksKeysOnly<4, 0, false, false, false>]
!54 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !55, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!55 = metadata !{null, metadata !56, metadata !56, metadata !24, metadata !24}
!56 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !57} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from uint4]
!57 = metadata !{i32 786454, null, metadata !"uint4", metadata !13, i32 361, i64 0, i64 0, i64 0, i32 0, metadata !58} ; [ DW_TAG_typedef ] [uint4] [line 361, size 0, align 0, offset 0] [from uint4]
!58 = metadata !{i32 786434, null, metadata !"uint4", metadata !59, i32 196, i64 128, i64 128, i32 0, i32 0, null, metadata !60, i32 0, null, null} ; [ DW_TAG_class_type ] [uint4] [line 196, size 128, align 128, offset 0] [from ]
!59 = metadata !{i32 786473, metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/include/cuda/vector_types.h", metadata !"/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Race/RaceSort", null} ; [ DW_TAG_file_type ]
!60 = metadata !{metadata !61, metadata !62, metadata !63, metadata !64}
!61 = metadata !{i32 786445, metadata !58, metadata !"x", metadata !59, i32 198, i64 32, i64 32, i64 0, i32 0, metadata !25} ; [ DW_TAG_member ] [x] [line 198, size 32, align 32, offset 0] [from unsigned int]
!62 = metadata !{i32 786445, metadata !58, metadata !"y", metadata !59, i32 198, i64 32, i64 32, i64 32, i32 0, metadata !25} ; [ DW_TAG_member ] [y] [line 198, size 32, align 32, offset 32] [from unsigned int]
!63 = metadata !{i32 786445, metadata !58, metadata !"z", metadata !59, i32 198, i64 32, i64 32, i64 64, i32 0, metadata !25} ; [ DW_TAG_member ] [z] [line 198, size 32, align 32, offset 64] [from unsigned int]
!64 = metadata !{i32 786445, metadata !58, metadata !"w", metadata !59, i32 198, i64 32, i64 32, i64 96, i32 0, metadata !25} ; [ DW_TAG_member ] [w] [line 198, size 32, align 32, offset 96] [from unsigned int]
!65 = metadata !{metadata !49, metadata !50, metadata !66, metadata !51, metadata !67}
!66 = metadata !{i32 786480, null, metadata !"fullBlocks", metadata !40, i64 0, null, i32 0, i32 0} ; [ DW_TAG_template_value_parameter ]
!67 = metadata !{i32 786480, null, metadata !"loop", metadata !40, i64 0, null, i32 0, i32 0} ; [ DW_TAG_template_value_parameter ]
!68 = metadata !{i32 786478, i32 0, metadata !13, metadata !"radixSortBlocksKeysOnly<4, 0, false, false, true>", metadata !"radixSortBlocksKeysOnly<4, 0, false, false, true>", metadata !"_Z23radixSortBlocksKeysOnlyILj4ELj0ELb0ELb0ELb1EEvP5uint4S1_jj", metadata !13, i32 541, metadata !54, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (%struct.uint4*, %struct.uint4*, i32, i32)* @_Z23radixSortBlocksKeysOnlyILj4ELj0ELb0ELb0ELb1EEvP5uint4S1_jj, metadata !69, null, metadata !1, i32 542} ; [ DW_TAG_subprogram ] [line 541] [def] [scope 542] [radixSortBlocksKeysOnly<4, 0, false, false, true>]
!69 = metadata !{metadata !49, metadata !50, metadata !66, metadata !51, metadata !70}
!70 = metadata !{i32 786480, null, metadata !"loop", metadata !40, i64 1, null, i32 0, i32 0} ; [ DW_TAG_template_value_parameter ]
!71 = metadata !{i32 786478, i32 0, metadata !13, metadata !"radixSortBlocksKeysOnly<4, 0, true, false, false>", metadata !"radixSortBlocksKeysOnly<4, 0, true, false, false>", metadata !"_Z23radixSortBlocksKeysOnlyILj4ELj0ELb1ELb0ELb0EEvP5uint4S1_jj", metadata !13, i32 541, metadata !54, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (%struct.uint4*, %struct.uint4*, i32, i32)* @_Z23radixSortBlocksKeysOnlyILj4ELj0ELb1ELb0ELb0EEvP5uint4S1_jj, metadata !72, null, metadata !1, i32 542} ; [ DW_TAG_subprogram ] [line 541] [def] [scope 542] [radixSortBlocksKeysOnly<4, 0, true, false, false>]
!72 = metadata !{metadata !49, metadata !50, metadata !73, metadata !51, metadata !67}
!73 = metadata !{i32 786480, null, metadata !"fullBlocks", metadata !40, i64 1, null, i32 0, i32 0} ; [ DW_TAG_template_value_parameter ]
!74 = metadata !{i32 786478, i32 0, metadata !13, metadata !"radixSortBlocksKeysOnly<4, 0, true, false, true>", metadata !"radixSortBlocksKeysOnly<4, 0, true, false, true>", metadata !"_Z23radixSortBlocksKeysOnlyILj4ELj0ELb1ELb0ELb1EEvP5uint4S1_jj", metadata !13, i32 541, metadata !54, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (%struct.uint4*, %struct.uint4*, i32, i32)* @_Z23radixSortBlocksKeysOnlyILj4ELj0ELb1ELb0ELb1EEvP5uint4S1_jj, metadata !75, null, metadata !1, i32 542} ; [ DW_TAG_subprogram ] [line 541] [def] [scope 542] [radixSortBlocksKeysOnly<4, 0, true, false, true>]
!75 = metadata !{metadata !49, metadata !50, metadata !73, metadata !51, metadata !70}
!76 = metadata !{i32 786478, i32 0, metadata !13, metadata !"radixSortStepKeysOnly<4, 0, true, false>", metadata !"radixSortStepKeysOnly<4, 0, true, false>", metadata !"_Z21radixSortStepKeysOnlyILj4ELj0ELb1ELb0EEvPjS0_S0_S0_S0_11CUDPPHandlej", metadata !13, i32 765, metadata !46, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (i32*, i32*, i32*, i32*, i32*, i32)* @_Z21radixSortStepKeysOnlyILj4ELj0ELb1ELb0EEvPjS0_S0_S0_S0_11CUDPPHandlej, metadata !77, null, metadata !1, i32 772} ; [ DW_TAG_subprogram ] [line 765] [def] [scope 772] [radixSortStepKeysOnly<4, 0, true, false>]
!77 = metadata !{metadata !49, metadata !50, metadata !78, metadata !52}
!78 = metadata !{i32 786480, null, metadata !"flip", metadata !40, i64 1, null, i32 0, i32 0} ; [ DW_TAG_template_value_parameter ]
!79 = metadata !{i32 786478, i32 0, metadata !13, metadata !"radixSortBlocksKeysOnly<4, 0, false, true, false>", metadata !"radixSortBlocksKeysOnly<4, 0, false, true, false>", metadata !"_Z23radixSortBlocksKeysOnlyILj4ELj0ELb0ELb1ELb0EEvP5uint4S1_jj", metadata !13, i32 541, metadata !54, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (%struct.uint4*, %struct.uint4*, i32, i32)* @_Z23radixSortBlocksKeysOnlyILj4ELj0ELb0ELb1ELb0EEvP5uint4S1_jj, metadata !80, null, metadata !1, i32 542} ; [ DW_TAG_subprogram ] [line 541] [def] [scope 542] [radixSortBlocksKeysOnly<4, 0, false, true, false>]
!80 = metadata !{metadata !49, metadata !50, metadata !66, metadata !78, metadata !67}
!81 = metadata !{i32 786478, i32 0, metadata !13, metadata !"radixSortBlocksKeysOnly<4, 0, false, true, true>", metadata !"radixSortBlocksKeysOnly<4, 0, false, true, true>", metadata !"_Z23radixSortBlocksKeysOnlyILj4ELj0ELb0ELb1ELb1EEvP5uint4S1_jj", metadata !13, i32 541, metadata !54, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (%struct.uint4*, %struct.uint4*, i32, i32)* @_Z23radixSortBlocksKeysOnlyILj4ELj0ELb0ELb1ELb1EEvP5uint4S1_jj, metadata !82, null, metadata !1, i32 542} ; [ DW_TAG_subprogram ] [line 541] [def] [scope 542] [radixSortBlocksKeysOnly<4, 0, false, true, true>]
!82 = metadata !{metadata !49, metadata !50, metadata !66, metadata !78, metadata !70}
!83 = metadata !{i32 786478, i32 0, metadata !13, metadata !"radixSortBlocksKeysOnly<4, 0, true, true, false>", metadata !"radixSortBlocksKeysOnly<4, 0, true, true, false>", metadata !"_Z23radixSortBlocksKeysOnlyILj4ELj0ELb1ELb1ELb0EEvP5uint4S1_jj", metadata !13, i32 541, metadata !54, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (%struct.uint4*, %struct.uint4*, i32, i32)* @_Z23radixSortBlocksKeysOnlyILj4ELj0ELb1ELb1ELb0EEvP5uint4S1_jj, metadata !84, null, metadata !1, i32 542} ; [ DW_TAG_subprogram ] [line 541] [def] [scope 542] [radixSortBlocksKeysOnly<4, 0, true, true, false>]
!84 = metadata !{metadata !49, metadata !50, metadata !73, metadata !78, metadata !67}
!85 = metadata !{i32 786478, i32 0, metadata !13, metadata !"radixSortBlocksKeysOnly<4, 0, true, true, true>", metadata !"radixSortBlocksKeysOnly<4, 0, true, true, true>", metadata !"_Z23radixSortBlocksKeysOnlyILj4ELj0ELb1ELb1ELb1EEvP5uint4S1_jj", metadata !13, i32 541, metadata !54, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (%struct.uint4*, %struct.uint4*, i32, i32)* @_Z23radixSortBlocksKeysOnlyILj4ELj0ELb1ELb1ELb1EEvP5uint4S1_jj, metadata !86, null, metadata !1, i32 542} ; [ DW_TAG_subprogram ] [line 541] [def] [scope 542] [radixSortBlocksKeysOnly<4, 0, true, true, true>]
!86 = metadata !{metadata !49, metadata !50, metadata !73, metadata !78, metadata !70}
!87 = metadata !{i32 786478, i32 0, null, metadata !"sort", metadata !"sort", metadata !"_ZN9RadixSort4sortEPjS0_jj", metadata !31, i32 111, metadata !88, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (%class.RadixSort*, i32*, i32*, i32, i32)* @_ZN9RadixSort4sortEPjS0_jj, null, metadata !104, metadata !1, i32 115} ; [ DW_TAG_subprogram ] [line 111] [def] [scope 115] [sort]
!88 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !89, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!89 = metadata !{null, metadata !90, metadata !96, metadata !96, metadata !25, metadata !25}
!90 = metadata !{i32 786447, i32 0, metadata !"", i32 0, i32 0, i64 64, i64 64, i64 0, i32 1088, metadata !91} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from RadixSort]
!91 = metadata !{i32 786434, null, metadata !"RadixSort", metadata !31, i32 70, i64 384, i64 64, i32 0, i32 0, null, metadata !92, i32 0, null, null} ; [ DW_TAG_class_type ] [RadixSort] [line 70, size 384, align 64, offset 0] [from ]
!92 = metadata !{metadata !93, metadata !94, metadata !95, metadata !97, metadata !98, metadata !99, metadata !100, metadata !101, metadata !104, metadata !105, metadata !106}
!93 = metadata !{i32 786445, metadata !91, metadata !"mScanPlan", metadata !31, i32 142, i64 8, i64 8, i64 0, i32 2, metadata !30} ; [ DW_TAG_member ] [mScanPlan] [line 142, size 8, align 8, offset 0] [protected] [from CUDPPHandle]
!94 = metadata !{i32 786445, metadata !91, metadata !"mNumElements", metadata !31, i32 144, i64 32, i64 32, i64 32, i32 2, metadata !25} ; [ DW_TAG_member ] [mNumElements] [line 144, size 32, align 32, offset 32] [protected] [from unsigned int]
!95 = metadata !{i32 786445, metadata !91, metadata !"mTempKeys", metadata !31, i32 145, i64 64, i64 64, i64 64, i32 2, metadata !96} ; [ DW_TAG_member ] [mTempKeys] [line 145, size 64, align 64, offset 64] [protected] [from ]
!96 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !25} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from unsigned int]
!97 = metadata !{i32 786445, metadata !91, metadata !"mTempValues", metadata !31, i32 146, i64 64, i64 64, i64 128, i32 2, metadata !96} ; [ DW_TAG_member ] [mTempValues] [line 146, size 64, align 64, offset 128] [protected] [from ]
!98 = metadata !{i32 786445, metadata !91, metadata !"mCounters", metadata !31, i32 147, i64 64, i64 64, i64 192, i32 2, metadata !96} ; [ DW_TAG_member ] [mCounters] [line 147, size 64, align 64, offset 192] [protected] [from ]
!99 = metadata !{i32 786445, metadata !91, metadata !"mCountersSum", metadata !31, i32 148, i64 64, i64 64, i64 256, i32 2, metadata !96} ; [ DW_TAG_member ] [mCountersSum] [line 148, size 64, align 64, offset 256] [protected] [from ]
!100 = metadata !{i32 786445, metadata !91, metadata !"mBlockOffsets", metadata !31, i32 149, i64 64, i64 64, i64 320, i32 2, metadata !96} ; [ DW_TAG_member ] [mBlockOffsets] [line 149, size 64, align 64, offset 320] [protected] [from ]
!101 = metadata !{i32 786478, i32 0, metadata !91, metadata !"RadixSort", metadata !"RadixSort", metadata !"", metadata !31, i32 81, metadata !102, i1 false, i1 false, i32 0, i32 0, null, i32 256, i1 false, null, null, i32 0, metadata !38, i32 81} ; [ DW_TAG_subprogram ] [line 81] [RadixSort]
!102 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !103, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!103 = metadata !{null, metadata !90, metadata !25, metadata !40}
!104 = metadata !{i32 786478, i32 0, metadata !91, metadata !"sort", metadata !"sort", metadata !"_ZN9RadixSort4sortEPjS0_jj", metadata !31, i32 111, metadata !88, i1 false, i1 false, i32 0, i32 0, null, i32 256, i1 false, null, null, i32 0, metadata !38, i32 111} ; [ DW_TAG_subprogram ] [line 111] [sort]
!105 = metadata !{i32 786478, i32 0, metadata !91, metadata !"initialize", metadata !"initialize", metadata !"_ZN9RadixSort10initializeEjb", metadata !31, i32 162, metadata !102, i1 false, i1 false, i32 0, i32 0, null, i32 258, i1 false, null, null, i32 0, metadata !38, i32 162} ; [ DW_TAG_subprogram ] [line 162] [initialize]
!106 = metadata !{i32 786478, i32 0, metadata !91, metadata !"finalize", metadata !"finalize", metadata !"_ZN9RadixSort8finalizeEv", metadata !31, i32 196, metadata !107, i1 false, i1 false, i32 0, i32 0, null, i32 258, i1 false, null, null, i32 0, metadata !38, i32 196} ; [ DW_TAG_subprogram ] [line 196] [finalize]
!107 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !108, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!108 = metadata !{null, metadata !90}
!109 = metadata !{i32 786478, i32 0, null, metadata !"RadixSort", metadata !"RadixSort", metadata !"_ZN9RadixSortC1Ejb", metadata !31, i32 81, metadata !102, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (%class.RadixSort*, i32, i1)* @_ZN9RadixSortC1Ejb, null, metadata !101, metadata !1, i32 89} ; [ DW_TAG_subprogram ] [line 81] [def] [scope 89] [RadixSort]
!110 = metadata !{i32 786478, i32 0, null, metadata !"RadixSort", metadata !"RadixSort", metadata !"_ZN9RadixSortC2Ejb", metadata !31, i32 81, metadata !102, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (%class.RadixSort*, i32, i1)* @_ZN9RadixSortC2Ejb, null, metadata !101, metadata !1, i32 89} ; [ DW_TAG_subprogram ] [line 81] [def] [scope 89] [RadixSort]
!111 = metadata !{i32 786478, i32 0, null, metadata !"initialize", metadata !"initialize", metadata !"_ZN9RadixSort10initializeEjb", metadata !31, i32 162, metadata !102, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (%class.RadixSort*, i32, i1)* @_ZN9RadixSort10initializeEjb, null, metadata !105, metadata !1, i32 163} ; [ DW_TAG_subprogram ] [line 162] [def] [scope 163] [initialize]
!112 = metadata !{i32 786478, i32 0, null, metadata !"CUDPPHandle", metadata !"CUDPPHandle", metadata !"_ZN11CUDPPHandleC1EPv", metadata !31, i32 26, metadata !34, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (%struct.CUDPPHandle*, i8*)* @_ZN11CUDPPHandleC1EPv, null, metadata !33, metadata !1, i32 26} ; [ DW_TAG_subprogram ] [line 26] [def] [CUDPPHandle]
!113 = metadata !{i32 786478, i32 0, null, metadata !"CUDPPHandle", metadata !"CUDPPHandle", metadata !"_ZN11CUDPPHandleC2EPv", metadata !31, i32 26, metadata !34, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (%struct.CUDPPHandle*, i8*)* @_ZN11CUDPPHandleC2EPv, null, metadata !33, metadata !1, i32 26} ; [ DW_TAG_subprogram ] [line 26] [def] [CUDPPHandle]
!114 = metadata !{i32 786478, i32 0, null, metadata !"dim3", metadata !"dim3", metadata !"_ZN4dim3C1Ejjj", metadata !59, i32 397, metadata !115, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (%struct.dim3*, i32, i32, i32)* @_ZN4dim3C1Ejjj, null, metadata !123, metadata !1, i32 397} ; [ DW_TAG_subprogram ] [line 397] [def] [dim3]
!115 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !116, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!116 = metadata !{null, metadata !117, metadata !25, metadata !25, metadata !25}
!117 = metadata !{i32 786447, i32 0, metadata !"", i32 0, i32 0, i64 64, i64 64, i64 0, i32 1088, metadata !118} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from dim3]
!118 = metadata !{i32 786434, null, metadata !"dim3", metadata !59, i32 393, i64 96, i64 32, i32 0, i32 0, null, metadata !119, i32 0, null, null} ; [ DW_TAG_class_type ] [dim3] [line 393, size 96, align 32, offset 0] [from ]
!119 = metadata !{metadata !120, metadata !121, metadata !122, metadata !123, metadata !124, metadata !133}
!120 = metadata !{i32 786445, metadata !118, metadata !"x", metadata !59, i32 395, i64 32, i64 32, i64 0, i32 0, metadata !25} ; [ DW_TAG_member ] [x] [line 395, size 32, align 32, offset 0] [from unsigned int]
!121 = metadata !{i32 786445, metadata !118, metadata !"y", metadata !59, i32 395, i64 32, i64 32, i64 32, i32 0, metadata !25} ; [ DW_TAG_member ] [y] [line 395, size 32, align 32, offset 32] [from unsigned int]
!122 = metadata !{i32 786445, metadata !118, metadata !"z", metadata !59, i32 395, i64 32, i64 32, i64 64, i32 0, metadata !25} ; [ DW_TAG_member ] [z] [line 395, size 32, align 32, offset 64] [from unsigned int]
!123 = metadata !{i32 786478, i32 0, metadata !118, metadata !"dim3", metadata !"dim3", metadata !"", metadata !59, i32 397, metadata !115, i1 false, i1 false, i32 0, i32 0, null, i32 256, i1 false, null, null, i32 0, metadata !38, i32 397} ; [ DW_TAG_subprogram ] [line 397] [dim3]
!124 = metadata !{i32 786478, i32 0, metadata !118, metadata !"dim3", metadata !"dim3", metadata !"", metadata !59, i32 398, metadata !125, i1 false, i1 false, i32 0, i32 0, null, i32 256, i1 false, null, null, i32 0, metadata !38, i32 398} ; [ DW_TAG_subprogram ] [line 398] [dim3]
!125 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !126, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!126 = metadata !{null, metadata !117, metadata !127}
!127 = metadata !{i32 786454, null, metadata !"uint3", metadata !59, i32 359, i64 0, i64 0, i64 0, i32 0, metadata !128} ; [ DW_TAG_typedef ] [uint3] [line 359, size 0, align 0, offset 0] [from uint3]
!128 = metadata !{i32 786434, null, metadata !"uint3", metadata !59, i32 186, i64 96, i64 32, i32 0, i32 0, null, metadata !129, i32 0, null, null} ; [ DW_TAG_class_type ] [uint3] [line 186, size 96, align 32, offset 0] [from ]
!129 = metadata !{metadata !130, metadata !131, metadata !132}
!130 = metadata !{i32 786445, metadata !128, metadata !"x", metadata !59, i32 188, i64 32, i64 32, i64 0, i32 0, metadata !25} ; [ DW_TAG_member ] [x] [line 188, size 32, align 32, offset 0] [from unsigned int]
!131 = metadata !{i32 786445, metadata !128, metadata !"y", metadata !59, i32 188, i64 32, i64 32, i64 32, i32 0, metadata !25} ; [ DW_TAG_member ] [y] [line 188, size 32, align 32, offset 32] [from unsigned int]
!132 = metadata !{i32 786445, metadata !128, metadata !"z", metadata !59, i32 188, i64 32, i64 32, i64 64, i32 0, metadata !25} ; [ DW_TAG_member ] [z] [line 188, size 32, align 32, offset 64] [from unsigned int]
!133 = metadata !{i32 786478, i32 0, metadata !118, metadata !"operator uint3", metadata !"operator uint3", metadata !"_ZN4dim3cv5uint3Ev", metadata !59, i32 399, metadata !134, i1 false, i1 false, i32 0, i32 0, null, i32 256, i1 false, null, null, i32 0, metadata !38, i32 399} ; [ DW_TAG_subprogram ] [line 399] [operator uint3]
!134 = metadata !{i32 786453, i32 0, metadata !"", i32 0, i32 0, i64 0, i64 0, i64 0, i32 0, null, metadata !135, i32 0, i32 0} ; [ DW_TAG_subroutine_type ] [line 0, size 0, align 0, offset 0] [from ]
!135 = metadata !{metadata !127, metadata !117}
!136 = metadata !{i32 786478, i32 0, null, metadata !"dim3", metadata !"dim3", metadata !"_ZN4dim3C2Ejjj", metadata !59, i32 397, metadata !115, i1 false, i1 true, i32 0, i32 0, null, i32 256, i1 false, void (%struct.dim3*, i32, i32, i32)* @_ZN4dim3C2Ejjj, null, metadata !123, metadata !1, i32 397} ; [ DW_TAG_subprogram ] [line 397] [def] [dim3]
!137 = metadata !{metadata !138}
!138 = metadata !{metadata !139, metadata !141, metadata !142, metadata !143, metadata !144, metadata !145, metadata !149, metadata !150, metadata !154, metadata !155, metadata !157, metadata !158, metadata !159, metadata !159, metadata !160, metadata !160, metadata !161, metadata !161, metadata !161, metadata !163, metadata !163, metadata !163, metadata !160, metadata !160, metadata !161, metadata !161, metadata !161, metadata !163, metadata !163, metadata !163, metadata !160, metadata !160, metadata !160, metadata !160, metadata !160, metadata !160, metadata !164, metadata !164, metadata !164}
!139 = metadata !{i32 786484, i32 0, null, metadata !"gridDim", metadata !"gridDim", metadata !"", metadata !6, i32 26, metadata !140, i32 0, i32 1, %struct.dim3* @gridDim} ; [ DW_TAG_variable ] [gridDim] [line 26] [def]
!140 = metadata !{i32 786454, null, metadata !"dim3", metadata !6, i32 403, i64 0, i64 0, i64 0, i32 0, metadata !118} ; [ DW_TAG_typedef ] [dim3] [line 403, size 0, align 0, offset 0] [from dim3]
!141 = metadata !{i32 786484, i32 0, null, metadata !"blockIdx", metadata !"blockIdx", metadata !"", metadata !6, i32 27, metadata !140, i32 0, i32 1, %struct.dim3* @blockIdx} ; [ DW_TAG_variable ] [blockIdx] [line 27] [def]
!142 = metadata !{i32 786484, i32 0, null, metadata !"blockDim", metadata !"blockDim", metadata !"", metadata !6, i32 28, metadata !140, i32 0, i32 1, %struct.dim3* @blockDim} ; [ DW_TAG_variable ] [blockDim] [line 28] [def]
!143 = metadata !{i32 786484, i32 0, null, metadata !"threadIdx", metadata !"threadIdx", metadata !"", metadata !6, i32 29, metadata !140, i32 0, i32 1, %struct.dim3* @threadIdx} ; [ DW_TAG_variable ] [threadIdx] [line 29] [def]
!144 = metadata !{i32 786484, i32 0, null, metadata !"bManualCoalesce", metadata !"bManualCoalesce", metadata !"", metadata !13, i32 31, metadata !40, i32 0, i32 1, i8* @bManualCoalesce} ; [ DW_TAG_variable ] [bManualCoalesce] [line 31] [def]
!145 = metadata !{i32 786484, i32 0, null, metadata !"numCTAs", metadata !"numCTAs", metadata !"", metadata !13, i32 32, metadata !146, i32 0, i32 1, [6 x i32]* @numCTAs} ; [ DW_TAG_variable ] [numCTAs] [line 32] [def]
!146 = metadata !{i32 786433, null, metadata !"", null, i32 0, i64 192, i64 32, i32 0, i32 0, metadata !25, metadata !147, i32 0, i32 0} ; [ DW_TAG_array_type ] [line 0, size 192, align 32, offset 0] [from unsigned int]
!147 = metadata !{metadata !148}
!148 = metadata !{i32 786465, i64 0, i64 5}       ; [ DW_TAG_subrange_type ] [0, 5]
!149 = metadata !{i32 786484, i32 0, null, metadata !"numSMs", metadata !"numSMs", metadata !"", metadata !13, i32 33, metadata !25, i32 0, i32 1, i32* @numSMs} ; [ DW_TAG_variable ] [numSMs] [line 33] [def]
!150 = metadata !{i32 786484, i32 0, null, metadata !"persistentCTAThreshold", metadata !"persistentCTAThreshold", metadata !"", metadata !13, i32 34, metadata !151, i32 0, i32 1, [2 x i32]* @persistentCTAThreshold} ; [ DW_TAG_variable ] [persistentCTAThreshold] [line 34] [def]
!151 = metadata !{i32 786433, null, metadata !"", null, i32 0, i64 64, i64 32, i32 0, i32 0, metadata !25, metadata !152, i32 0, i32 0} ; [ DW_TAG_array_type ] [line 0, size 64, align 32, offset 0] [from unsigned int]
!152 = metadata !{metadata !153}
!153 = metadata !{i32 786465, i64 0, i64 1}       ; [ DW_TAG_subrange_type ] [0, 1]
!154 = metadata !{i32 786484, i32 0, null, metadata !"persistentCTAThresholdFullBlocks", metadata !"persistentCTAThresholdFullBlocks", metadata !"", metadata !13, i32 35, metadata !151, i32 0, i32 1, [2 x i32]* @persistentCTAThresholdFullBlocks} ; [ DW_TAG_variable ] [persistentCTAThresholdFullBlocks] [line 35] [def]
!155 = metadata !{i32 786484, i32 0, metadata !91, metadata !"CTA_SIZE", metadata !"CTA_SIZE", metadata !"CTA_SIZE", metadata !31, i32 132, metadata !156, i32 1, i32 1, i32 256} ; [ DW_TAG_variable ] [CTA_SIZE] [line 132] [local] [def]
!156 = metadata !{i32 786470, null, metadata !"", null, i32 0, i64 0, i64 0, i64 0, i32 0, metadata !25} ; [ DW_TAG_const_type ] [line 0, size 0, align 0, offset 0] [from unsigned int]
!157 = metadata !{i32 786484, i32 0, metadata !91, metadata !"WARP_SIZE", metadata !"WARP_SIZE", metadata !"WARP_SIZE", metadata !31, i32 133, metadata !156, i32 1, i32 1, i32 32} ; [ DW_TAG_variable ] [WARP_SIZE] [line 133] [local] [def]
!158 = metadata !{i32 786484, i32 0, metadata !13, metadata !"maxElements", metadata !"maxElements", metadata !"maxElements", metadata !13, i32 1121, metadata !156, i32 1, i32 1, i32 32} ; [ DW_TAG_variable ] [maxElements] [line 1121] [local] [def]
!159 = metadata !{i32 786484, i32 0, metadata !13, metadata !"numElements", metadata !"numElements", metadata !"numElements", metadata !13, i32 1122, metadata !156, i32 1, i32 1, i32 16} ; [ DW_TAG_variable ] [numElements] [line 1122] [local] [def]
!160 = metadata !{i32 786484, i32 0, metadata !31, metadata !"CTA_SIZE", metadata !"CTA_SIZE", metadata !"CTA_SIZE", metadata !31, i32 132, metadata !156, i32 1, i32 1, i32 256} ; [ DW_TAG_variable ] [CTA_SIZE] [line 132] [local] [def]
!161 = metadata !{i32 786484, i32 0, metadata !13, metadata !"eltsPerBlock", metadata !"eltsPerBlock", metadata !"eltsPerBlock", metadata !13, i32 773, metadata !162, i32 1, i32 1, i32 1024} ; [ DW_TAG_variable ] [eltsPerBlock] [line 773] [local] [def]
!162 = metadata !{i32 786470, null, metadata !"", null, i32 0, i64 0, i64 0, i64 0, i32 0, metadata !24} ; [ DW_TAG_const_type ] [line 0, size 0, align 0, offset 0] [from uint]
!163 = metadata !{i32 786484, i32 0, metadata !13, metadata !"eltsPerBlock2", metadata !"eltsPerBlock2", metadata !"eltsPerBlock2", metadata !13, i32 774, metadata !162, i32 1, i32 1, i32 512} ; [ DW_TAG_variable ] [eltsPerBlock2] [line 774] [local] [def]
!164 = metadata !{i32 786484, i32 0, metadata !31, metadata !"WARP_SIZE", metadata !"WARP_SIZE", metadata !"WARP_SIZE", metadata !31, i32 133, metadata !156, i32 1, i32 1, i32 32} ; [ DW_TAG_variable ] [WARP_SIZE] [line 133] [local] [def]
!165 = metadata !{i32 26, i32 6, metadata !5, null}
!166 = metadata !{i32 786689, metadata !114, metadata !"this", metadata !59, i32 16777613, metadata !167, i32 1088, i32 0} ; [ DW_TAG_arg_variable ] [this] [line 397]
!167 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !118} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from dim3]
!168 = metadata !{i32 397, i32 25, metadata !114, null}
!169 = metadata !{i32 786689, metadata !114, metadata !"vx", metadata !59, i32 33554829, metadata !25, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [vx] [line 397]
!170 = metadata !{i32 397, i32 43, metadata !114, null}
!171 = metadata !{i32 786689, metadata !114, metadata !"vy", metadata !59, i32 50332045, metadata !25, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [vy] [line 397]
!172 = metadata !{i32 397, i32 64, metadata !114, null}
!173 = metadata !{i32 786689, metadata !114, metadata !"vz", metadata !59, i32 67109261, metadata !25, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [vz] [line 397]
!174 = metadata !{i32 397, i32 85, metadata !114, null}
!175 = metadata !{i32 397, i32 116, metadata !114, null}
!176 = metadata !{i32 27, i32 6, metadata !9, null}
!177 = metadata !{i32 28, i32 6, metadata !10, null}
!178 = metadata !{i32 29, i32 6, metadata !11, null}
!179 = metadata !{i32 92, i32 1, metadata !180, null}
!180 = metadata !{i32 786443, metadata !12, i32 42, i32 1, metadata !13, i32 0} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Race/RaceSort/radixsort.cu]
!181 = metadata !{i32 786689, metadata !14, metadata !"msg", metadata !13, i32 16777325, metadata !17, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [msg] [line 109]
!182 = metadata !{i32 109, i32 33, metadata !14, null}
!183 = metadata !{i32 125, i32 1, metadata !184, null}
!184 = metadata !{i32 786443, metadata !14, i32 110, i32 1, metadata !13, i32 1} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Race/RaceSort/radixsort.cu]
!185 = metadata !{i32 786689, metadata !27, metadata !"keys", metadata !13, i32 16778233, metadata !23, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [keys] [line 1017]
!186 = metadata !{i32 1017, i32 30, metadata !27, null}
!187 = metadata !{i32 786689, metadata !27, metadata !"tempKeys", metadata !13, i32 33555450, metadata !23, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [tempKeys] [line 1018]
!188 = metadata !{i32 1018, i32 30, metadata !27, null}
!189 = metadata !{i32 786689, metadata !27, metadata !"counters", metadata !13, i32 50332667, metadata !23, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [counters] [line 1019]
!190 = metadata !{i32 1019, i32 30, metadata !27, null}
!191 = metadata !{i32 786689, metadata !27, metadata !"countersSum", metadata !13, i32 67109884, metadata !23, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [countersSum] [line 1020]
!192 = metadata !{i32 1020, i32 30, metadata !27, null}
!193 = metadata !{i32 786689, metadata !27, metadata !"blockOffsets", metadata !13, i32 83887101, metadata !23, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [blockOffsets] [line 1021]
!194 = metadata !{i32 1021, i32 30, metadata !27, null}
!195 = metadata !{i32 786689, metadata !27, metadata !"scanPlan", metadata !13, i32 100664318, metadata !30, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [scanPlan] [line 1022]
!196 = metadata !{i32 1022, i32 36, metadata !27, null}
!197 = metadata !{i32 786689, metadata !27, metadata !"numElements", metadata !13, i32 117441535, metadata !24, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [numElements] [line 1023]
!198 = metadata !{i32 1023, i32 29, metadata !27, null}
!199 = metadata !{i32 786689, metadata !27, metadata !"keyBits", metadata !13, i32 134218752, metadata !24, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [keyBits] [line 1024]
!200 = metadata !{i32 1024, i32 29, metadata !27, null}
!201 = metadata !{i32 786689, metadata !27, metadata !"flipBits", metadata !13, i32 150995969, metadata !40, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [flipBits] [line 1025]
!202 = metadata !{i32 1025, i32 29, metadata !27, null}
!203 = metadata !{i32 1047, i32 5, metadata !204, null}
!204 = metadata !{i32 786443, metadata !27, i32 1026, i32 1, metadata !13, i32 2} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Race/RaceSort/radixsort.cu]
!205 = metadata !{i32 1049, i32 13, metadata !206, null}
!206 = metadata !{i32 786443, metadata !204, i32 1048, i32 5, metadata !13, i32 3} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Race/RaceSort/radixsort.cu]
!207 = metadata !{i32 1052, i32 5, metadata !206, null}
!208 = metadata !{i32 1055, i32 13, metadata !209, null}
!209 = metadata !{i32 786443, metadata !204, i32 1054, i32 5, metadata !13, i32 4} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Race/RaceSort/radixsort.cu]
!210 = metadata !{i32 1113, i32 1, metadata !204, null}
!211 = metadata !{i32 786689, metadata !76, metadata !"keys", metadata !13, i32 16777981, metadata !23, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [keys] [line 765]
!212 = metadata !{i32 765, i32 34, metadata !76, null}
!213 = metadata !{i32 786689, metadata !76, metadata !"tempKeys", metadata !13, i32 33555198, metadata !23, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [tempKeys] [line 766]
!214 = metadata !{i32 766, i32 26, metadata !76, null}
!215 = metadata !{i32 786689, metadata !76, metadata !"counters", metadata !13, i32 50332415, metadata !23, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [counters] [line 767]
!216 = metadata !{i32 767, i32 26, metadata !76, null}
!217 = metadata !{i32 786689, metadata !76, metadata !"countersSum", metadata !13, i32 67109632, metadata !23, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [countersSum] [line 768]
!218 = metadata !{i32 768, i32 26, metadata !76, null}
!219 = metadata !{i32 786689, metadata !76, metadata !"blockOffsets", metadata !13, i32 83886849, metadata !23, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [blockOffsets] [line 769]
!220 = metadata !{i32 769, i32 26, metadata !76, null}
!221 = metadata !{i32 786689, metadata !76, metadata !"scanPlan", metadata !13, i32 100664066, metadata !30, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [scanPlan] [line 770]
!222 = metadata !{i32 770, i32 32, metadata !76, null}
!223 = metadata !{i32 786689, metadata !76, metadata !"numElements", metadata !13, i32 117441283, metadata !24, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [numElements] [line 771]
!224 = metadata !{i32 771, i32 25, metadata !76, null}
!225 = metadata !{i32 786688, metadata !226, metadata !"eltsPerBlock", metadata !13, i32 773, metadata !162, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [eltsPerBlock] [line 773]
!226 = metadata !{i32 786443, metadata !76, i32 772, i32 1, metadata !13, i32 12} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Race/RaceSort/radixsort.cu]
!227 = metadata !{i32 773, i32 16, metadata !226, null}
!228 = metadata !{i32 773, i32 54, metadata !226, null}
!229 = metadata !{i32 786688, metadata !226, metadata !"eltsPerBlock2", metadata !13, i32 774, metadata !162, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [eltsPerBlock2] [line 774]
!230 = metadata !{i32 774, i32 16, metadata !226, null}
!231 = metadata !{i32 774, i32 55, metadata !226, null}
!232 = metadata !{i32 786688, metadata !226, metadata !"fullBlocks", metadata !13, i32 776, metadata !40, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [fullBlocks] [line 776]
!233 = metadata !{i32 776, i32 10, metadata !226, null}
!234 = metadata !{i32 776, i32 58, metadata !226, null}
!235 = metadata !{i32 786688, metadata !226, metadata !"numBlocks", metadata !13, i32 777, metadata !24, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [numBlocks] [line 777]
!236 = metadata !{i32 777, i32 10, metadata !226, null}
!237 = metadata !{i32 779, i32 41, metadata !226, null}
!238 = metadata !{i32 786688, metadata !226, metadata !"numBlocks2", metadata !13, i32 780, metadata !24, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [numBlocks2] [line 780]
!239 = metadata !{i32 780, i32 10, metadata !226, null}
!240 = metadata !{i32 782, i32 42, metadata !226, null}
!241 = metadata !{i32 786688, metadata !226, metadata !"loop", metadata !13, i32 784, metadata !40, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [loop] [line 784]
!242 = metadata !{i32 784, i32 10, metadata !226, null}
!243 = metadata !{i32 784, i32 34, metadata !226, null}
!244 = metadata !{i32 786688, metadata !226, metadata !"loop2", metadata !13, i32 785, metadata !40, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [loop2] [line 785]
!245 = metadata !{i32 785, i32 10, metadata !226, null}
!246 = metadata !{i32 785, i32 36, metadata !226, null}
!247 = metadata !{i32 786688, metadata !226, metadata !"blocks", metadata !13, i32 786, metadata !24, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [blocks] [line 786]
!248 = metadata !{i32 786, i32 10, metadata !226, null}
!249 = metadata !{i32 786, i32 43, metadata !226, null}
!250 = metadata !{i32 786688, metadata !226, metadata !"blocksFind", metadata !13, i32 787, metadata !24, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [blocksFind] [line 787]
!251 = metadata !{i32 787, i32 10, metadata !226, null}
!252 = metadata !{i32 787, i32 49, metadata !226, null}
!253 = metadata !{i32 786688, metadata !226, metadata !"blocksReorder", metadata !13, i32 788, metadata !24, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [blocksReorder] [line 788]
!254 = metadata !{i32 788, i32 10, metadata !226, null}
!255 = metadata !{i32 788, i32 52, metadata !226, null}
!256 = metadata !{i32 802, i32 5, metadata !226, null}
!257 = metadata !{i32 804, i32 9, metadata !258, null}
!258 = metadata !{i32 786443, metadata !226, i32 803, i32 5, metadata !13, i32 13} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Race/RaceSort/radixsort.cu]
!259 = metadata !{i32 807, i32 17, metadata !258, null}
!260 = metadata !{i32 812, i32 16, metadata !258, null}
!261 = metadata !{i32 814, i32 5, metadata !258, null}
!262 = metadata !{i32 817, i32 9, metadata !263, null}
!263 = metadata !{i32 786443, metadata !226, i32 816, i32 5, metadata !13, i32 14} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Race/RaceSort/radixsort.cu]
!264 = metadata !{i32 820, i32 17, metadata !263, null}
!265 = metadata !{i32 825, i32 17, metadata !263, null}
!266 = metadata !{i32 937, i32 1, metadata !226, null}
!267 = metadata !{i32 786689, metadata !45, metadata !"keys", metadata !13, i32 16777981, metadata !23, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [keys] [line 765]
!268 = metadata !{i32 765, i32 34, metadata !45, null}
!269 = metadata !{i32 786689, metadata !45, metadata !"tempKeys", metadata !13, i32 33555198, metadata !23, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [tempKeys] [line 766]
!270 = metadata !{i32 766, i32 26, metadata !45, null}
!271 = metadata !{i32 786689, metadata !45, metadata !"counters", metadata !13, i32 50332415, metadata !23, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [counters] [line 767]
!272 = metadata !{i32 767, i32 26, metadata !45, null}
!273 = metadata !{i32 786689, metadata !45, metadata !"countersSum", metadata !13, i32 67109632, metadata !23, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [countersSum] [line 768]
!274 = metadata !{i32 768, i32 26, metadata !45, null}
!275 = metadata !{i32 786689, metadata !45, metadata !"blockOffsets", metadata !13, i32 83886849, metadata !23, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [blockOffsets] [line 769]
!276 = metadata !{i32 769, i32 26, metadata !45, null}
!277 = metadata !{i32 786689, metadata !45, metadata !"scanPlan", metadata !13, i32 100664066, metadata !30, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [scanPlan] [line 770]
!278 = metadata !{i32 770, i32 32, metadata !45, null}
!279 = metadata !{i32 786689, metadata !45, metadata !"numElements", metadata !13, i32 117441283, metadata !24, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [numElements] [line 771]
!280 = metadata !{i32 771, i32 25, metadata !45, null}
!281 = metadata !{i32 786688, metadata !282, metadata !"eltsPerBlock", metadata !13, i32 773, metadata !162, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [eltsPerBlock] [line 773]
!282 = metadata !{i32 786443, metadata !45, i32 772, i32 1, metadata !13, i32 9} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Race/RaceSort/radixsort.cu]
!283 = metadata !{i32 773, i32 16, metadata !282, null}
!284 = metadata !{i32 773, i32 54, metadata !282, null}
!285 = metadata !{i32 786688, metadata !282, metadata !"eltsPerBlock2", metadata !13, i32 774, metadata !162, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [eltsPerBlock2] [line 774]
!286 = metadata !{i32 774, i32 16, metadata !282, null}
!287 = metadata !{i32 774, i32 55, metadata !282, null}
!288 = metadata !{i32 786688, metadata !282, metadata !"fullBlocks", metadata !13, i32 776, metadata !40, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [fullBlocks] [line 776]
!289 = metadata !{i32 776, i32 10, metadata !282, null}
!290 = metadata !{i32 776, i32 58, metadata !282, null}
!291 = metadata !{i32 786688, metadata !282, metadata !"numBlocks", metadata !13, i32 777, metadata !24, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [numBlocks] [line 777]
!292 = metadata !{i32 777, i32 10, metadata !282, null}
!293 = metadata !{i32 779, i32 41, metadata !282, null}
!294 = metadata !{i32 786688, metadata !282, metadata !"numBlocks2", metadata !13, i32 780, metadata !24, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [numBlocks2] [line 780]
!295 = metadata !{i32 780, i32 10, metadata !282, null}
!296 = metadata !{i32 782, i32 42, metadata !282, null}
!297 = metadata !{i32 786688, metadata !282, metadata !"loop", metadata !13, i32 784, metadata !40, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [loop] [line 784]
!298 = metadata !{i32 784, i32 10, metadata !282, null}
!299 = metadata !{i32 784, i32 34, metadata !282, null}
!300 = metadata !{i32 786688, metadata !282, metadata !"loop2", metadata !13, i32 785, metadata !40, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [loop2] [line 785]
!301 = metadata !{i32 785, i32 10, metadata !282, null}
!302 = metadata !{i32 785, i32 36, metadata !282, null}
!303 = metadata !{i32 786688, metadata !282, metadata !"blocks", metadata !13, i32 786, metadata !24, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [blocks] [line 786]
!304 = metadata !{i32 786, i32 10, metadata !282, null}
!305 = metadata !{i32 786, i32 43, metadata !282, null}
!306 = metadata !{i32 786688, metadata !282, metadata !"blocksFind", metadata !13, i32 787, metadata !24, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [blocksFind] [line 787]
!307 = metadata !{i32 787, i32 10, metadata !282, null}
!308 = metadata !{i32 787, i32 49, metadata !282, null}
!309 = metadata !{i32 786688, metadata !282, metadata !"blocksReorder", metadata !13, i32 788, metadata !24, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [blocksReorder] [line 788]
!310 = metadata !{i32 788, i32 10, metadata !282, null}
!311 = metadata !{i32 788, i32 52, metadata !282, null}
!312 = metadata !{i32 802, i32 5, metadata !282, null}
!313 = metadata !{i32 804, i32 9, metadata !314, null}
!314 = metadata !{i32 786443, metadata !282, i32 803, i32 5, metadata !13, i32 10} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Race/RaceSort/radixsort.cu]
!315 = metadata !{i32 807, i32 17, metadata !314, null}
!316 = metadata !{i32 812, i32 16, metadata !314, null}
!317 = metadata !{i32 814, i32 5, metadata !314, null}
!318 = metadata !{i32 817, i32 9, metadata !319, null}
!319 = metadata !{i32 786443, metadata !282, i32 816, i32 5, metadata !13, i32 11} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Race/RaceSort/radixsort.cu]
!320 = metadata !{i32 820, i32 17, metadata !319, null}
!321 = metadata !{i32 825, i32 17, metadata !319, null}
!322 = metadata !{i32 937, i32 1, metadata !282, null}
!323 = metadata !{i32 786688, metadata !324, metadata !"maxElements", metadata !13, i32 1121, metadata !156, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [maxElements] [line 1121]
!324 = metadata !{i32 786443, metadata !41, i32 1119, i32 12, metadata !13, i32 5} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Race/RaceSort/radixsort.cu]
!325 = metadata !{i32 1121, i32 18, metadata !324, null}
!326 = metadata !{i32 1121, i32 34, metadata !324, null}
!327 = metadata !{i32 786688, metadata !324, metadata !"numElements", metadata !13, i32 1122, metadata !156, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [numElements] [line 1122]
!328 = metadata !{i32 1122, i32 18, metadata !324, null}
!329 = metadata !{i32 1122, i32 34, metadata !324, null}
!330 = metadata !{i32 786688, metadata !324, metadata !"keyBits", metadata !13, i32 1123, metadata !25, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [keyBits] [line 1123]
!331 = metadata !{i32 1123, i32 12, metadata !324, null}
!332 = metadata !{i32 1123, i32 24, metadata !324, null}
!333 = metadata !{i32 786688, metadata !324, metadata !"keys", metadata !13, i32 1124, metadata !334, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [keys] [line 1124]
!334 = metadata !{i32 786433, null, metadata !"", null, i32 0, i64 512, i64 32, i32 0, i32 0, metadata !25, metadata !335, i32 0, i32 0} ; [ DW_TAG_array_type ] [line 0, size 512, align 32, offset 0] [from unsigned int]
!335 = metadata !{metadata !336}
!336 = metadata !{i32 786465, i64 0, i64 15}      ; [ DW_TAG_subrange_type ] [0, 15]
!337 = metadata !{i32 1124, i32 12, metadata !324, null}
!338 = metadata !{i32 786688, metadata !324, metadata !"RS", metadata !13, i32 1127, metadata !91, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [RS] [line 1127]
!339 = metadata !{i32 1127, i32 13, metadata !324, null}
!340 = metadata !{i32 1127, i32 34, metadata !324, null}
!341 = metadata !{i32 1130, i32 3, metadata !324, null}
!342 = metadata !{i32 786688, metadata !343, metadata !"i", metadata !13, i32 1133, metadata !44, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [i] [line 1133]
!343 = metadata !{i32 786443, metadata !324, i32 1133, i32 3, metadata !13, i32 6} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Race/RaceSort/radixsort.cu]
!344 = metadata !{i32 1133, i32 12, metadata !343, null}
!345 = metadata !{i32 1133, i32 17, metadata !343, null}
!346 = metadata !{i32 1134, i32 5, metadata !347, null}
!347 = metadata !{i32 786443, metadata !343, i32 1133, i32 41, metadata !13, i32 7} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Race/RaceSort/radixsort.cu]
!348 = metadata !{i32 1135, i32 7, metadata !349, null}
!349 = metadata !{i32 786443, metadata !347, i32 1134, i32 30, metadata !13, i32 8} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Race/RaceSort/radixsort.cu]
!350 = metadata !{i32 1136, i32 7, metadata !349, null}
!351 = metadata !{i32 1138, i32 3, metadata !347, null}
!352 = metadata !{i32 1133, i32 36, metadata !343, null}
!353 = metadata !{i32 1140, i32 1, metadata !324, null}
!354 = metadata !{i32 786689, metadata !109, metadata !"this", metadata !31, i32 16777297, metadata !355, i32 1088, i32 0} ; [ DW_TAG_arg_variable ] [this] [line 81]
!355 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !91} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from RadixSort]
!356 = metadata !{i32 81, i32 5, metadata !109, null}
!357 = metadata !{i32 786689, metadata !109, metadata !"maxElements", metadata !31, i32 33554513, metadata !25, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [maxElements] [line 81]
!358 = metadata !{i32 81, i32 28, metadata !109, null}
!359 = metadata !{i32 786689, metadata !109, metadata !"keysOnly", metadata !31, i32 50331729, metadata !40, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [keysOnly] [line 81]
!360 = metadata !{i32 81, i32 46, metadata !109, null}
!361 = metadata !{i32 92, i32 5, metadata !109, null}
!362 = metadata !{i32 786689, metadata !87, metadata !"this", metadata !31, i32 16777327, metadata !355, i32 1088, i32 0} ; [ DW_TAG_arg_variable ] [this] [line 111]
!363 = metadata !{i32 111, i32 10, metadata !87, null}
!364 = metadata !{i32 786689, metadata !87, metadata !"keys", metadata !31, i32 33554543, metadata !96, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [keys] [line 111]
!365 = metadata !{i32 111, i32 29, metadata !87, null}
!366 = metadata !{i32 786689, metadata !87, metadata !"values", metadata !31, i32 50331760, metadata !96, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [values] [line 112]
!367 = metadata !{i32 112, i32 29, metadata !87, null}
!368 = metadata !{i32 786689, metadata !87, metadata !"numElements", metadata !31, i32 67108977, metadata !25, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [numElements] [line 113]
!369 = metadata !{i32 113, i32 29, metadata !87, null}
!370 = metadata !{i32 786689, metadata !87, metadata !"keyBits", metadata !31, i32 83886194, metadata !25, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [keyBits] [line 114]
!371 = metadata !{i32 114, i32 29, metadata !87, null}
!372 = metadata !{i32 116, i32 9, metadata !373, null}
!373 = metadata !{i32 786443, metadata !87, i32 115, i32 5, metadata !31, i32 15} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Race/RaceSort/./radixsort.h]
!374 = metadata !{i32 118, i32 13, metadata !375, null}
!375 = metadata !{i32 786443, metadata !373, i32 117, i32 9, metadata !31, i32 16} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Race/RaceSort/./radixsort.h]
!376 = metadata !{i32 121, i32 9, metadata !375, null}
!377 = metadata !{i32 128, i32 5, metadata !373, null}
!378 = metadata !{i32 786689, metadata !110, metadata !"this", metadata !31, i32 16777297, metadata !355, i32 1088, i32 0} ; [ DW_TAG_arg_variable ] [this] [line 81]
!379 = metadata !{i32 81, i32 5, metadata !110, null}
!380 = metadata !{i32 786689, metadata !110, metadata !"maxElements", metadata !31, i32 33554513, metadata !25, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [maxElements] [line 81]
!381 = metadata !{i32 81, i32 28, metadata !110, null}
!382 = metadata !{i32 786689, metadata !110, metadata !"keysOnly", metadata !31, i32 50331729, metadata !40, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [keysOnly] [line 81]
!383 = metadata !{i32 81, i32 46, metadata !110, null}
!384 = metadata !{i32 89, i32 5, metadata !110, null}
!385 = metadata !{i32 91, i32 9, metadata !386, null}
!386 = metadata !{i32 786443, metadata !110, i32 89, i32 5, metadata !31, i32 17} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Race/RaceSort/./radixsort.h]
!387 = metadata !{i32 92, i32 5, metadata !386, null}
!388 = metadata !{i32 786689, metadata !112, metadata !"this", metadata !31, i32 16777242, metadata !389, i32 1088, i32 0} ; [ DW_TAG_arg_variable ] [this] [line 26]
!389 = metadata !{i32 786447, null, metadata !"", null, i32 0, i64 64, i64 64, i64 0, i32 0, metadata !30} ; [ DW_TAG_pointer_type ] [line 0, size 64, align 64, offset 0] [from CUDPPHandle]
!390 = metadata !{i32 26, i32 3, metadata !112, null}
!391 = metadata !{i32 786689, metadata !112, metadata !"c", metadata !31, i32 33554458, metadata !37, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [c] [line 26]
!392 = metadata !{i32 26, i32 21, metadata !112, null}
!393 = metadata !{i32 26, i32 25, metadata !112, null}
!394 = metadata !{i32 786689, metadata !111, metadata !"this", metadata !31, i32 16777378, metadata !355, i32 1088, i32 0} ; [ DW_TAG_arg_variable ] [this] [line 162]
!395 = metadata !{i32 162, i32 10, metadata !111, null}
!396 = metadata !{i32 786689, metadata !111, metadata !"numElements", metadata !31, i32 33554594, metadata !25, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [numElements] [line 162]
!397 = metadata !{i32 162, i32 34, metadata !111, null}
!398 = metadata !{i32 786689, metadata !111, metadata !"keysOnly", metadata !31, i32 50331810, metadata !40, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [keysOnly] [line 162]
!399 = metadata !{i32 162, i32 52, metadata !111, null}
!400 = metadata !{i32 168, i32 9, metadata !401, null}
!401 = metadata !{i32 786443, metadata !111, i32 163, i32 5, metadata !31, i32 18} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Race/RaceSort/./radixsort.h]
!402 = metadata !{i32 786688, metadata !401, metadata !"numBlocks", metadata !31, i32 170, metadata !25, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [numBlocks] [line 170]
!403 = metadata !{i32 170, i32 22, metadata !401, null}
!404 = metadata !{i32 171, i32 80, metadata !401, null}
!405 = metadata !{i32 786688, metadata !401, metadata !"numBlocks2", metadata !31, i32 172, metadata !25, i32 0, i32 0} ; [ DW_TAG_auto_variable ] [numBlocks2] [line 172]
!406 = metadata !{i32 172, i32 22, metadata !401, null}
!407 = metadata !{i32 173, i32 80, metadata !401, null}
!408 = metadata !{i32 183, i32 9, metadata !401, null}
!409 = metadata !{i32 184, i32 9, metadata !401, null}
!410 = metadata !{i32 185, i32 13, metadata !401, null}
!411 = metadata !{i32 186, i32 9, metadata !401, null}
!412 = metadata !{i32 187, i32 9, metadata !401, null}
!413 = metadata !{i32 188, i32 9, metadata !401, null}
!414 = metadata !{i32 190, i32 9, metadata !401, null}
!415 = metadata !{i32 191, i32 5, metadata !401, null}
!416 = metadata !{i32 786689, metadata !113, metadata !"this", metadata !31, i32 16777242, metadata !389, i32 1088, i32 0} ; [ DW_TAG_arg_variable ] [this] [line 26]
!417 = metadata !{i32 26, i32 3, metadata !113, null}
!418 = metadata !{i32 786689, metadata !113, metadata !"c", metadata !31, i32 33554458, metadata !37, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [c] [line 26]
!419 = metadata !{i32 26, i32 21, metadata !113, null}
!420 = metadata !{i32 26, i32 25, metadata !421, null}
!421 = metadata !{i32 786443, metadata !113, i32 26, i32 24, metadata !31, i32 19} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Race/RaceSort/./radixsort.h]
!422 = metadata !{i32 786689, metadata !136, metadata !"this", metadata !59, i32 16777613, metadata !167, i32 1088, i32 0} ; [ DW_TAG_arg_variable ] [this] [line 397]
!423 = metadata !{i32 397, i32 25, metadata !136, null}
!424 = metadata !{i32 786689, metadata !136, metadata !"vx", metadata !59, i32 33554829, metadata !25, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [vx] [line 397]
!425 = metadata !{i32 397, i32 43, metadata !136, null}
!426 = metadata !{i32 786689, metadata !136, metadata !"vy", metadata !59, i32 50332045, metadata !25, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [vy] [line 397]
!427 = metadata !{i32 397, i32 64, metadata !136, null}
!428 = metadata !{i32 786689, metadata !136, metadata !"vz", metadata !59, i32 67109261, metadata !25, i32 0, i32 0} ; [ DW_TAG_arg_variable ] [vz] [line 397]
!429 = metadata !{i32 397, i32 85, metadata !136, null}
!430 = metadata !{i32 397, i32 115, metadata !136, null}
!431 = metadata !{i32 397, i32 116, metadata !432, null}
!432 = metadata !{i32 786443, metadata !136, i32 397, i32 115, metadata !59, i32 20} ; [ DW_TAG_lexical_block ] [/home/peng/gklee-clang/gklee/trunk/Gklee/CUDA/Test/Clang_Test/FM2012-Tutorial/Race/RaceSort//home/peng/gklee-clang/gklee/trunk/Gklee/include/cuda/vector_types.h]
