#include "stdio.h"
#include "string.h"

int main(){
  int item1, item2, item3;
  klee_make_symbolic(&item1, sizeof(item1), "item1");
  klee_make_symbolic(&item2, sizeof(item2), "item2");
  klee_make_symbolic(&item3, sizeof(item3), "item3");
  
  if(item1 > item2) {
    printf("Item1 > Item2\n");
    if(item2 > item3) {
      printf("Item2 > Item3\n");
      if(item3 > item1) {
	printf("Item3 > Item1\n");
      }
      else
	printf("Item3 <= Item1\n");
    }
    printf("Item2 <= Item3\n");
  }
  printf("Item1 <= Item2\n");
}

