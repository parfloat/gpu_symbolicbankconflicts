#include <stdio.h>

#define NUM 100

__shared__ int v[NUM];

__global__ void divergence() {
  if (threadIdx.x %2) { 
    v[threadIdx.x]++;
  }
  else {
    v[threadIdx.x]--;
  }
}

int main() {
  divergence<<<1,NUM>>>();

  return 0;
}
