
#include <klee.h>
#include <stdio.h>
#include "cutil.h"

#define NUM 100

__shared__ int v[NUM];

__kernel__ void deadlock() {
  if (threadIdx.x > 0) { 
    v[threadIdx.x]++;
    __syncthreads();
  }
  else {
    __syncthreads();  // remove this one to incur a barrier dismatch
  }
}

__kernel__ void race() {

  v[threadIdx.x] = v[(threadIdx.x + 1) % blockDim.x];
  __syncthreads();
}


int main() {

  printf("This is for testing barrier mismatches!\n");

  __begin_GPU(NUM);
  deadlock();
  __end_GPU();

  return 0;
}
