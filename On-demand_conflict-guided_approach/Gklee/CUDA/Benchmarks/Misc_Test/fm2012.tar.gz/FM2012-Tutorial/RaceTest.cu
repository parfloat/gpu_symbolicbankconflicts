#include <stdio.h>

#define NUM 100

__shared__ int v[NUM];

__global__ void race() {
  v[threadIdx.x] = v[(threadIdx.x + 1) % blockDim.x];
  __syncthreads();
}


int main() {
  race<<<1,NUM>>>();

  return 0;
}
