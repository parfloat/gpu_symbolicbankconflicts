#include "stdio.h"
#include "string.h"

int main(){
 char item;
 klee_make_symbolic(&item, sizeof(item), "item");
 if(item) {
   if(item > 3) printf("Item > 3\n");
   else printf("1 <= Item <= 3\n");
 }
 else printf("Item == Zero\n");
}
