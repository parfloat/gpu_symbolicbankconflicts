/*
 * Copyright (C) 2004-2006 Manuel Novoa III <mjn3@uclibc.org>
 *
 * Licensed under the LGPL v2.1, see the file COPYING.LIB in this tarball.
 */

#define L_nl_langinfo_l
#define __UCLIBC_DO_XLOCALE
#include "locale.c"
